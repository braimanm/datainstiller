This repository contain automation tests for the following ALFRESCO based projects:</br>
RLM Canada </br>
RLM US </br>
SDS </br>
RATES </br>
TORC </br>
SIT KYC </br>
SIT Tax-Operations </br>
SIT Project Clients </br>
SIT JOB MANDATE </br>
