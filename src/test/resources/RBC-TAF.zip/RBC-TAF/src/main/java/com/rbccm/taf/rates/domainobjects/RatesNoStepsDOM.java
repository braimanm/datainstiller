package com.rbccm.taf.rates.domainobjects;

import com.rbccm.taf.mail.EWSMail;
import com.rbccm.taf.rates.api.RatesIndexFile;
import com.rbccm.taf.rates.api.RatesIndexFileAttribute;
import com.rbccm.taf.rates.api.RatesIndexFileFlag;
import com.rbccm.taf.rates.api.RatesSCP;
import com.rbccm.taf.rates.pageobjects.RatesActiFlowPOM;
import com.rbccm.taf.rates.pageobjects.RatesLoginPOM;
import com.rbccm.taf.ui.support.*;
import com.thoughtworks.xstream.annotations.XStreamAlias;
import microsoft.exchange.webservices.data.core.service.item.Item;
import microsoft.exchange.webservices.data.search.FindItemsResults;
import org.apache.commons.io.IOUtils;
import org.assertj.core.api.Assertions;
import ru.yandex.qatools.allure.annotations.Step;

import java.io.IOException;
import java.io.InputStream;
import java.util.Set;

@XStreamAlias("rates-no-steps-domain-object")
public class RatesNoStepsDOM extends DomainObjectModel {
    private AliasedString envUrl;
    private AliasedString feedDestinationFolder;
    private AliasedString adviceId;
    private AliasedString mailUserName;
    private AliasedString mailPassWord;
    private AliasedString forwardEmailID;
    private AliasedString emailPrefixBody;
    private Set<RatesIndexFileFlag> indexFlags;
    private Set<RatesIndexFileAttribute> indexAttributes;
    private RatesLoginPOM login;
    private RatesActiFlowPOM actiFlow;

    public RatesNoStepsDOM(){}
    public RatesNoStepsDOM(String dataSet) {
        initData(fromResource(dataSet));
        if (System.getenv().containsKey("APP_ENTITY") && System.getenv("APP_ENTITY").trim().toUpperCase().equals("LONDON")) {
            String curr = TestContext.getGlobalAliases().get("advice-id");
            TestContext.getGlobalAliases().put("advice-id",curr.replaceFirst("T","L"));
        }
    }

    @Step("Upload feed files")
    public String uploadGeneratedFeedFiles() throws IOException, InterruptedException {

        RatesIndexFile indexFile = new RatesIndexFile(adviceId.getData());
        if (indexFlags != null) {
            for (RatesIndexFileFlag flag : indexFlags) {
                indexFile.setFlag(flag, true);
            }
        }
        if (indexAttributes != null) {
            for (RatesIndexFileAttribute attribute : indexAttributes) {
                indexFile.setAttribute(attribute);
            }
        }
        InputStream isDoc = getClass().getClassLoader().getResourceAsStream("data/rates/feed/ADVICE.html");
        byte[] document = IOUtils.toByteArray(isDoc);
        IOUtils.closeQuietly(isDoc);
        String transId = indexFile.getProps().getProperty("TRANS_ID");
        String fileName = "ADVICE_" + transId + "_" + adviceId.getData();
        EnvironmentsSetup.User usr = TestContext.getTestProperties().getTestEnvironment().getUser("ssh");
        String sshServer = envUrl.getData();
        sshServer = sshServer.substring(sshServer.indexOf(":") + 3, sshServer.lastIndexOf(":"));
        RatesSCP scp = new RatesSCP(sshServer, usr.getUserName(), usr.getPassword());
        scp.transferFile(document, fileName + ".html", feedDestinationFolder.getData());
        scp.transferFile(indexFile.getPropsAsBytes(), fileName + ".index", feedDestinationFolder.getData());
        System.out.println("Task with advice id " + adviceId.getData() + " was created and moved to server");
        RatesStep step = new RatesStep();
        step.waitForTaskInBasket(adviceId.getData(), actiFlow.getSourceBasket());
        return adviceId.getData();
    }

    @Step("Verify that Email is triggered for the trade in counterParty's mailbox and Sending it back to ActiFlow")

    public String verifyAndForwardMail(){
        EWSMail mail = new EWSMail();
        mail.setCredentials(mailUserName.getData(),mailPassWord.getData());
        FindItemsResults<Item> items = mail.waitForEmailWithSubject(adviceId.getData());
        Assertions.assertThat(items.getTotalCount()).isGreaterThan(0);
        mail.forwardEmail(items.getItems().get(0), forwardEmailID.getData(), emailPrefixBody.getData());
        RatesStep step = new RatesStep();
        step.waitForTaskInBasket(adviceId.getData(), actiFlow.getSourceBasket());
        return adviceId.getData();
    }


    public RatesLoginPOM getLoginPOM(TestContext context) {
        this.context = context;
        login.initPage(context);
        return login;
    }

    public RatesActiFlowPOM getActiFlowPOM () {
        actiFlow.initPage(getContext());
        return actiFlow;
    }

}
