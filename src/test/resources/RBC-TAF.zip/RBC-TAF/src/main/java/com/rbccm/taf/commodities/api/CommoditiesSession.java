package com.rbccm.taf.commodities.api;

import com.rbccm.taf.common.api.AlfrescoApiBase;
import org.jsoup.Connection;
import org.jsoup.nodes.Document;

import java.io.IOException;
import java.util.Map;

public class CommoditiesSession {
    private Map<String, String> cookies;
    private String urlBase;
    private String userName;
    private String password;

    public CommoditiesSession(String urlBase, String userName, String password) throws IOException {
        this.urlBase = urlBase;
        this.userName = userName;
        this.password = password;
        login();
    }

    private void login() throws IOException {
        AlfrescoApiBase api = new AlfrescoApiBase(urlBase);
        Connection con = api.getConnection("/login");
        con.data("username", userName);
        con.data("password", password);
        con.data("submit", "Login");
        con.method(Connection.Method.POST);
        Connection.Response res = con.execute();
        cookies = res.cookies();
        System.out.println("COMSESSIONID: " + cookies.get("COMSESSIONID") + " USER: " + userName);
        Document doc = res.parse();
        String title = doc.title();
        if (!title.contains("Commodities Actiflow"))
        {
            throw new RuntimeException("Login failed!");
        }
    }

    public Connection getConnection(String endPoint) throws IOException {
        if (cookies == null) login();
        Connection con = new AlfrescoApiBase(urlBase).getConnection(endPoint);
        con.cookies(cookies);
        return con;
    }

}
