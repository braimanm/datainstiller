package com.rbccm.taf.sit.pageobjects;

import com.rbccm.taf.sit.components.SITMenuButton;
import com.rbccm.taf.sit.components.SITMoveToDialog;
import com.rbccm.taf.ui.support.AliasedString;
import com.rbccm.taf.ui.support.PageObjectModel;
import com.rbccm.taf.ui.utils.Helper;
import com.thoughtworks.xstream.annotations.XStreamImplicit;
import datainstiller.data.Data;
import org.apache.commons.io.FileUtils;
import org.assertj.core.api.Assertions;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.LocalFileDetector;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import ru.yandex.qatools.allure.annotations.Step;
import ui.auto.core.components.WebComponent;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

public class SITDocumentLibraryPOM extends PageObjectModel {
    @Data(skip = true)
    @FindBy(xpath = "//button[starts-with(.,'Create...')]")
    SITMenuButton createButton;
    @Data(skip = true)
    @FindBy(xpath = "//button[starts-with(.,'Selected Items...')]")
    SITMenuButton selctedItemsButton;
    @Data(skip = true)
    @FindBy(css = "button[id$=fileUpload-button-button]")
    WebComponent uploadButton;
    @Data(skip = true)
    @FindBy(css = "div[id$=createFolder-dialog]")
    WebComponent newFolderDialog;
    @Data(skip = true)
    @FindBy(css = "div[id$=createFolder-dialog] input[name=prop_cm_name]")
    WebComponent newFolderName;
    @Data(skip = true)
    @FindBy(css = "div[id$=createFolder-dialog] input[name=prop_cm_title]")
    WebComponent newFolderTitle;
    @Data(skip = true)
    @FindBy(css = "div[id$=createFolder-dialog] button[id$=submit-button]")
    WebComponent newFolderSaveButton;
    @Data(skip = true)
    @FindBy(css = "input[type=file][name='files[]']")
    WebComponent fileUpload;
    @Data(skip = true)
    @FindBy(css = ".dnd-upload")
    WebComponent fileUploadDialog;
    @Data(skip = true)
    @FindBy(css = "#message")
    WebComponent message;
    AliasedString documentFolder;
    @XStreamImplicit
    List<SITDocumentDetailsPOM> documentDetailsPOMs;
    @Data(skip = true)
    @FindBy(css = "div[id$=copyMoveTo-dialog]")
    SITMoveToDialog moveToDialog;
    @Data(skip = true)
    @FindBy(css = "#HEADER_SEARCHBOX_FORM_FIELD")
    WebComponent searchInput;

    public void createNewFolder() {
        createNewFolder("");
    }

    public void createNewFolder(String suffix) {
        String folderName = documentFolder.getData() + suffix;
        createButton.setValue("Folder");
        Helper.waitToShow(newFolderDialog);
        setElementValue(newFolderName, folderName);
        setElementValue(newFolderTitle, folderName);
        newFolderSaveButton.click();
        Helper.waitToHide(newFolderDialog);
        Assertions.assertThat(message.getText()).contains("Folder '" + folderName + "' created");
    }

    public void openFolder() {
        By by = By.xpath("//a[.='" + documentFolder.getData() + "']");
        List<WebElement> el = Helper.getWebDriiverWait().until(ExpectedConditions.presenceOfAllElementsLocatedBy(by));
        el.get(1).click();
        Helper.waitForXHR();
    }


    public void uploadDocuments() throws IOException {
        for (SITDocumentDetailsPOM documentDetails : documentDetailsPOMs) {
            uploadDocument(documentDetails.documentFolderName.getData(), documentDetails.documentFileName.getData());
        }
    }

    public void validateDocuments() throws IOException {
        for (SITDocumentDetailsPOM documentDetails : documentDetailsPOMs) {
            validateDocument(documentDetails, documentDetails.documentFileName.getData());
        }
    }

    @Step("Upload \"{1}\" document file")
    private void uploadDocument(String documentPath, String documentName) throws IOException {
        uploadButton.click();
        Helper.waitToShow(fileUploadDialog);
        if (getDriver().getClass().equals(RemoteWebDriver.class)) {
            ((RemoteWebDriver) getDriver()).setFileDetector(new LocalFileDetector());
        }
        File file = new File("./" + documentPath + documentName);
        InputStream stream = getClass().getClassLoader().getResourceAsStream(documentPath + documentName);
        FileUtils.copyInputStreamToFile(stream, file);
        WebElement upload = getDriver().findElement(By.cssSelector("input[type=file][name='files[]']"));
        upload.sendKeys(file.getAbsolutePath());
        Helper.waitToHide(fileUploadDialog);
        Helper.waitForXHR();
    }

    @Step("Validate document \"{1}\"")
    public void validateDocument(SITDocumentDetailsPOM documentDetailsPOM, String documentName) throws IOException {
        Assertions.assertThat(getDriver().getCurrentUrl()).contains(documentFolder.getData());
        WebElement doc = Helper.waitToShow(By.xpath("//div/span/a[.='" + documentDetailsPOM.documentFileName.getData() + "']"));
        doc.click();
        documentDetailsPOM.initPage(getContext());
        documentDetailsPOM.validateDocument(documentFolder.getData());
    }

    @Step("Move document to another folder")
    public void moveDocument(String suffix) {
        getDriver().findElement(By.xpath("//label[.='Check SIT_DOC.docx']/..//input")).click();
        selctedItemsButton.setValue("Move to...");
        Helper.waitForXHR();
        moveToDialog.moveToFolder(documentFolder.getData() + suffix);
    }

    @Step("Search for folder")
    public void searchForFolder(String suffix) {
        String folderName = documentFolder.getData() + suffix;
        List<WebElement> items;
        long to = System.currentTimeMillis() + getContext().getWaitForUrlTimeOut();
        do {
            searchInput.getCoreElement().sendKeys(folderName + Keys.ENTER);
            waitForUrlToChange();
            Helper.waitToShow(By.cssSelector("#FCTSRCH_RESULTS_COUNT_LABEL"));
            items = getDriver().findElements(By.xpath("//span[.='" + folderName + "']"));
            if (items.isEmpty()) {
                getDriver().navigate().back();
                waitForUrlToChange();
                Helper.sleep(1000);
            }
        } while (items.isEmpty() && System.currentTimeMillis() < to);
        if (items.isEmpty()) {
            throw new RuntimeException("Folder " + folderName + " can't be found!");
        }
        items.get(0).click();
    }

    @Step("Validate moved document")
    public void validateMovedDocument(String suffix) throws IOException {
        String folderName = documentFolder.getData();
        documentFolder.initializeData(folderName + suffix, null, null);
        SITDocumentDetailsPOM documentDetails = documentDetailsPOMs.get((documentDetailsPOMs.size()-1));
        validateDocument(documentDetails, documentDetails.documentFileName.getData());
        documentFolder.initializeData(folderName, null, null);
    }
}
