package com.rbccm.taf.commodities.tests.perf;

import org.testng.annotations.Factory;

public class CommoditiesPerfTestFactory {

    @Factory()
    public Object[] createInstances() {
        int threads = 5;
        if (System.getenv().containsKey("LOAD_FLOWS")) {
            threads = Integer.parseInt(System.getenv().get("LOAD_FLOWS"));
        }
        Object[] result = new Object[threads];
        for (int i = 0; i < threads; i++) {
            result[i] = new CommoditiesPerfTest(i + 1);
        }
        return result;
    }

}
