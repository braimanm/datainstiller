package com.rbccm.taf.sds.pageobjects;

import com.rbccm.taf.ui.support.PageObjectModel;
import com.rbccm.taf.ui.utils.Helper;
import datainstiller.data.Data;
import org.openqa.selenium.support.FindBy;
import ru.yandex.qatools.allure.annotations.Step;
import ui.auto.core.components.WebComponent;

public class SDSMainPO extends PageObjectModel {
    @Data(skip = true)
    @FindBy(css = "button.btn[type=button]")
    private WebComponent newrequestButton;
    @Data(skip = true)
    @FindBy(xpath = "//a[contains(.,'Create New Request')]")
    private WebComponent newRequestTab;

    @Data(skip = true)
    @FindBy(css = "[class='fa fa-power-off fa-lg']")
    private WebComponent btnSignOut;

    @Step("Log-off from application")
    public void logOut() {
        btnSignOut.click();
    }

    @Step("Click On 'new-request' button")
    public void createNewRequest() {
        newrequestButton.click();
        newRequestTab.click();
        Helper.waitForXHR();
    }

}
