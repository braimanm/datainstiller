package com.rbccm.taf.rates.domainobjects;

import com.rbccm.taf.rates.api.*;
import com.rbccm.taf.ui.support.AliasedString;
import com.rbccm.taf.ui.support.DomainObjectModel;
import com.rbccm.taf.ui.support.EnvironmentsSetup;
import com.rbccm.taf.ui.support.TestContext;
import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;
import org.apache.commons.io.IOUtils;
import ru.yandex.qatools.allure.annotations.Step;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Set;


@XStreamAlias("rates-domain-object")
public class RatesDOM extends DomainObjectModel {
    private AliasedString envUrl;
    private AliasedString feedDestinationFolder;
    private AliasedString adviceId;
    private Set<RatesIndexFileFlag> indexFlags;
    private Set<RatesIndexFileAttribute> indexAttributes;
    @XStreamImplicit
    private List<RatesStep> functionalSteps;

    public RatesDOM() {}
    public RatesDOM(String dataset) {
        initData(fromResource(dataset));
    }

    private void uploadFiles(RatesIndexFile indexFile) throws IOException, InterruptedException {
        InputStream isDoc = getClass().getClassLoader().getResourceAsStream("data/rates/feed/ADVICE.html");
        byte[] document = IOUtils.toByteArray(isDoc);
        IOUtils.closeQuietly(isDoc);
        String adviceId = indexFile.getProps().getProperty("ADVICE_ID");
        String transId = indexFile.getProps().getProperty("TRANS_ID");
        String fileName = "ADVICE_" + transId + "_" + adviceId;
        EnvironmentsSetup.User usr = TestContext.getTestProperties().getTestEnvironment().getUser("ssh");
        String sshServer = envUrl.getData();
        sshServer = sshServer.substring(sshServer.indexOf(":") + 3, sshServer.lastIndexOf(":"));
        RatesSCP scp = new RatesSCP(sshServer, usr.getUserName(), usr.getPassword());
        scp.transferFile(document, fileName + ".html", feedDestinationFolder.getData());
        scp.transferFile(indexFile.getPropsAsBytes(), fileName + ".index", feedDestinationFolder.getData());
        System.out.println("Task with advice id " + adviceId + " was created and moved to server");
    }

    @Step("Upload feed files and wait for task to appear in destination folder")
    public String uploadGeneratedFeedFiles() throws IOException, InterruptedException {
        RatesStep step = functionalSteps.get(0);
        RatesIndexFile indexFile = new RatesIndexFile(adviceId.getData());
        if (indexFlags != null) {
            for (RatesIndexFileFlag flag : indexFlags) {
                indexFile.setFlag(flag, true);
            }
        }
        if (indexAttributes != null) {
            for (RatesIndexFileAttribute attribute : indexAttributes) {
                indexFile.setAttribute(attribute);
            }
        }
        String adviceId = indexFile.getProperty("ADVICE_ID");
        uploadFiles(indexFile);
        step.waitForTaskInBasket(adviceId, step.actiFlow.getSourceBasket());
        return adviceId;
    }


    public RatesStep getFunctionalStep(int i) {
        return functionalSteps.get(i);
    }

    public List<RatesStep> getfunctionalSteps() {
        return functionalSteps;
    }
}
