package com.rbccm.taf.rates.api;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("flag")
public enum RatesIndexFileFlag {
    SPECIAL_FEATURE_FLAG,
    STRUCTURED_FLAG,
    AMENDMENT_FLAG,
    BBAIRS_FLAG,
    NEW_COUNTERPARTY,
    ASSIGNED,
    SI_MISSING,
    SAME_DAY_CANCEL_FLAG,
    CDS_FLAG,
    PAYMENT_FLAG,
    FATCA_FLAG;

    public String getName() {
        return this.name();
    }

}
