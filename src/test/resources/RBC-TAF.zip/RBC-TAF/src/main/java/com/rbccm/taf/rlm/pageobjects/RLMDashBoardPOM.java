package com.rbccm.taf.rlm.pageobjects;

import com.rbccm.taf.rlm.components.RLMTable;
import com.rbccm.taf.ui.testng.TestNGBase;
import com.rbccm.taf.ui.utils.Helper;
import datainstiller.data.Data;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.support.FindBy;
import ru.yandex.qatools.allure.annotations.Step;
import ui.auto.core.components.WebComponent;
import static org.assertj.core.api.Assertions.assertThat;

@SuppressWarnings("unused")
public class RLMDashBoardPOM extends RLMMainPOM {
    @Data(skip = true)
    @FindBy(css = ".alert-success")
    private WebComponent pendingRequestsLoadInfo;
    @Data(skip = true)
    @FindBy(css = ".alert-success")
    private WebComponent pendingRequestsLoadStatus;
    @Data(skip = true)
    @FindBy(css = "input[placeholder='Search by Request ID']")
    private WebComponent searchByReqId;
    @Data(skip = true)
    @FindBy(css = "button.btn-search")
    private WebComponent buttonSearch;
    @Data(skip = true)
    @FindBy(css = "rlm-dashboard>div table")
    private RLMTable pendingRequests;
    @Data(skip = true)
    @FindBy(css = "rlm-search-grid>div table")
    private RLMTable searchResults;
    @Data(skip = true)
    @FindBy(id = "requestorname")
    private WebComponent reqName;


    public RLMDashBoardPOM() {
        this.initPage(TestNGBase.CONTEXT());
    }

    private void searchForReqId(String reqId) {
        setElementValue(searchByReqId, reqId);
        buttonSearch.click();
        waitForTableToUpdate(searchResults);
    }

    @Step("Serach for request by ID {0} and select it")
    public void searchForReqIDandSelect(String reqId) {
        searchForReqId(reqId);
        searchResults.clickRequestId(reqId);
    }

    @Step("Search for request by ID {0} and select Audit Trail")
    public void selectAuditTrailForReqId(String reqId) {
        searchForReqId(reqId);
        searchResults.clickAuditTrail(reqId);
        Helper.waitForXHR();
    }

    @Step("Selecting Pending Request ID {0} ")
    public void selectPendingRequestByReqID(String reqId) {
        pendingRequests.clickRequestId(reqId);
        Helper.waitForXHR();
    }

    @Step("Validate Request Id {0} has expected status of {1}")
    public void validateRequestStatusByReqId(String reqId, String expectedStatus) {
        assertThat(pendingRequests.getStatusByRequestId(reqId)).isEqualToIgnoringCase(expectedStatus);
    }

    public void waitForPendingRequestsToUpdate() {
//        Helper.moveFocusToElement(pendingRequests.getCoreElement());
//        boolean showed = Helper.waitToShow(pendingRequestsLoadInfo, 2);
//        if (showed && pendingRequestsLoadInfo.getText().contains("Loading Requests")) {
//            if (Helper.waitToShow(pendingRequestsLoadStatus)) {
//                String msg = pendingRequestsLoadStatus.getText();
//                assertThat(msg).containsPattern("\\d+ +Requests loaded successfully.");
//            }
//        }
        waitForTableToUpdate(pendingRequests);
    }

    private void waitForTableToUpdate(RLMTable table) {
        try {
            Helper.getWebDriiverWait().until(driver -> table.getNumberOfRows() > 0);
        } catch (TimeoutException e) {
            throw new RuntimeException("Data for the Table was not loaded (tried for " +
                    getContext().getAjaxTimeOut() + " seconds)");
        }
    }


}
