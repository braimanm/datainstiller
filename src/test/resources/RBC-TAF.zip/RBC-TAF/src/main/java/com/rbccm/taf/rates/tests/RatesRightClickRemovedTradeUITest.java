package com.rbccm.taf.rates.tests;

import com.rbccm.taf.rates.components.RatesDocumentEntry;
import com.rbccm.taf.rates.components.RatesDocumentProperty;
import com.rbccm.taf.rates.components.RatesTaskEntry;
import com.rbccm.taf.rates.components.RatesTaskProperty;
import com.rbccm.taf.rates.domainobjects.RatesNoStepsDOM;
import com.rbccm.taf.rates.pageobjects.RatesActiFlowPOM;
import com.rbccm.taf.rates.pageobjects.RatesFileCabinetPOM;
import com.rbccm.taf.rates.pageobjects.RatesLoginPOM;
import com.rbccm.taf.ui.testng.TestNGBase;
import org.assertj.core.api.Assertions;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.Description;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

import java.io.IOException;

@Features("Review 1 to Remove")
@Stories("Verify task removal from workflow")
@Description("Review 1 -->Remove(Verify Comment)-->Return to review1(Verify Comment)-->Remove(Verify Comment)-->Remove from workflow-->StatusCode verify in FileCabinet")
public class RatesRightClickRemovedTradeUITest extends TestNGBase {
    private String adviceId;


    @Parameters({"data-set1"})
    @Test
    public void tc010_01(@Optional("data/rates/TC010_Vanilla_ReviewI_Verify_the_right_click_functionalities_for_Removed_trades_from_Review1/TC010_01.xml") String dataSet) throws IOException, InterruptedException {

        RatesNoStepsDOM rates = new RatesNoStepsDOM(dataSet);
        adviceId = rates.uploadGeneratedFeedFiles();

        RatesLoginPOM login = rates.getLoginPOM(getContext());
        login.login();

        RatesActiFlowPOM actiFlow = rates.getActiFlowPOM();

        actiFlow.selectBasket();

        RatesTaskEntry task = actiFlow.getTaskByAdviceId(adviceId);
        task.validateActions();
        task.doAction();
        actiFlow.validateTaskMigration(adviceId);
        Assertions.assertThat(task.getProperty(RatesTaskProperty.Comment)).isEqualTo("From Review 1");

    }

    @Parameters({"data-set2"})
    @Test(dependsOnMethods = "tc010_01")
    public void tc010_02(@Optional("data/rates/TC010_Vanilla_ReviewI_Verify_the_right_click_functionalities_for_Removed_trades_from_Review1/TC010_02.xml") String dataSet) throws IOException, InterruptedException{
        RatesNoStepsDOM rates = new RatesNoStepsDOM(dataSet);

        RatesLoginPOM login = rates.getLoginPOM(getContext());
        login.login();

        RatesActiFlowPOM actiFlow = rates.getActiFlowPOM();
        actiFlow.selectBasket();


        RatesTaskEntry task = actiFlow.getTaskByAdviceId(adviceId);
        task.validateActions();
        task.doAction();
        actiFlow.validateTaskMigration(adviceId);
        RatesFileCabinetPOM fileCabinetPOM = actiFlow.getFileCabinetPOM();
        fileCabinetPOM.searchForDocument("Advice Id :" + adviceId);
        RatesDocumentEntry documentEntry = fileCabinetPOM.getDocument(0);
        Assertions.assertThat(documentEntry.getProperty(RatesDocumentProperty.StatusCode)).isEqualTo("NEW");
    }

    @Parameters({"data-set3"})
    @Test(dependsOnMethods = "tc010_02")
    public void tc010_03(@Optional("data/rates/TC010_Vanilla_ReviewI_Verify_the_right_click_functionalities_for_Removed_trades_from_Review1/TC010_03.xml") String dataSet) throws IOException, InterruptedException {
        RatesNoStepsDOM rates = new RatesNoStepsDOM(dataSet);

        RatesLoginPOM login = rates.getLoginPOM(getContext());
        login.login();

        RatesActiFlowPOM actiFlow = rates.getActiFlowPOM();

        actiFlow.selectBasket();

        RatesTaskEntry task = actiFlow.getTaskByAdviceId(adviceId);
        task.doAction();
    }

    @Parameters({"data-set4"})
    @Test(dependsOnMethods = "tc010_03")
    public void tc010_04(@Optional("data/rates/TC010_Vanilla_ReviewI_Verify_the_right_click_functionalities_for_Removed_trades_from_Review1/TC010_04.xml") String dataSet) throws IOException, InterruptedException {
        RatesNoStepsDOM rates = new RatesNoStepsDOM(dataSet);

        RatesLoginPOM login = rates.getLoginPOM(getContext());
        login.login();

        RatesActiFlowPOM actiFlow = rates.getActiFlowPOM();

        actiFlow.selectBasket();

        RatesTaskEntry task = actiFlow.getTaskByAdviceId(adviceId);
        task.doAction();
    }


    @Parameters({"data-set5"})
    @Test(dependsOnMethods = "tc010_04")
    public void tc010_05(@Optional("data/rates/TC010_Vanilla_ReviewI_Verify_the_right_click_functionalities_for_Removed_trades_from_Review1/TC010_05.xml") String dataSet) throws IOException, InterruptedException {
        RatesNoStepsDOM rates = new RatesNoStepsDOM(dataSet);

        RatesLoginPOM login = rates.getLoginPOM(getContext());
        login.login();

        RatesActiFlowPOM actiFlow = rates.getActiFlowPOM();

        actiFlow.selectBasket();

        RatesTaskEntry task = actiFlow.getTaskByAdviceId(adviceId);
        task.doAction();
    }

    @Parameters({"data-set6"})
    @Test(dependsOnMethods = "tc010_05")
    public void tc010_06(@Optional("data/rates/TC010_Vanilla_ReviewI_Verify_the_right_click_functionalities_for_Removed_trades_from_Review1/TC010_06.xml") String dataSet) throws IOException, InterruptedException {
        RatesNoStepsDOM rates = new RatesNoStepsDOM(dataSet);

        RatesLoginPOM login = rates.getLoginPOM(getContext());
        login.login();

        RatesActiFlowPOM actiFlow = rates.getActiFlowPOM();

        actiFlow.selectBasket();

        RatesTaskEntry task = actiFlow.getTaskByAdviceId(adviceId);
        task.doAction();
    }


    @Parameters({"data-set7"})
    @Test(dependsOnMethods = "tc010_06")
    public void tc010_07(@Optional("data/rates/TC010_Vanilla_ReviewI_Verify_the_right_click_functionalities_for_Removed_trades_from_Review1/TC010_07.xml") String dataSet) throws IOException, InterruptedException {
        RatesNoStepsDOM rates = new RatesNoStepsDOM(dataSet);

        RatesLoginPOM login = rates.getLoginPOM(getContext());
        login.login();

        RatesActiFlowPOM actiFlow = rates.getActiFlowPOM();
        actiFlow.selectBasket();

        RatesTaskEntry task = actiFlow.getTaskByAdviceId(adviceId);
        task.validateActions();
        task.doAction();
        actiFlow.validateTaskRemoval(adviceId);

        RatesFileCabinetPOM fileCabinetPOM = actiFlow.getFileCabinetPOM();
        fileCabinetPOM.searchForDocument("Advice Id :" + adviceId);
        RatesDocumentEntry documentEntry = fileCabinetPOM.getDocument(0);
        Assertions.assertThat(documentEntry.getProperty(RatesDocumentProperty.StatusCode)).isEqualTo("Removed");
    }
}
