package com.rbccm.taf.rates.components;

import com.rbccm.taf.rates.pageobjects.*;
import com.rbccm.taf.ui.support.TestContext;
import com.rbccm.taf.ui.support.WebDriverTypeEnum;
import com.rbccm.taf.ui.testng.TestNGBase;
import com.rbccm.taf.ui.utils.Helper;
import datainstiller.data.Data;
import org.assertj.core.api.Assertions;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.Step;

import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

public class RatesTaskEntry {
    private String expectedActions;
    private String actionToPerform;
    private String expectedSuccessMessage;
    @Data(skip = true)
    private String adviceId;
    RatesChangeEmailFaxPOM changeEmailFaxPOM;
    RatesSendToPOM sendToPOM;
    RatesAnnotationsPOM annotationsPOM;
    RatesDocumentAttributesPOM documentAttributesPOM;
    RatesWorkFlowStatusPOM workFlowStatusPOM;

    public RatesTaskEntry(){}
    public RatesTaskEntry(String adviceId) {
        init(adviceId);
    }

    public void init(String adviceId) {
        this.adviceId = adviceId;
    }

    private WebElement getCoreElement() {
        By by = By.xpath("//div[@kendo-grid='taskGrid']//table[@data-role]//span[.='" + adviceId + "']/../..");
        return Helper.getWebDriver().findElement(by);
    }

    public String getExpectedActions() {
        return expectedActions;
    }

    public String getActionToPerform() {
        return actionToPerform;
    }

    public String getExpectedSuccessMessage() {
        return expectedSuccessMessage;
    }

    public String getAdviceId() {
        return getProperty(RatesTaskProperty.AdviceID);
    }

    public String getProperty(RatesTaskProperty property) {
        if (property.equals(RatesTaskProperty.Selected)) {
            boolean selected = getCoreElement().findElement(By.xpath("./td[" + (property.ordinal() + 1) + "]//input[@type='checkbox']")).isSelected();
            return selected ? "Yes" : "No";
        }
        return getCoreElement().findElement(By.xpath("./td[" + (property.ordinal() + 1) + "]")).getText();
    }

    private WebElement getMenu() {
        By menuBy = By.cssSelector("div.k-animation-container ul[data-role=contextmenu]");
        WebElement element = getCoreElement().findElement(By.xpath(".//span[contains(.,'" + adviceId + "')]"));
        List<WebElement> menu = TestNGBase.CONTEXT().getDriver().findElements(menuBy);
        if (!menu.isEmpty() && menu.get(0).isDisplayed()) {
            return menu.get(0);
        }else {
            Actions a = new Actions(TestNGBase.CONTEXT().getDriver());
            a.contextClick(element).build().perform();
            WebElement menuEl = Helper.waitToShow(menuBy);
            Helper.sleep(200); //Wait for menu animation to complete
            return menuEl;
        }
    }

    public void doAction()  {
        performAction(actionToPerform);
        if (RatesTaskAction.OpenTradeDocuments.action.equals(actionToPerform)){
            WebElement ele=TestNGBase.CONTEXT().getDriver().findElement(By.cssSelector("#TradeDocumentsModal_wnd_title"));
            if(ele.isDisplayed()) {
                String title = ele.getText();
                assertThat(title).isEqualTo("Trade documents");
                WebElement webElement=TestNGBase.CONTEXT().getDriver().findElement(By.xpath("//*[@id='TradeDocumentsModal_wnd_title']//following::div[1]//span[text()='Close']"));
                webElement.click();
            }
        }

        if (RatesTaskAction.Compare.action.equals(actionToPerform)){
            WebElement ele=TestNGBase.CONTEXT().getDriver().findElement(By.cssSelector("#CompareRelatedDocumentsListModal [ng-click='compare()']"));
            if(ele.isDisplayed()) {
                String title = ele.getText();
                assertThat(title).isEqualTo("Compare");
                WebElement webElement=TestNGBase.CONTEXT().getDriver().findElement(By.xpath("//*[@id='CompareRelatedDocumentsListModal_wnd_title']//following::div[1]//span[text()='Close']"));
                webElement.click();
            }
        }

        if (RatesTaskAction.ShowDocumentAttributes.action.equals(actionToPerform)){
            documentAttributesPOM.initPage(TestNGBase.CONTEXT());
            documentAttributesPOM.validateDocumentAttributes();
            Helper.sleep(200);
        }

        if (RatesTaskAction.ShowWorkflowStatus.action.equals(actionToPerform)) {
            workFlowStatusPOM.initPage(TestNGBase.CONTEXT());
            workFlowStatusPOM.validateWorkFlowStatus();
            Helper.sleep(200);
        }
        if (RatesTaskAction.ShowAnnotations.action.equals(actionToPerform)){
            annotationsPOM.initPage(TestNGBase.CONTEXT());
            annotationsPOM.addAnnotation();
            if (expectedSuccessMessage != null) {
                validateSuccessMessage(expectedSuccessMessage);
            }
            annotationsPOM.closeAnnotation();
        }
        if (RatesTaskAction.ForwardForReview.action.equals(actionToPerform)) {
            sendToPOM.initPage(TestNGBase.CONTEXT());
            sendToPOM.send();
            if (expectedSuccessMessage != null) {
                validateSuccessMessage(expectedSuccessMessage);
            }
        } else if(RatesTaskAction.ChangeEmailFax.action.equals(actionToPerform)) {
            changeEmailFaxPOM.initPage(TestNGBase.CONTEXT());
            changeEmailFaxPOM.setNewEmailFax();
            if (expectedSuccessMessage != null) {
                validateSuccessMessage(expectedSuccessMessage);
            }
            validateFaxEmail(changeEmailFaxPOM.getEmailFaxValue());
        }  else {
            if (expectedSuccessMessage != null) {
                validateSuccessMessage(expectedSuccessMessage);
            }
        }
    }

    @Step("Validate 'Cpty Email Or Fax' field is set to {0}")
    private void validateFaxEmail(String expectedValue) {
        Assertions.assertThat(this.getProperty(RatesTaskProperty.CptyEmailOrFax)).isEqualTo(expectedValue);
    }

    @Step("Select \"{0}\" option from the pop-up menu")
    private void performAction(String action)  {
        List<WebElement> menuItems = getMenu().findElements(By.xpath(".//a[contains(.,'" + action + "')]"));
        Assertions.assertThat(menuItems).withFailMessage("Action item: '" + action + "' was not found for advice Id:" + adviceId).isNotEmpty();
        boolean clicked = false;
        for (WebElement item : menuItems) {
            if (item.isDisplayed()) {
                clicked = true;
                item.click();
                boolean isFromReview1 = getProperty(RatesTaskProperty.Comment).contains("From Review 1");
                if (RatesTaskAction.RemoveFromWorkFlow.action.equals(action) && isFromReview1) {
                    Helper.getFluentWait().until(ExpectedConditions.alertIsPresent());
                    Alert alert = TestNGBase.CONTEXT().getDriver().switchTo().alert();
                    alert.accept();
                }
                //There is a IE problem: The context menu is still visible after selecting menu items on
                // so this block of code is needed to close the context menu.
                if(TestContext.getTestProperties().getBrowserType().equals(WebDriverTypeEnum.IE)) {
                    item.sendKeys(Keys.ESCAPE);

                }
                Helper.waitForXHR();
            }
        }
        Assertions.assertThat(clicked).withFailMessage("Action item: '" + action + "' was not found for advice Id:" + adviceId).isTrue();
    }


    public void validateActions() {
        if (expectedActions != null) {
            validateExpectedActions();
        }
    }

    @Step("Right click the task and validate that the pop-up menu contains expected action options")
    private void validateExpectedActions() {
        List<String> actualList = new ArrayList<>();
        String[] expected = expectedActions.split(",");
        for (int i = 0; i < expected.length; i++) {
            expected[i] = expected[i].trim();
            stepForReport(expected[i], i+1);
        }
        String[] actual = getMenu().getText().split("\n");
        for (String s : actual) {
            actualList.add(s.trim());
        }
        Assertions.assertThat(actualList).containsExactlyInAnyOrder(expected);
    }

    @Step("Expected pop-up menu option #{1} - \"{0}\"")
    private void stepForReport(String option, int i){}

    @Step("Validate action success message is \"{0}\"")
    public void validateSuccessMessage(String message) {
        WebElement successMessage = Helper.waitToShow(By.cssSelector("#toast-container .toast-success"));
        Assertions.assertThat(successMessage.getText()).contains(message);
    }

    @Step("Double click on a trade and verify the alert message")
    public void doubleClick(String adviceId) {

        WebElement element = getCoreElement().findElement(By.xpath(".//span[contains(.,'" + adviceId + "')]"));
        Actions action = new Actions(TestNGBase.CONTEXT().getDriver());
        action.moveToElement(element).doubleClick().build().perform();

        Helper.getFluentWait().until(ExpectedConditions.alertIsPresent());
        Alert alert = TestNGBase.CONTEXT().getDriver().switchTo().alert();
        String alertText=alert.getText();
        alert.accept();
        Assertions.assertThat(alertText).isEqualTo("You are not authorized to execute this task");

    }
}
