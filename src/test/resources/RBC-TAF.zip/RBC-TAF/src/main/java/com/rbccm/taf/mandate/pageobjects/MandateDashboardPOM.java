package com.rbccm.taf.mandate.pageobjects;

import com.rbccm.taf.ui.support.PageObjectModel;
import com.rbccm.taf.ui.support.TestContext;
import org.assertj.core.api.Assertions;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import ru.yandex.qatools.allure.annotations.Step;
import ui.auto.core.components.WebComponent;
import ui.auto.core.context.PageComponentContext;

public class MandateDashboardPOM extends PageObjectModel {
    @FindBy(css = "button#mandateTemplate")
    private WebComponent newButton;
    @FindBy(css = "input#positionTitleId")
    private WebComponent positionTitle;
    @FindBy(xpath = "//div[@id='newMandatePositionDiv'] //button[.='Okay']")
    private WebComponent okayButton;

    public MandateDashboardPOM(PageComponentContext context) {
        initPage(context);
    }

    @Step("{1} mandate for \"{0}\"")
    public void getMandateForUser(String userDisplayName, String expectedAction) {
        By userActionButton = By.xpath(String.format("//td[.='%s']/..//button", userDisplayName));
        WebElement action = getDriver().findElement(userActionButton);
        Assertions.assertThat(action.getText()).isEqualTo(expectedAction);
        action.click();
        waitForUrl("activiti-tasks#/tasks?taskId");
    }

    @Step("Create new job mandate template")
    public void createMandateForManager() {
        newButton.click();
        setElementValue(positionTitle, TestContext.getGlobalAliases().get("time-stamp"));
        okayButton.click();
        waitForUrlToChange();
    }

}
