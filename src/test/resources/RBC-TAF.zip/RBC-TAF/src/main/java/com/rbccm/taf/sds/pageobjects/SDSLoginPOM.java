package com.rbccm.taf.sds.pageobjects;

import com.rbccm.taf.ui.support.AliasedString;
import com.rbccm.taf.ui.support.PageObjectModel;
import com.rbccm.taf.ui.utils.Helper;
import datainstiller.data.Data;
import org.openqa.selenium.support.FindBy;
import ru.yandex.qatools.allure.annotations.Step;
import ui.auto.core.components.WebComponent;
import ui.auto.core.pagecomponent.SkipAutoFill;

/**
 * Created by subdas on 12/07/2017.
 */
public class SDSLoginPOM extends PageObjectModel {
    @Data(alias = "url")
    @SkipAutoFill
    AliasedString url;
    @FindBy(id = "username")
    @Data(alias = "username")
    private WebComponent username;
    @Data(alias = "password")
    @FindBy(id = "password")
    private WebComponent password;
    @Data(skip = true)
    @FindBy(id = "login-button")
    private WebComponent loginButton;

    public void setDataValues(String urlS, String user, String paswd) {
        url = new AliasedString();
        url.initializeData(urlS, null, null);
        username = new WebComponent();
        username.initializeData(user, null, null);
        password = new WebComponent();
        password.initializeData(paswd, null, null);
    }

    @Step("Navigating to SDS application")
    public void navigate() {
        getDriver().get(url.getData());
        //TestNGBase.takeScreenshot("LOGIN PAGE");
    }

    @Step("login to SDS Application with valid username and password")
    public void login() {
        // #1 Approach
        //username.setValue();
        //password.setValue();
        // #2 Approach
        //setElementValue(username);
        //setElementValue(password);
        // #3 Approach
        autoFillPage();

        loginButton.click();
        Helper.waitForXHR();
        //login(username.getData(), password.getData());
    }

    @Step("Login using user {0} and password {1}")
    private void login(String user, String password) {
        setElementValue(username, user);
        setElementValue(this.password, password);
        loginButton.click();
        Helper.waitForXHR();
    }


}
