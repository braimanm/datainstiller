package com.rbccm.taf.rates.tests.perf;

import com.rbccm.taf.rates.api.RatesSession;
import com.rbccm.taf.ui.support.EnvironmentsSetup;
import com.rbccm.taf.ui.support.TestContext;
import com.rbccm.taf.ui.testng.TestNGBase;
import org.assertj.core.api.Assertions;
import org.testng.annotations.Test;

import java.io.IOException;

public class UserTest extends TestNGBase{

    @Test
    public void testAccounts() throws IOException, InterruptedException {
        EnvironmentsSetup setup = new EnvironmentsSetup().fromResource("data/rates/environments.xml");
        EnvironmentsSetup.Environment env = setup.getEnvironment("any");
        String url = "https://mrkdlvaiaas933.devfg.rbc.com:8040";
        StringBuilder log = new StringBuilder();

        for (EnvironmentsSetup.User user : env.getUsers()) {
            String role = user.getRole();
            if (role.equals("ssh") || role.endsWith("-0")) continue;
            String u = user.getUserName();
            String p = user.getPassword();
            try {
                new RatesSession(url, u, p);
            } catch (Exception e) {
                log.append("USER: ").append(u).append("  PSWD: ").append(p).append("  ");
                log.append(e.getLocalizedMessage()).append("\n");
            }
        }
        Assertions.assertThat(log.length()).withFailMessage("\n"+log.toString()).isEqualTo(0);

    }
}
