package com.rbccm.taf.rates.pageobjects;

import com.rbccm.taf.ui.support.AliasedString;
import com.rbccm.taf.ui.support.PageObjectModel;
import com.rbccm.taf.ui.utils.Helper;
import datainstiller.data.Data;
import org.openqa.selenium.By;
import org.openqa.selenium.support.FindBy;
import ru.yandex.qatools.allure.annotations.Step;
import ui.auto.core.components.CheckBox;
import ui.auto.core.components.WebComponent;

import java.util.List;

public class RatesSendToPOM extends PageObjectModel {
    @FindBy(xpath = "//td[contains(.,'Trader Review')]/..//input")
    CheckBox traderReview;
    @FindBy(xpath = "//td[contains(.,'SPBS Review')]/..//input")
    CheckBox spbsReview;
    @Data(skip = true)
    @FindBy(css = "button[ng-click='send()']")
    WebComponent sendButton;
    List<String> users;
    @Data(skip = true)
    @FindBy(css = "#mulActionUserModal")
    WebComponent selectUserPanel;
    @Data(skip = true)
    @FindBy(css = "button[ng-click='sendUsers()']")
    WebComponent sendUsers;

    public void send() {
        if (traderReview.getData() != null) selectTraderReview();
        if (spbsReview.getData() != null) selectSPBSReview();
        sendButton.click();
        Helper.waitForXHR();
        for (String user : users) {
            selectUser(user);
        }
        sendUsers.click();
        Helper.waitForXHR();
    }

    @Step("Select \"Trader Review\"")
    private void selectTraderReview() {
        setElementValue(traderReview);
    }

    @Step("Select \"SPBS Review\"")
    private void selectSPBSReview() {
        setElementValue(spbsReview);
    }


    @Step("Select user \"{0}\"")
    private void selectUser(String user) {
        By byUser = By.xpath("//div[@id='mulActionUserModal']//td[contains(.,'" + user + "')]/..//input");
        selectUserPanel.findElement(byUser).click();
    }

}
