package com.rbccm.taf.mandate.domainobjects;

import com.rbccm.taf.mandate.api.EmployeeMandate;
import com.rbccm.taf.mandate.pageobjects.MandateDashboardPOM;
import com.rbccm.taf.mandate.pageobjects.MandateFormPOM;
import com.rbccm.taf.mandate.pageobjects.MandateLoginPOM;
import com.rbccm.taf.sit.components.SITMenuButton;
import com.rbccm.taf.ui.support.DomainObjectModel;
import com.rbccm.taf.ui.support.EnvironmentsSetup;
import com.rbccm.taf.ui.support.TestContext;
import com.rbccm.taf.ui.utils.Helper;
import com.thoughtworks.xstream.annotations.XStreamAlias;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import ru.yandex.qatools.allure.annotations.Step;

@XStreamAlias("mandate-workflow")
public class MandateWorkflowDOM extends DomainObjectModel {
    MandateLoginPOM loginPOM;
    MandateFormPOM mandateFormPOM;

    public MandateWorkflowDOM() {}
    public MandateWorkflowDOM(TestContext context) {
        this.context = context;
    }

    @Step("Login as {0}")
    public MandateDashboardPOM login(String userRole) {
        EnvironmentsSetup.User user = TestContext.getTestProperties().getTestEnvironment().getUser(userRole);
        loginPOM.initPage(getContext());
        return loginPOM.login(user.getUserName(), user.getPassword());
    }

    public MandateDashboardPOM login() {
        loginPOM.initPage(getContext());
        return loginPOM.login();
    }

    public MandateDashboardPOM navigateToDashboard() {
        getDriver().get(loginPOM.url.getData() + "/site/rbc-mandate/dashboard");
        waitForUrlToChange();
        return new MandateDashboardPOM(getContext());
    }

    @Step("Delete mandate document for employee \"{0}\"")
    public void deleteDocumentFolderForUser(String userName) {
        EnvironmentsSetup.User user = TestContext.getTestProperties().getTestEnvironment().getUser("manager");
        String[] names = user.getFullName().split(" ");
        String manFull = names[1] + ", " + names[0];
        String url = TestContext.getTestProperties().getTestEnvironment().getUrl() + "/site/rbc-mandate/documentlibrary#filter=path|/Capital Markets/14175/" + manFull + "/Employee Job Mandates";
        getContext().getDriver().get(url);
        WebElement el = Helper.waitToShow(By.xpath("//a[.='" + userName + "']/../../../../..//input"));
        el.click();
        By by = By.xpath("//button[starts-with(.,'Selected Items')]");
        SITMenuButton menuButton = new SITMenuButton(getDriver().findElement(by));
        menuButton.setValue("Delete");
        el = Helper.waitToShow(By.xpath("//button[.='Delete']"));
        el.click();
        Helper.getWebDriiverWait().until(ExpectedConditions.invisibilityOf(el));
        EmployeeMandate.getEmployee("employee", userName).waitForWorkflowStatus("None on File");
    }

    public MandateFormPOM getMandateFormPOM() {
        mandateFormPOM.initPage(getContext());
        return mandateFormPOM;
    }
}
