package com.rbccm.taf.sit.domainobjects;

import com.rbccm.taf.sit.pageobjects.SITDocumentLibraryPOM;
import com.rbccm.taf.sit.pageobjects.SITLoginPOM;
import com.rbccm.taf.sit.pageobjects.SITNavigation;
import com.rbccm.taf.ui.support.DomainObjectModel;
import com.rbccm.taf.ui.support.TestContext;
import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("general-flow")
public class SITGeneralFlowDOM extends DomainObjectModel {
    private SITNavigation navigation;
    private SITLoginPOM loginPOM;
    private SITDocumentLibraryPOM documentLibraryPOM;

    public SITGeneralFlowDOM(){}
    public SITGeneralFlowDOM(TestContext context) {
        this.context = context;
    }

    public SITNavigation getNavigation() {
        navigation.initPage(getContext());
        return navigation;
    }

    public void login() {
        loginPOM.initPage(getContext());
        loginPOM.login();
    }

    public SITDocumentLibraryPOM getDocumentLibrary() {
        documentLibraryPOM.initPage(getContext());
        return documentLibraryPOM;
    }

}
