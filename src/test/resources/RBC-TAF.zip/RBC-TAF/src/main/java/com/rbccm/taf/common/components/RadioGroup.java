package com.rbccm.taf.common.components;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import ui.auto.core.data.DataTypes;
import ui.auto.core.pagecomponent.PageComponent;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

public class RadioGroup extends PageComponent {
    List<WebElement> radios;

    @Override
    protected void init() {
        radios = coreElement.findElements(By.cssSelector("input[type=radio]"));
    }

    @Override
    public void setValue() {
        for (WebElement el : radios) {
            String value = el.getAttribute("value");
            if (value != null && value.equalsIgnoreCase(getData())) {
                el.click();
                return;
            }
        }
        throw new RuntimeException("Radio button with value " +  getData() + "was not found!");
    }

    @Override
    public String getValue() {
        for (WebElement el : radios) {
            if (el.isSelected()) {
                return el.getAttribute("value");
            }
        }
        return null;
    }

    @Override
    public void validateData(DataTypes validationMethod) {
        assertThat(getValue()).isEqualToIgnoringCase(validationMethod.getData(this));
    }
}
