package com.rbccm.taf.rates.components;

import com.rbccm.taf.ui.testng.TestNGBase;
import com.rbccm.taf.ui.utils.Helper;
import datainstiller.data.Data;
import org.assertj.core.api.Assertions;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import java.util.List;

public class RatesDocumentEntry {
    @Data(skip = true)
    private WebElement coreElement;

    public RatesDocumentEntry(WebElement coreElement) {
        this.coreElement = coreElement;
    }

    private WebElement getMenu() {
        By menuBy = By.cssSelector("div.k-animation-container ul[data-role=contextmenu]");
        WebElement element = coreElement.findElement(By.xpath("./td[2]"));
        List<WebElement> menu = TestNGBase.CONTEXT().getDriver().findElements(menuBy);
        if (!menu.isEmpty() && menu.get(0).isDisplayed()) {
            return menu.get(0);
        }else {
            Actions a = new Actions(Helper.getWebDriver());
            a.contextClick(element).build().perform();
            WebElement menuEl = Helper.waitToShow(menuBy);
            Helper.sleep(200); //Wait for menu animation to complete
            return menuEl;
        }
    }

    public String getProperty(RatesDocumentProperty property) {
        return coreElement.findElement(By.xpath("./td[" + (property.ordinal() + 2) + "]")).getText();
    }

    public void doAction(RatesDocumentAction action) {
        WebElement menu = getMenu();
        List<WebElement> menuItems = menu.findElements(By.xpath(".//a[contains(.,'" + action.getAction() + "')]"));
        Assertions.assertThat(menuItems).withFailMessage("Action item: '" + action.getAction() + "' was not found!").isNotEmpty();
        boolean clicked = false;
        for (WebElement item : menuItems) {
            if (item.isDisplayed()) {
                clicked = true;
                item.click();
                Helper.waitForXHR();
            }
        }
        Assertions.assertThat(clicked).withFailMessage("Action item: '" + action.getAction() + "' was not found!").isTrue();
    }


}
