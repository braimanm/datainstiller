package com.rbccm.taf.commodities.pageobjects;


import com.rbccm.taf.ui.support.AliasedString;
import com.rbccm.taf.ui.support.PageObjectModel;
import com.rbccm.taf.ui.support.TestContext;
import com.rbccm.taf.ui.utils.Helper;
import datainstiller.data.Data;
import org.openqa.selenium.support.FindBy;
import ru.yandex.qatools.allure.annotations.Step;
import ui.auto.core.components.WebComponent;


public class CommoditiesLoginPOM extends PageObjectModel{
    public AliasedString url;
    @FindBy(name = "username")
    public WebComponent userName;
    @FindBy(name = "password")
    public WebComponent password;
    @Data(skip = true)
    @FindBy(css = "input[type=submit]")
    private WebComponent loginButton;


    public void login() {
        login(userName.getData(), password.getData());
    }

    @Step("Login to actiFlow with \"{0}\" user's credentials")
    public void login(String user, String pswrd) {
        getDriver().manage().deleteAllCookies();
        TestContext.getGlobalAliases().put("lastUrl", url.getData());
        TestContext.getGlobalAliases().put("lastUser", userName.getData());
        TestContext.getGlobalAliases().put("lastPswd", password.getData());
        getDriver().get(url.getData() + "/login");
        setElementValue(userName, user);
        setElementValue(password, pswrd);
        loginButton.click();
        if (!TestContext.getGlobalAliases().containsKey("first-login")) {
            TestContext.getGlobalAliases().put("first-login", "true");
        } else {
            Helper.waitForXHR();
        }

    }

}
