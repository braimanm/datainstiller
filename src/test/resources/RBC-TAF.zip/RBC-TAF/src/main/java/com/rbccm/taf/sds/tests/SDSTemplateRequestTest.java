package com.rbccm.taf.sds.tests;

import com.rbccm.taf.sds.domainobjects.SDSCreateRequestTemplateDOM;
import com.rbccm.taf.sds.pageobjects.SDSCreateNewRequestPOM;
import com.rbccm.taf.ui.support.TestContext;
import com.rbccm.taf.ui.testng.TestNGBase;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.Description;
import ru.yandex.qatools.allure.annotations.Features;

public class SDSTemplateRequestTest extends TestNGBase {


    @Description("This test is for creating request with Template")
    @Features({"Create request", "validate pre-filled data", "complete request", "search newly created request and validate the fields"})
    @Parameters("data-set")
    @Test
    public void newRequestWithTemplate(@Optional("data/sds/templateDataSets/srdr_template_request_data.xml") String dataSet) {
        SDSCreateRequestTemplateDOM createNewRequestDOM = new SDSCreateRequestTemplateDOM(getContext()).fromResource(dataSet);
        createNewRequestDOM.login();
        SDSCreateNewRequestPOM newRequest = createNewRequestDOM.getNewRequest();
        newRequest.fillTemplateAndValidate();
        newRequest.submitRequestAndValidateMessage();
        newRequest.searchNewCreatedRequest();
        newRequest.validateTemplateRequestData();
    }

    @Description("This test is to approve a request")
    @Features({"Create request", "Fill required fields", "Validate field's data", "Complete request", "Search newly created request", "Validate the fields", "Approve request"})
    @Parameters("data-set")
    @Test
    public void approveRequest(@Optional("data/sds/approve_request_data.xml") String dataSet) {
        SDSCreateRequestTemplateDOM createNewRequestDOM = new SDSCreateRequestTemplateDOM(getContext()).fromResource(dataSet);
        createNewRequestDOM.login();
        SDSCreateNewRequestPOM newRequest = createNewRequestDOM.getNewRequest();
        newRequest.fillWorkBasketAndValidate();
        newRequest.submitRequestAndValidateMessage();
        newRequest.searchNewCreatedRequest();
        newRequest.validateWorkBasketRequestData();
        newRequest.completeRequest();
        newRequest.validateWorkStatus();
    }

    @Description("This test is to cancel a request")
    @Features({"Create request", "Fill required fields", "Validate field's data", "Complete request", "Search newly created request", "Validate the fields", "Cancel Request"})
    @Parameters("data-set")
    @Test
    public void cancelRequest(@Optional("data/sds/cancel_request_data.xml") String dataSet) {
        SDSCreateRequestTemplateDOM createNewRequestDOM = new SDSCreateRequestTemplateDOM(getContext()).fromResource(dataSet);
        createNewRequestDOM.login();
        SDSCreateNewRequestPOM newRequest = createNewRequestDOM.getNewRequest();
        newRequest.fillWorkBasketAndValidate();
        newRequest.submitRequestAndValidateMessage();
        newRequest.searchNewCreatedRequest();
        newRequest.validateWorkBasketRequestData();
        newRequest.cancelRequest();
        newRequest.validateWorkStatus();
    }


    @Description("This test is to duplicate a request")
    @Features({"Create request", "Fill required fields", "Validate field's data", "Complete request", "Search newly created request", "Validate the fields", "Duplicate Request"})
    @Parameters("data-set")
    @Test
    public void duplicateRequest(@Optional("data/sds/duplicate_request_data.xml") String dataSet) {
        SDSCreateRequestTemplateDOM createNewRequestDOM = new SDSCreateRequestTemplateDOM(getContext()).fromResource(dataSet);
        createNewRequestDOM.login();
        SDSCreateNewRequestPOM newRequest = createNewRequestDOM.getNewRequest();
        newRequest.fillWorkBasketAndValidate();
        newRequest.submitRequestAndValidateMessage();
        String reqId = TestContext.getGlobalAliases().get("request-id");
        newRequest = createNewRequestDOM.getNewRequest();
        newRequest.fillWorkBasketAndValidate();
        newRequest.submitRequestAndValidateMessage();
        String reqId2 = TestContext.getGlobalAliases().get("request-id");
        newRequest.resolveDuplicate(reqId, reqId2);

    }

}
