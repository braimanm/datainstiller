package com.rbccm.taf.rlm.pageobjects;

import com.rbccm.taf.rlm.components.RLMRadioGroup;
import com.rbccm.taf.rlm.components.RLMSelect;
import com.rbccm.taf.ui.support.PageObjectModel;
import com.rbccm.taf.ui.utils.Helper;
import datainstiller.data.Data;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import ru.yandex.qatools.allure.annotations.Step;
import ui.auto.core.components.WebComponent;
import ui.auto.core.data.DataTypes;
import ui.auto.core.pagecomponent.PageComponent;

import static org.assertj.core.api.Assertions.assertThat;

@SuppressWarnings("unused")
public class RLMFidessaFormPOM extends PageObjectModel {
    @Data(alias = "fidessa-accountType")
    @FindBy(id = "fidessaaccounttype")
    private RLMRadioGroup accountType;
    @Data(alias = "fidessa-clientName")
    @FindBy(id ="fidessacounterpartyorclientname")
    private WebComponent clientName;
    @Data(alias = "fidessa-traderName")
    @FindBy(id = "fidessatradername")
    private WebComponent traderName;
    @Data(alias = "fidessa-typeOfChange")
    @FindBy(id = "fidessatypeofchange")
    private RLMSelect typeOfChange;
    @Data(alias = "fidessa-priceToleranceSoftWarningRange")
    @FindBy(id = "fidessapricetolerancesoftwarningrange")
    private RLMSelect priceToleranceSoftWarningRange;
    @Data(alias = "fidessa-systemPriceToleranceRange")
    @FindBy(id ="fidessasystempricetolerancesettingsrange")
    private RLMSelect systemPriceToleranceRange;
    @Data(alias = "fidessa-existingLimit")
    @FindBy(id = "fidessaexistinglimit")
    private WebComponent existingLimit;
    @Data(alias = "fidessa-newLimit")
    @FindBy(id = "fidessanewlimit")
    private WebComponent newLimit;
    @Data(alias = "fidessa-durationType")
    @FindBy(id = "fidessadurationtype")
    private RLMRadioGroup durationType;
    @Data(alias = "fidessa-expireDate")
    @FindBy(id = "fidessaexpiredate")
    private WebComponent expireDate;
    @Data(alias = "fidessa-expireHour")
    @FindBy(id = "fidessaexpirehour")
    private RLMSelect expireHour;
    @Data(alias = "fidessa-expireMinute")
    @FindBy(id = "fidessaexpireminute")
    private RLMSelect expireMinute;
    @Data(alias = "fidessa-amOrPM")
    @FindBy(id = "fidessaamorpm")
    private RLMSelect amOrPm;

    //Fields for Form Validation
    @Data(skip = true)
    @FindAll({
            @FindBy(id = "fidessarequestfor"),
            @FindBy(id = "fidessaapplicant")
    })
    private WebComponent valRequestFor;
    @Data(skip = true)
    @FindBy(id = "fidessatypeofchange")
    private WebComponent valTypeOfChange;
    @Data(skip = true)
    @FindBy(id = "fidessadurationtype")
    private WebComponent valDurationType;
    @Data(skip = true)
    @FindBy(id = "fidessaexpirydate")
    private WebComponent valExpiryDate;
    @Data(skip = true)
    @FindBy(id = "fidessaexistinglimit")
    private WebComponent valExistingLimit;
    @Data(skip = true)
    @FindBy(id = "fidessanewlimit")
    private WebComponent valNewLimit;


    @Step("Populate FIDESSA Request Form with provided data")
    void fill() {
        autoFillPage();
    }

    @Step("Validate FIDESSA Request Form")
    public void validate() {
        String requestFor = "request for:";
        if (valRequestFor.getAttribute("id").contains("applicant")) {
            requestFor = "applicant";
        }
        if (isDataProvided(clientName)) {
            validateComponentValue(valRequestFor, clientName.getData(), "Fidessa " + requestFor);
        } else if (isDataProvided(traderName)) {
            validateComponentValue(valRequestFor, traderName.getData(), "Fidessa " + requestFor);
        }
        if (isDataProvided(typeOfChange)) {
            validateComponentValue(valTypeOfChange, typeOfChange.getData(), "Fidessa Type of Change");
        }
        if (isDataProvided(durationType)) {
            validateComponentValue(valDurationType, durationType.getData(), "Fidessa Duration Type");
        }
        if (isDataProvided(existingLimit)) {
            validateComponentValue(valExistingLimit, existingLimit.getData(), "Fidessa Existing limit");
        }
        if (isDataProvided(newLimit)) {
            validateComponentValue(valNewLimit, newLimit.getData(), "Fidessa New Limit");
        }
        if (isDataProvided(expireDate)) {
            String expiryDateData = expireDate.getData() + " " + expireHour.getData() + ":" +
                    expireMinute.getData() + " " + amOrPm.getData();
            String data = Helper.convertDate("d-M-yyyy hh:mm a", "yyyy-MM-dd hh:mm a", expiryDateData);
            validateComponentValue(valExpiryDate, data, "Fidessa Expiry Date");
        }
    }

    private boolean isDataProvided(PageComponent component) {
        return (component.getData() != null && !component.getData().isEmpty());
    }

    @Step("Validating field \"{2}\" has a value of \"{1}\"")
    private void validateComponentValue(PageComponent component, String data, String field) {
        if (data != null && !data.isEmpty()) {
            assertThat(component.getValue()).isEqualToIgnoringCase(data);
        }
    }

    @Step("Validate default Fidessa fields values")
    public void validateInitialValues() {
        autoValidatePage(DataTypes.Initial);
    }
}
