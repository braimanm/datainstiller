package com.rbccm.taf.mandate.api;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rbccm.taf.common.api.AlfrescoApiBase;
import com.rbccm.taf.ui.support.EnvironmentsSetup;
import com.rbccm.taf.ui.support.TestContext;
import com.rbccm.taf.ui.utils.Helper;
import org.apache.http.client.utils.URIBuilder;
import org.assertj.core.api.Assertions;
import org.jsoup.Connection;
import org.jsoup.nodes.Document;
import java.io.IOException;
import java.net.URISyntaxException;

@JsonIgnoreProperties(ignoreUnknown=true)
public class EmployeeMandate {
     public String displayName;
     public String workflowStatus;
     public String employeeNumber;
     public String taskId;
     public String nodeRef;
     public String userRole;

     public static EmployeeMandate[] getEmployees(String userRole)  {
         EnvironmentsSetup.Environment env = TestContext.getTestProperties().getTestEnvironment();
         EnvironmentsSetup.User user = env.getUser(userRole);
         String urlBase;
         try {
             URIBuilder uriBuilder = new URIBuilder(env.getUrl());
             urlBase = uriBuilder.setPath("").build().toString();
         } catch (URISyntaxException e) {
             throw new RuntimeException(e);
         }
         AlfrescoApiBase api = new AlfrescoApiBase(urlBase);
         Connection con = null;
         EmployeeMandate[] employeeMandates = null;
         try {
             con = api.getAlfrescoConnection("/alfresco/s/com/microstrat/rbc/getEmployees", user.getUserName(), user.getPassword());
             con.method(Connection.Method.GET);
             Connection.Response res = con.execute();
             Document doc = res.parse();
             ObjectMapper mapper = new ObjectMapper();
             employeeMandates = mapper.readValue(doc.body().text(), EmployeeMandate[].class);
         } catch (IOException e) {
             e.printStackTrace();
         }
         if (employeeMandates != null) {
             for (EmployeeMandate employeeMandate : employeeMandates) {
                 employeeMandate.userRole = userRole;
             }
         }
          return employeeMandates;
     }

     public static EmployeeMandate getEmployee (String userRole, String displayName)  {
        EmployeeMandate[] employeeMandates = getEmployees(userRole);
        for (EmployeeMandate employeeMandate : employeeMandates) {
            if (employeeMandate.displayName.equals(displayName)) {
                return employeeMandate;
            }
        }
        return null;
     }

     public void waitForWorkflowStatus(String status) {
         EmployeeMandate employeeMandate = null;
         long t_o = System.currentTimeMillis() + 60000;
         boolean done = false;
         do {
             employeeMandate = getEmployee(userRole, displayName);
             if (employeeMandate != null && employeeMandate.workflowStatus.equals(status)) {
                 done = true;
             } else {
                 Helper.sleep(500);
             }
         } while (System.currentTimeMillis() < t_o && !done);
         if (!done) {
             Assertions.assertThat(employeeMandate.workflowStatus).isEqualTo(status);
         }
     }

}
