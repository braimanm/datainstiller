package com.rbccm.taf.sds.components;


import ui.auto.core.components.SelectComponent;

public class SDSSelect extends SelectComponent {

    @Override
    public void setValue() {
        selectByValue();
    }

    @Override
    public String getValue() {
        return getSelectElement().getFirstSelectedOption().getAttribute("value");
    }
}
