package com.rbccm.taf.rates.components;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("action")
public enum RatesTaskAction {
    ReturnToReview1("Return to Review I"),
    ForwardToReview2("Forward To Review II"),
    ForwardToRemove("Forward to Remove"),
    ClaimAsNegotiator("Claim as Negotiator"),
    Compare("Compare"),
    ShowAnnotations("Show Annotations"),
    ChangeEmailFax("Change Email/Fax"),
    ShowDocumentAttributes("Show Document Attributes"),
    ShowWorkflowStatus("Show Workflow Status"),
    OpenTradeDocuments("Open Trade Documents"),
    StartConfirmationTracking("Start Confirmation Tracking"),
    ApproveSendToCounterparty("Approve - Send to Counterparty"),
    ForwardForReview("Forward For Review"),
    Withdraw("Withdraw"),
    ShowReviewers("Show Reviewers"),
    UpdateReviewers("Update Reviewers"),
    RemoveFromWorkFlow("Remove from Workflow");
    String action;

    RatesTaskAction(String action) {
        this.action = action;
    }

    public String getAction() {
        return action;
    }
}
