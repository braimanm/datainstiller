package com.rbccm.taf.rlm.tests;

import com.rbccm.taf.rlm.domainobjects.RLMCreateRequestFullCycleDOM;
import com.rbccm.taf.rlm.pageobjects.RLMAuditTrailPOM;
import com.rbccm.taf.rlm.pageobjects.RLMDashBoardPOM;
import com.rbccm.taf.rlm.pageobjects.RLMLoginPOM;
import com.rbccm.taf.rlm.pageobjects.RLMRequestFormPOM;
import com.rbccm.taf.ui.testng.TestNGBase;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.*;
import ru.yandex.qatools.allure.model.SeverityLevel;

public class RLMCreatePreApprovedTest extends TestNGBase {

    @Parameters("request-data-set")
    @Features("Create Request Full Flow")
    @Severity(SeverityLevel.CRITICAL)
    @Test
    public void createAutoApprovedRequest(@Optional("data/rlm/us/create_perm_request_email_auto_approve_data.xml") String dataSet) {
        // Trader Non-Approver
        RLMCreateRequestFullCycleDOM requestDOM = new RLMCreateRequestFullCycleDOM(getContext()).fromResource(dataSet);
        RLMLoginPOM loginPOM = requestDOM.getLoginPOM(0);
        loginPOM.navigate();
        loginPOM.login();
        RLMDashBoardPOM dashBoardPOM = new RLMDashBoardPOM();
        RLMRequestFormPOM requestFormPOM = requestDOM.getRequestFormPOM();
        requestFormPOM.navigateToRequestForm();
        requestFormPOM.selectTradingSystems();
        requestFormPOM.valiadteSelectedTradingSystemsTabs();
        requestFormPOM.populateTradingSystemsRequestForms();
        requestFormPOM.completeAndValidateResponse();
        requestFormPOM.valiadateAutoApprovedEmail("requestor");

        // Auto Approved
        String useEmail = getContext().getAlias("approver-action-use-email").toLowerCase();
        String approverAction;
        loginPOM = requestDOM.getLoginPOM(1);
        requestFormPOM.valiadateAutoApprovedEmail("approver");
        requestFormPOM.valiadateAutoApprovedEmail("trade support");

        // Implementor
        loginPOM = requestDOM.getLoginPOM(2);
        loginPOM.navigate();
        loginPOM.login();
        dashBoardPOM.waitForPendingRequestsToUpdate();
        dashBoardPOM.validateRequestStatusByReqId(getContext().getAlias("request-id"), "New");
        dashBoardPOM.selectPendingRequestByReqID(getContext().getAlias("request-id"));
        requestFormPOM.validateTradingSystemsRequestForms();
        requestFormPOM.implement();

        // Audit Trail
        dashBoardPOM.selectAuditTrailForReqId(getContext().getAlias("request-id"));
        RLMAuditTrailPOM auditTrailPOM = requestDOM.getAuditTrailPom();
        auditTrailPOM.validateNew();
        auditTrailPOM.validateChangeComplete();


    }

}
