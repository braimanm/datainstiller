package com.rbccm.taf.commodities.pageobjects;

import com.rbccm.taf.ui.support.PageObjectModel;
import com.rbccm.taf.ui.utils.Helper;
import datainstiller.data.Data;
import org.openqa.selenium.support.FindBy;
import ru.yandex.qatools.allure.annotations.Step;
import ui.auto.core.components.WebComponent;

public class CommoditiesChangeEmailFaxPOM extends PageObjectModel {
    @Data(skip = true)
    @FindBy(css = "#worklist-change-email-fax #txtCurrent")
    WebComponent currentEmailFax;
    @FindBy(css = "#worklist-change-email-fax #txtNew")
    WebComponent newEmailFax;
    @Data(skip = true)
    @FindBy(css = "#worklist-change-email-fax button[ng-click^=ok]")
    WebComponent okButton;
    @Data(skip = true)
    @FindBy(css = "#toast-container .toast-success")
    WebComponent successMessage;

    public void setNewEmailFax() {
       setNewEmailFaxSTep(newEmailFax.getData());
    }

    @Step("Type {0} into the new Email/Fax field and click OK button")
    private void setNewEmailFaxSTep(String randomValue) {
        setElementValue(newEmailFax);
        okButton.click();
        Helper.waitForXHR();

    }

    public void validateCurrentEmailFax() {
        currentEmailFax.validateData();
    }

    public String getEmailFaxValue() {
        return newEmailFax.getData();
    }
}
