package com.rbccm.taf.rlm.pageobjects;

import com.rbccm.taf.ui.support.EnvironmentsSetup;
import com.rbccm.taf.ui.support.PageObjectModel;
import com.rbccm.taf.ui.support.TestContext;
import com.rbccm.taf.ui.utils.Helper;
import com.thoughtworks.xstream.annotations.XStreamAlias;
import datainstiller.data.Data;
import org.openqa.selenium.support.FindBy;
import ru.yandex.qatools.allure.annotations.Step;
import ui.auto.core.components.WebComponent;

@SuppressWarnings("unused")
@XStreamAlias("loginPOM")
public class RLMLoginPOM extends PageObjectModel {
    @FindBy(id = "username")
    private WebComponent userName;
    @FindBy(id = "password")
    private WebComponent password;
    @Data(skip = true)
    @FindBy(id = "login-button")
    private WebComponent loginButton;
    @Data(skip = true)
    @FindBy(id = "login-error")
    private WebComponent error;

    public RLMLoginPOM(){}

    public RLMLoginPOM(TestContext context){
        initPage(context);
    }

    @Step("Navigate to RLM site")
    public void navigate() {
        getDriver().manage().deleteAllCookies();
        EnvironmentsSetup.Environment env = TestContext.getTestProperties().getTestEnvironment();
        getDriver().get(env.getUrl() + "/login");
        Helper.waitToShow(userName);
    }

    @Step("Login with user \"{0}\" and password \"{1}\"")
    private void login(String userName, String password) {
        setElementValue(this.userName, userName);
        setElementValue(this.password, password);
    }

    @Step("Log into RLM using valid credentials")
    public void login() {
        login(userName.getData(), password.getData());
        loginButton.click();
        if (Helper.waitToShow(error, 2)){
            throw new RuntimeException(error.getText());
        }
        waitForUrl("/rlm-dashboard");
    }

    public String getUserName() {
        return userName.getData();
    }

    public String getPassword() {
        return password.getData();
    }


}
