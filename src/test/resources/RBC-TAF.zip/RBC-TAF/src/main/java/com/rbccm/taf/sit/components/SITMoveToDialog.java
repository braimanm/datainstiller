package com.rbccm.taf.sit.components;


import com.rbccm.taf.ui.utils.Helper;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import ui.auto.core.pagecomponent.PageComponentNoDefaultAction;

public class SITMoveToDialog extends PageComponentNoDefaultAction {
    private WebElement moveButton;

    @Override
    protected void init() {
        moveButton = coreElement.findElement(By.cssSelector("button[id$=copyMoveTo-ok-button]"));
    }

    public void moveToFolder(String folderName) {
        WebElement folderElement = Helper.getWebDriiverWait()
                .until(ExpectedConditions.presenceOfNestedElementLocatedBy(coreElement, (By.xpath(".//span[.='" + folderName + "']"))));
        folderElement.click();
        moveButton.click();
        Helper.waitForXHR();
    }


}
