package com.rbccm.taf.sit.components;


import com.rbccm.taf.ui.utils.Helper;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import ui.auto.core.data.DataTypes;
import ui.auto.core.pagecomponent.PageComponent;

public class SITMenuButton extends PageComponent {
    private WebElement menu;

    public SITMenuButton() {}
    public SITMenuButton(WebElement element) {
        super(element);
    }

    @Override
    protected void init() {
        if (!coreElement.getTagName().equals("button")) {
            throw new RuntimeException("Given component " + coreElement + " is not of type SITMenuButton!");
        }
        menu = coreElement.findElement(By.xpath("../../../div"));
    }

    @Override
    public void setValue() {
        setValue(getData());
    }

    public void setValue(String menuItemName) {
        if (!menu.isDisplayed()) {
            coreElement.click();
            Helper.getWebDriiverWait().until(ExpectedConditions.visibilityOf(menu));
        }
        WebElement menuItem = menu.findElement(By.xpath(".//span[starts-with(.,'" + menuItemName + "')]"));
        menuItem.click();
    }

    @Override
    public String getValue() {
        return null;
    }

    @Override
    public void validateData(DataTypes validationMethod) {
    }

}
