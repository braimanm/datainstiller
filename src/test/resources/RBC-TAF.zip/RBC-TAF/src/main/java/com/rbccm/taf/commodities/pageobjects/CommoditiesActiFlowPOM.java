package com.rbccm.taf.commodities.pageobjects;

import com.rbccm.taf.commodities.components.CommoditiesBasket;
import com.rbccm.taf.commodities.components.CommoditiesBasketsPanel;
import com.rbccm.taf.commodities.components.CommoditiesTaskEntry;
import com.rbccm.taf.commodities.components.CommoditiesTaskTable;
import com.rbccm.taf.ui.support.PageObjectModel;
import datainstiller.data.Data;
import org.openqa.selenium.support.FindBy;
import ru.yandex.qatools.allure.annotations.Step;
import ui.auto.core.data.DataTypes;

public class CommoditiesActiFlowPOM extends PageObjectModel {
    @FindBy(css = "#panelBaskets")
    CommoditiesBasketsPanel sourceBasket;
    CommoditiesTaskEntry taskEntry;
    @Data(skip = true)
    @FindBy(css = "div[kendo-grid=taskGrid] .k-grid-content")
    CommoditiesTaskTable tasks;
    @FindBy(css = "#panelBaskets")
    CommoditiesBasketsPanel destinationBasket;

    CommoditiesFileCabinetPOM fileCabinetPOM;

    public CommoditiesFileCabinetPOM getFileCabinetPOM() {
        if (fileCabinetPOM == null) {
            fileCabinetPOM = new CommoditiesFileCabinetPOM();
        }
        fileCabinetPOM.initPage(getContext());
        return fileCabinetPOM;
    }

    @Step("Go to \"{0}\" basket")
    private void gotoBasket(String basket, CommoditiesBasketsPanel basketComponent) {
        setElementValue(basketComponent, false);
        basketComponent.validateData(DataTypes.Data);
    }

    public void selectBasket() {
        gotoBasket(sourceBasket.getData(), sourceBasket);
    }

    public CommoditiesBasket getSourceBasket() {
        return CommoditiesBasket.getBasketForName(sourceBasket.getData());
    }

    public CommoditiesBasket getDestinationBasket() {
        if (destinationBasket.getData() != null) {
            return CommoditiesBasket.getBasketForName(destinationBasket.getData());
        }
        return null;
    }

    @Step("Lookup for the task with Advice Id {0} in the worklist")
    public CommoditiesTaskEntry getTaskByAdviceId(String adviceId) {
        return tasks.getTaskEntry(adviceId, taskEntry);
    }

    public void validateTaskMigration(String adviceId) {
        String destBasket = destinationBasket.getData();
        if(destBasket != null) {
            validateTaskRemoval(adviceId);
            gotoBasket(destinationBasket.getData(), destinationBasket);
            validateMigration(destBasket, adviceId);
        }
    }

    public void validateTaskRemoval(String adviceId) {
        validateTaskRemoval(sourceBasket.getData(), adviceId);
    }

    @Step("Validate that task \"{1}\" is removed from \"{0}\" basket")
    private void validateTaskRemoval(String basket, String adviceId) {
        String failMessage = "Task with advice Id " + adviceId + " was not moved from \"" + basket + "\" basket";
        tasks.waitFotTaskToDisappear(adviceId, failMessage);
    }

    @Step("Validate that task \"{1}\" is migrated to \"{0}\" basket")
    private void validateMigration(String basket, String adviceId) {
        String failMessage = "Task with advice Id " + adviceId + " was not found in the \"" + basket + "\" basket";
        tasks.waitFotTaskToAppear(adviceId, failMessage);
    }
}
