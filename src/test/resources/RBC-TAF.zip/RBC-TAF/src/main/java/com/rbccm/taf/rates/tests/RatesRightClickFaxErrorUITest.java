package com.rbccm.taf.rates.tests;

import com.rbccm.taf.rates.components.RatesDocumentEntry;
import com.rbccm.taf.rates.components.RatesDocumentProperty;
import com.rbccm.taf.rates.components.RatesTaskEntry;
import com.rbccm.taf.rates.components.RatesTaskProperty;
import com.rbccm.taf.rates.domainobjects.RatesNoStepsDOM;
import com.rbccm.taf.rates.pageobjects.RatesActiFlowPOM;
import com.rbccm.taf.rates.pageobjects.RatesFileCabinetPOM;
import com.rbccm.taf.rates.pageobjects.RatesLoginPOM;
import com.rbccm.taf.ui.testng.TestNGBase;
import org.assertj.core.api.Assertions;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.Description;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

import java.io.IOException;

@Features("Fax to Remove")
@Stories("Verify task removal from workflow")
@Description("Fax Error-->Remove-->Return to Resolve Error-->Forward to Remove-->Remove from Workflow-->Check FileCabinet")
public class RatesRightClickFaxErrorUITest extends TestNGBase {
    private String adviceId;


    @Parameters({"data-set1"})
    @Test
    public void tc007_01(@Optional("data/rates/TC007_Fax_Error_Verify_the_right_click_functionailities/TC007_01.xml") String dataSet) throws IOException, InterruptedException {

        RatesNoStepsDOM rates = new RatesNoStepsDOM(dataSet);
        adviceId = rates.uploadGeneratedFeedFiles();

        RatesLoginPOM login = rates.getLoginPOM(getContext());
        login.login();

        RatesActiFlowPOM actiFlow = rates.getActiFlowPOM();

        actiFlow.selectBasket();

        RatesTaskEntry task = actiFlow.getTaskByAdviceId(adviceId);
        task.validateActions();
        task.doAction();

    }

    @Parameters({"data-set2"})
    @Test(dependsOnMethods = "tc007_01")
    public void tc007_02(@Optional("data/rates/TC007_Fax_Error_Verify_the_right_click_functionailities/TC007_02.xml") String dataSet) throws IOException, InterruptedException{
        RatesNoStepsDOM rates = new RatesNoStepsDOM(dataSet);

        RatesLoginPOM login = rates.getLoginPOM(getContext());
        login.login();

        RatesActiFlowPOM actiFlow = rates.getActiFlowPOM();
        actiFlow.selectBasket();

        RatesTaskEntry task = actiFlow.getTaskByAdviceId(adviceId);
        task.doAction();
        actiFlow.validateTaskMigration(adviceId);

    }

    @Parameters({"data-set3"})
    @Test(dependsOnMethods = "tc007_02")
    public void tc007_03(@Optional("data/rates/TC007_Fax_Error_Verify_the_right_click_functionailities/TC007_03.xml") String dataSet) throws IOException, InterruptedException {
        RatesNoStepsDOM rates = new RatesNoStepsDOM(dataSet);

        RatesLoginPOM login = rates.getLoginPOM(getContext());
        login.login();

        RatesActiFlowPOM actiFlow = rates.getActiFlowPOM();

        actiFlow.selectBasket();

        RatesTaskEntry task = actiFlow.getTaskByAdviceId(adviceId);
        task.validateActions();
        task.doAction();

        actiFlow.validateTaskMigration(adviceId);
    }

    @Parameters({"data-set4"})
    @Test(dependsOnMethods = "tc007_03")
    public void tc007_04(@Optional("data/rates/TC007_Fax_Error_Verify_the_right_click_functionailities/TC007_04.xml") String dataSet) throws IOException, InterruptedException {
        RatesNoStepsDOM rates = new RatesNoStepsDOM(dataSet);

        RatesLoginPOM login = rates.getLoginPOM(getContext());
        login.login();

        RatesActiFlowPOM actiFlow = rates.getActiFlowPOM();
        actiFlow.selectBasket();

        RatesTaskEntry task = actiFlow.getTaskByAdviceId(adviceId);
        task.validateActions();
        task.doAction();
        actiFlow.validateTaskMigration(adviceId);

    }

    @Parameters({"data-set5"})
    @Test(dependsOnMethods = "tc007_04")
    public void tc007_05(@Optional("data/rates/TC007_Fax_Error_Verify_the_right_click_functionailities/TC007_05.xml") String dataSet) throws IOException, InterruptedException {
        RatesNoStepsDOM rates = new RatesNoStepsDOM(dataSet);

        RatesLoginPOM login = rates.getLoginPOM(getContext());
        login.login();

        RatesActiFlowPOM actiFlow = rates.getActiFlowPOM();
        actiFlow.selectBasket();

        RatesTaskEntry task = actiFlow.getTaskByAdviceId(adviceId);
        task.validateActions();
        task.doAction();
        actiFlow.validateTaskMigration(adviceId);
        Assertions.assertThat(task.getProperty(RatesTaskProperty.Comment)).isEqualTo("From Fax Error");
    }

    @Parameters({"data-set6"})
    @Test(dependsOnMethods = "tc007_05")
    public void tc007_06(@Optional("data/rates/TC007_Fax_Error_Verify_the_right_click_functionailities/TC007_06.xml") String dataSet) throws IOException, InterruptedException {
        RatesNoStepsDOM rates = new RatesNoStepsDOM(dataSet);

        RatesLoginPOM login = rates.getLoginPOM(getContext());
        login.login();

        RatesActiFlowPOM actiFlow = rates.getActiFlowPOM();
        actiFlow.selectBasket();

        RatesTaskEntry task = actiFlow.getTaskByAdviceId(adviceId);
        task.validateActions();
        task.doAction();
    }

    @Parameters({"data-set7"})
    @Test(dependsOnMethods = "tc007_06")
    public void tc007_07(@Optional("data/rates/TC007_Fax_Error_Verify_the_right_click_functionailities/TC007_07.xml") String dataSet) throws IOException, InterruptedException {
        RatesNoStepsDOM rates = new RatesNoStepsDOM(dataSet);

        RatesLoginPOM login = rates.getLoginPOM(getContext());
        login.login();

        RatesActiFlowPOM actiFlow = rates.getActiFlowPOM();
        actiFlow.selectBasket();

        RatesTaskEntry task = actiFlow.getTaskByAdviceId(adviceId);
        task.validateActions();
        task.doAction();
    }


    @Parameters({"data-set8"})
    @Test(dependsOnMethods = "tc007_07")
    public void tc007_08(@Optional("data/rates/TC007_Fax_Error_Verify_the_right_click_functionailities/TC007_08.xml") String dataSet) throws IOException, InterruptedException {
        RatesNoStepsDOM rates = new RatesNoStepsDOM(dataSet);

        RatesLoginPOM login = rates.getLoginPOM(getContext());
        login.login();

        RatesActiFlowPOM actiFlow = rates.getActiFlowPOM();
        actiFlow.selectBasket();

        RatesTaskEntry task = actiFlow.getTaskByAdviceId(adviceId);
        task.validateActions();
        task.doAction();
    }
    @Parameters({"data-set9"})
    @Test(dependsOnMethods = "tc007_08")
    public void tc007_09(@Optional("data/rates/TC007_Fax_Error_Verify_the_right_click_functionailities/TC007_09.xml") String dataSet) throws IOException, InterruptedException {
        RatesNoStepsDOM rates = new RatesNoStepsDOM(dataSet);

        RatesLoginPOM login = rates.getLoginPOM(getContext());
        login.login();

        RatesActiFlowPOM actiFlow = rates.getActiFlowPOM();
        actiFlow.selectBasket();

        RatesTaskEntry task = actiFlow.getTaskByAdviceId(adviceId);
        task.validateActions();
        task.doAction();
        actiFlow.validateTaskMigration(adviceId);
        Assertions.assertThat(task.getProperty(RatesTaskProperty.Comment)).isEqualTo("Returned From Remove");
    }
    @Parameters({"data-set10"})
    @Test(dependsOnMethods = "tc007_09")
    public void tc007_10(@Optional("data/rates/TC007_Fax_Error_Verify_the_right_click_functionailities/TC007_10.xml") String dataSet) throws IOException, InterruptedException {
        RatesNoStepsDOM rates = new RatesNoStepsDOM(dataSet);

        RatesLoginPOM login = rates.getLoginPOM(getContext());
        login.login();

        RatesActiFlowPOM actiFlow = rates.getActiFlowPOM();
        actiFlow.selectBasket();

        RatesTaskEntry task = actiFlow.getTaskByAdviceId(adviceId);
        task.validateActions();
        task.doAction();
        actiFlow.validateTaskMigration(adviceId);
        Assertions.assertThat(task.getProperty(RatesTaskProperty.Comment)).isEqualTo("From Fax Error");
    }
    @Parameters({"data-set11"})
    @Test(dependsOnMethods = "tc007_10")
    public void tc007_11(@Optional("data/rates/TC007_Fax_Error_Verify_the_right_click_functionailities/TC007_11.xml") String dataSet) throws IOException, InterruptedException {
        RatesNoStepsDOM rates = new RatesNoStepsDOM(dataSet);

        RatesLoginPOM login = rates.getLoginPOM(getContext());
        login.login();

        RatesActiFlowPOM actiFlow = rates.getActiFlowPOM();
        actiFlow.selectBasket();

        RatesTaskEntry task = actiFlow.getTaskByAdviceId(adviceId);
        task.validateActions();
        task.doAction();
        actiFlow.validateTaskMigration(adviceId);
        RatesFileCabinetPOM fileCabinetPOM = actiFlow.getFileCabinetPOM();
        fileCabinetPOM.searchForDocument("Advice Id :" + adviceId);
        RatesDocumentEntry documentEntry = fileCabinetPOM.getDocument(0);
        Assertions.assertThat(documentEntry.getProperty(RatesDocumentProperty.StatusCode)).isEqualTo("Removed");
    }

}
