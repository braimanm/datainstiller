package com.rbccm.taf.rates.pageobjects;

import com.rbccm.taf.rates.components.RatesCabinetSearchPannel;
import com.rbccm.taf.rates.components.RatesDocumentEntry;
import com.rbccm.taf.rates.components.RatesFileCabinetTable;
import com.rbccm.taf.ui.support.PageObjectModel;
import com.rbccm.taf.ui.utils.Helper;
import datainstiller.data.Data;
import org.openqa.selenium.support.FindBy;
import ui.auto.core.components.WebComponent;

public class RatesFileCabinetPOM extends PageObjectModel {
    @FindBy(css = "#fileSearchPanel")
    RatesCabinetSearchPannel searchPannel;
    @Data(skip = true)
    @FindBy(css="[ng-click='search()']")
    public WebComponent cabinateSearchBtn;
    @Data(skip = true)
    @FindBy(css = "[ng-click='reset()']")
    public WebComponent cabinateResetBtn;
    @Data(skip = true)
    @FindBy(css = "#kendoFileGrid")
    public RatesFileCabinetTable fileCabinetTable;


    public void searchForDocument(String search){
        cabinateResetBtn.click();
        searchPannel.setValue(search);
        cabinateSearchBtn.click();
        Helper.waitForXHR();
    }

    public RatesDocumentEntry getDocument(int index) {
        return fileCabinetTable.getDocumentEntry(index);
    }

}

