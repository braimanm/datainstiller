package com.rbccm.taf.commodities.components;

public enum CommoditiesDocumentProperty {

    AdviceId,
    TransID,
    TradeId,
    ConfirmationType,
    StatusCode,
    Counterparty,
    DocumentType,
    DocumentName,
    Created,
    Product,
    OutTurnDate,
    SettlementDate,
    SettlementCurency,
    Annotations
}
