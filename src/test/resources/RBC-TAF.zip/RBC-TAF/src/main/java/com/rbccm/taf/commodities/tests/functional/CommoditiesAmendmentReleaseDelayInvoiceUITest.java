package com.rbccm.taf.commodities.tests.functional;

import com.rbccm.taf.commodities.components.CommoditiesDocumentEntry;
import com.rbccm.taf.commodities.components.CommoditiesDocumentProperty;
import com.rbccm.taf.commodities.components.CommoditiesTaskEntry;
import com.rbccm.taf.commodities.domainobjects.CommoditiesNoStepsDOM;
import com.rbccm.taf.commodities.pageobjects.CommoditiesActiFlowPOM;
import com.rbccm.taf.commodities.pageobjects.CommoditiesFileCabinetPOM;
import com.rbccm.taf.commodities.pageobjects.CommoditiesLoginPOM;
import com.rbccm.taf.ui.testng.TestNGBase;
import org.assertj.core.api.Assertions;
import org.openqa.selenium.By;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.Description;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

import java.io.IOException;

@Features("Amendment watch flow for Invoice Trade in Release Delay")
@Stories("Amendment watch flow when old trade in Release Delay basket and New trade inserted in Invoice basket")
@Description("Trade1 inserted in Invoice Review-->Release Delay-->Trade2 inserted in  Invoice Review-->StatusCode verify in FileCabinet")
public class CommoditiesAmendmentReleaseDelayInvoiceUITest extends TestNGBase {
    private String adviceId;

    @Parameters({"data-set1"})
    @Test
    public void tc001_01(@Optional("data/commodities/functional/Amendment/TC016_Amendment_Watch_Release_Delay_Invoice/TC001_01.xml") String dataSet) throws IOException, InterruptedException {
        CommoditiesNoStepsDOM comm = new CommoditiesNoStepsDOM(dataSet);
        adviceId = comm.uploadGeneratedFeedFiles();
        CommoditiesLoginPOM login = comm.getLoginPOM(getContext());
        login.login();

        CommoditiesActiFlowPOM actiFlow = comm.getActiFlowPOM();

        actiFlow.selectBasket();

        CommoditiesTaskEntry task = actiFlow.getTaskByAdviceId(adviceId);
        task.validateActions();
        task.doAction();
        actiFlow.validateTaskRemoval(adviceId);
        actiFlow.validateTaskMigration(adviceId);
        CommoditiesFileCabinetPOM fileCabinetPOM = actiFlow.getFileCabinetPOM();
        fileCabinetPOM.searchForDocument("Advice ID :" + adviceId);
        By by = By.cssSelector(".k-grid-content tr");
        long allCells = fileCabinetPOM.fileCabinetTable.getCoreElement().findElements(by).size();
        for(int i=0;i<allCells;i++) {
            CommoditiesDocumentEntry documentEntry = fileCabinetPOM.getDocument(i);
            if(documentEntry.getProperty(CommoditiesDocumentProperty.StatusCode).equals("NEW")) {
                Assertions.assertThat(documentEntry.getProperty(CommoditiesDocumentProperty.StatusCode)).isEqualTo("NEW");
                break;
            }
        }
    }

    @Parameters({"data-set2"})
    @Test(dependsOnMethods = "tc001_01")
    public void tc001_02(@Optional("data/commodities/functional/Amendment/TC016_Amendment_Watch_Release_Delay_Invoice/TC001_02.xml") String dataSet) throws IOException, InterruptedException {
        CommoditiesNoStepsDOM comm = new CommoditiesNoStepsDOM(dataSet);
        adviceId = comm.uploadGeneratedFeedFiles();
        CommoditiesLoginPOM login = comm.getLoginPOM(getContext());
        login.login();

        CommoditiesActiFlowPOM actiFlow = comm.getActiFlowPOM();

        actiFlow.selectBasket();

        CommoditiesTaskEntry task = actiFlow.getTaskByAdviceId(adviceId);
        task.validateActions();
        CommoditiesFileCabinetPOM fileCabinetPOM = actiFlow.getFileCabinetPOM();
        fileCabinetPOM.searchForDocument("Advice ID :" + adviceId);
        By by = By.cssSelector(".k-grid-content tr");
        long allCells = fileCabinetPOM.fileCabinetTable.getCoreElement().findElements(by).size();
        for(int i=0;i<allCells;i++) {
            CommoditiesDocumentEntry documentEntry = fileCabinetPOM.getDocument(i);
            if (documentEntry.getProperty(CommoditiesDocumentProperty.StatusCode).equals("Amended")) {
                Assertions.assertThat(documentEntry.getProperty(CommoditiesDocumentProperty.StatusCode)).isEqualTo("Amended");
                break;
            }
        }
    }
}
