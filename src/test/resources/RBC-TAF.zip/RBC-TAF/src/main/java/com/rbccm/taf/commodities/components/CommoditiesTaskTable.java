package com.rbccm.taf.commodities.components;

import com.rbccm.taf.ui.support.TestContext;
import org.assertj.core.api.Assertions;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import ui.auto.core.pagecomponent.PageComponentNoDefaultAction;

import java.util.ArrayList;
import java.util.List;

public class CommoditiesTaskTable extends PageComponentNoDefaultAction {
    List<WebElement> tasks;

    @Override
    protected void init() {
        WebElement el = coreElement.findElement(By.cssSelector("table"));
        if (el.isDisplayed()) {
            tasks = coreElement.findElements(By.cssSelector("tr[data-uid]"));
            coreElement = el;
        } else {
            tasks = new ArrayList<>();
        }
    }

    public CommoditiesTaskEntry waitFotTaskToAppear(String adviceId, String failMessage) {
        By by = By.xpath(".//span[.='" + adviceId + "']/../..");
        long timeout = System.currentTimeMillis() + TestContext.getTestProperties().getElementTimeout() * 1000;
        List<WebElement> taskElements;
        do {
            taskElements = coreElement.findElements(by);
        } while (System.currentTimeMillis() < timeout && taskElements.isEmpty());
        Assertions.assertThat(taskElements).withFailMessage(failMessage).isNotEmpty();
        return new CommoditiesTaskEntry(adviceId);
    }

    public void waitFotTaskToDisappear(String adviceId, String failMessage) {
        if (tasks.isEmpty()) return;
        By by = By.xpath(".//span[.='" + adviceId + "']/../..");
        long timeout = System.currentTimeMillis() + TestContext.getTestProperties().getElementTimeout() * 1000;
        List<WebElement> taskElements;
        do {
            taskElements = coreElement.findElements(by);
        } while (System.currentTimeMillis() < timeout && !taskElements.isEmpty());
        Assertions.assertThat(taskElements).withFailMessage(failMessage).isEmpty();
    }

    public CommoditiesTaskEntry getTaskEntry(String adviceId, CommoditiesTaskEntry entry) {
        Assertions.assertThat(tasks).withFailMessage("There are no tasks in the table!").isNotEmpty();
        for (WebElement task : tasks) {
            String taskText = "";
            try {taskText = task.getText();} catch (Exception ignore) {}
            if (taskText.startsWith(adviceId)) {
                if (entry == null) {
                    entry = new CommoditiesTaskEntry(adviceId);
                } else {
                    entry.init(adviceId);
                }
                return entry;
            }
        }
        Assertions.fail("The task with Advice Id:" + adviceId + " was not found!");
        return null;
    }
}
