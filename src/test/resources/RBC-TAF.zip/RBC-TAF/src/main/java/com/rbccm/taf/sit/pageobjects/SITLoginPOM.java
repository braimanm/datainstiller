package com.rbccm.taf.sit.pageobjects;

import com.rbccm.taf.ui.support.AliasedString;
import com.rbccm.taf.ui.support.PageObjectModel;
import com.rbccm.taf.ui.support.TestContext;
import datainstiller.data.Data;
import org.openqa.selenium.support.FindBy;
import ru.yandex.qatools.allure.annotations.Step;
import ui.auto.core.components.WebComponent;

public class SITLoginPOM extends PageObjectModel {
    private AliasedString url;
    @FindBy(name = "username")
    private WebComponent userName;
    @FindBy(name = "password")
    private WebComponent password;
    @Data(skip = true)
    @FindBy(css = "button[type=button]")
    private WebComponent loginButton;

    public SITLoginPOM(){}
    public SITLoginPOM(TestContext context) {
        initPage(context);
    }

    @Step("Login to Alfresco application")
    public void login() {
        getDriver().get(url.getData());
        setElementValue(userName);
        setElementValue(password);
        loginButton.click();
    }

}
