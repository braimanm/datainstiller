package com.rbccm.taf.sds.pageobjects;

import datainstiller.data.Data;
import org.openqa.selenium.support.FindBy;
import ui.auto.core.components.WebComponent;

/**
 * Created by subdas on 28/07/2017.
 */
public class SDSQueuedRequestsPOM extends SDSCreateNewRequestPOM {

    @Data(skip = true)
    @FindBy(xpath = "//span[text()='Queued Requests']")
    private WebComponent lnkQueuedRequest;

    @FindBy(css = "[placeholder='search Request']")
    private WebComponent txtSearchRequest;

    @Data(skip = true)
    @FindBy(css = "span[class='glyphicon glyphicon-search']")
    private WebComponent btnSearchRequest;


    //[class='container'] table a


    //@Step("Verify the data of the created requests and SLA timing")
//    public void searchAndValidateRequest(){
//
//        lnkQueuedRequest.click();
//
//        for (String str : requestNumber) {
//            setElementValue(txtSearchRequest,str);
//            btnSearchRequest.click();
//
//
//
//        }


}

//}
