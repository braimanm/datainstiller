package com.rbccm.taf.sds.pageobjects;

import com.rbccm.taf.common.components.RadioGroup;
import com.rbccm.taf.sds.components.SDSAutocomplete;
import com.rbccm.taf.sds.components.SDSSelect;
import com.rbccm.taf.ui.support.TestContext;
import com.rbccm.taf.ui.utils.Helper;
import com.thoughtworks.xstream.annotations.XStreamAlias;
import datainstiller.data.Data;
import org.openqa.selenium.support.FindBy;
import ru.yandex.qatools.allure.annotations.Step;
import ui.auto.core.components.WebComponent;
import ui.auto.core.data.DataTypes;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import static org.assertj.core.api.Assertions.assertThat;


@XStreamAlias("request")
public class SDSCreateNewRequestPOM extends SDSMainPO {
    @FindBy(css = "[name='title']")
    public WebComponent requestTitle;
    @FindBy(css = "[name='template']")
    public SDSSelect template;
    @FindBy(css = "[name='clientname']")
    public SDSAutocomplete clientName;
    @FindBy(name = "clientcontact")
    public WebComponent contactNumber;
    @FindBy(css = "[name='email']")
    public SDSAutocomplete clientEmail;
    @FindBy(name = "wbname")
    public SDSSelect workBasket;
    @FindBy(css = "[name='location']")
    public WebComponent location;
    @FindBy(css = "[name='category']")
    public SDSSelect category;
    @FindBy(css = "[name='subcategory']")
    public SDSSelect subCategory;
    @FindBy(css = "[name='type']")
    public SDSSelect requestType;
    @FindBy(name = "slagoal")
    public WebComponent slaGoalTime;
    @FindBy(name = "sladeadline")
    public WebComponent slaDeadLineTime;
    @FindBy(name = "slalate")
    public WebComponent slaLateTime;
    @FindBy(css = "[name='priority']")
    public SDSSelect priority;
    @FindBy(css = "div.radio")
    public RadioGroup asapIndicator;
    @FindBy(name = "totaltasks")
    public WebComponent totalTasks;
    @FindBy(name = "completedtasks")
    public WebComponent completedTask;
    @FindBy(name = "externalgroup")
    public SDSSelect externalGroup;
    @Data(skip = true)
    @FindBy(css = "button.btn.btn-primary[type=submit]")
    public WebComponent btnCreateRequest;
    @Data(skip = true)
    @FindBy(css = "div.response-container")
    public WebComponent message;
    @Data(skip = true)
    @FindBy(css = ".close[type='button']")
    public WebComponent closeCreateRequestButton;

    //WebElements for Search request
    @Data(skip = true)
    @FindBy(xpath = "//span[text()='Queued Requests']")
    public WebComponent lnkQueuedRequest;
    @FindBy(css = "[placeholder='search Request']")
    public WebComponent txtSearchRequest;
    @Data(skip = true)
    @FindBy(css = "span[class='glyphicon glyphicon-search']")
    public WebComponent btnSearchRequest;
    @Data(skip = true)
    @FindBy(css = "[class='container'] table a")
    public WebComponent searchedRequest;
    @Data(skip = true)
    @FindBy(css = "[id='bodycolor']>div:nth-child(4)>div:nth-child(2)")
    public WebComponent requestCreatedDateTimee;

    //WebElements for complete request
    @Data(skip = true)
    @FindBy(css = "[class='row headColorButton top-buffer center']>div:nth-child(4)>button")
    public WebComponent btnComplete;
    @FindBy(css = "[name^='completeNote']")
    public WebComponent txtApproveComment;
    @Data(skip = true)
    @FindBy(xpath = "//*[contains(text(),'Complete Request')]")
    public WebComponent btnCompleteRequest;

    //WebElements for cancel request
    @Data(skip = true)
    @FindBy(css = "[class='row headColorButton top-buffer center']>div:nth-child(5)>button")
    public WebComponent btnCancel;

    @FindBy(css = "[placeholder='Enter Approver Note here']")
    public WebComponent txtApproverNote;

    @FindBy(css = "[placeholder='Enter your note here']")
    public WebComponent txtNote;

    @Data(skip = true)
    @FindBy(xpath = "//*[contains(text(),'Cancel Request')]")
    public WebComponent btnCancelRequest;
    @FindBy(css = "[class=statusFont]")
    public WebComponent txtWorkStatus;

    //WebElements for Duplicate request
    @FindBy(css = "[class='row headColorButton top-buffer center'] select")
    public SDSSelect resolvedAs;

    @FindBy(css = "[placeholder='Enter Request Id here']")
    public WebComponent txtDuplicateID;
    @Data(skip = true)
    @FindBy(xpath = "//*[contains(text(),'Resolved as Duplicate')]")
    public WebComponent btnResolvedDuplicate;

    @Data(skip = true)
    @FindBy(xpath = "//span[text()='Resolved List']")
    public WebComponent navResolvedList;

    @Data(skip = true)
    @FindBy(xpath = "//a[text()='Duplicate ']")
    public WebComponent navDuplicate;

    @Step("Fill the request form")
    public void fill() {
        autoFillPage();
    }

    @Step("Submit the request form and validate successful confirmation message")
    public void submitRequestAndValidateMessage() {
        btnCreateRequest.click();
        Helper.waitForXHR();
        String successMessage = message.getText();
        String reqNum = "SDS-" + successMessage.replaceAll("\\D+", "");
        TestContext.getGlobalAliases().put("request-id", reqNum);
        assertThat(successMessage).containsPattern("Success! New Request SDS-\\d{6,} has been created successfully");
        closeCreateRequestButton.click();
    }

    @Step("Select template and validate that required fields are pre-filled with correct values")
    public void fillTemplateAndValidate() {
        setElementValue(template);
        setElementValue(clientName);
        setElementValue(clientEmail);
        Helper.waitForXHR();
        autoValidatePage(DataTypes.Expected);
    }


    @Step("Select workbasket and validate location field is pre-filled with correct value and fill the other required fields")
    public void fillWorkBasketAndValidate() {
        setElementValue(clientName);
        setElementValue(workBasket);
        setElementValue(category);
        setElementValue(subCategory);
        setElementValue(requestType);
        setElementValue(priority);
        setElementValue(asapIndicator);
        setElementValue(clientEmail);
        Helper.waitForXHR();
        autoValidatePage(DataTypes.Expected);
    }

    @Step("Search newly created request")
    public void searchNewCreatedRequest() {
        String requestId = TestContext.getGlobalAliases().get("request-id");
        Helper.waitForXHR();
        lnkQueuedRequest.click();
        setElementValue(txtSearchRequest, requestId);
        btnSearchRequest.click();
        searchedRequest.click();
        closeCreateRequestButton.click();
        Helper.waitForXHR();

    }

    @Step("Validate data for newly created request with Template")
    public void validateTemplateRequestData() {
        clientName.validateData(DataTypes.Expected);
        workBasket.validateData(DataTypes.Expected);
        location.validateData(DataTypes.Expected);
        category.validateData(DataTypes.Expected);
        requestType.validateData(DataTypes.Expected);
        totalTasks.validateData(DataTypes.Expected);
        completedTask.validateData(DataTypes.Expected);
        externalGroup.validateData(DataTypes.Expected);
    }


    @Step("Validate data for newly created request with WorkBasket")
    public void validateWorkBasketRequestData() {
        clientName.validateData(DataTypes.Expected);
        workBasket.validateData(DataTypes.Expected);
        location.validateData(DataTypes.Expected);
        category.validateData(DataTypes.Expected);
        subCategory.validateData(DataTypes.Expected);
        requestType.validateData(DataTypes.Expected);
        totalTasks.validateData(DataTypes.Expected);
        completedTask.validateData(DataTypes.Expected);
    }

    @Step("Validate the SLAGoal Time")
    public void validateSLAGoalTime() {

        String requestCreatedDateTime = requestCreatedDateTimee.getText();
        Integer intSlaGoal = Integer.parseInt(slaGoalTime.getData());
        Calendar calender = Calendar.getInstance();
        Date dateRequestCreatedDateTime = new Date(requestCreatedDateTime);
        calender.setTime(dateRequestCreatedDateTime);
        calender.add(Calendar.MINUTE, intSlaGoal);
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("M/d/yyyy,h:mm:ss a");
        dateRequestCreatedDateTime = calender.getTime();
        String expectedSlaGoalTime = simpleDateFormat.format(dateRequestCreatedDateTime);
        String actualSlaGoalTime = slaGoalTime.getAttribute("value");
        assertThat(actualSlaGoalTime).isEqualToIgnoringWhitespace(expectedSlaGoalTime);

    }

    @Step("Validate the SLADeadLineTime")
    public void validateSLADeadLineTime() {

        String requestCreatedDateTime = requestCreatedDateTimee.getText();
        Integer intSlaDeadTime = Integer.parseInt(slaDeadLineTime.getData());
        Calendar calender = Calendar.getInstance();
        Date dateRequestCreatedDateTime = new Date(requestCreatedDateTime);
        calender.setTime(dateRequestCreatedDateTime);
        calender.add(Calendar.MINUTE, intSlaDeadTime);
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("M/d/yyyy,h:mm:ss a");
        dateRequestCreatedDateTime = calender.getTime();
        String expectedSlaDeadLineTime = simpleDateFormat.format(dateRequestCreatedDateTime);
        String actualSlaDeadlineTime = slaDeadLineTime.getAttribute("value");
        assertThat(actualSlaDeadlineTime).isEqualToIgnoringWhitespace(expectedSlaDeadLineTime);

    }


    @Step("Validate the SLALateTime")
    public void validateSLALateTime() {

        String requestCreatedDateTime = requestCreatedDateTimee.getText();
        Integer intSlaLateTime = Integer.parseInt(slaLateTime.getData());
        Calendar calender = Calendar.getInstance();
        Date dateRequestCreatedDateTime = new Date(requestCreatedDateTime);
        calender.setTime(dateRequestCreatedDateTime);
        calender.add(Calendar.MINUTE, intSlaLateTime);
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("M/d/yyyy,h:mm:ss a");
        dateRequestCreatedDateTime = calender.getTime();
        String expectedSlaLateTime = simpleDateFormat.format(dateRequestCreatedDateTime);
        String actualSlaGoalTime = slaLateTime.getAttribute("value");
        assertThat(actualSlaGoalTime).isEqualToIgnoringWhitespace(expectedSlaLateTime);

    }

    @Step("Validate that the request update message is displayed")
    public void validateRequestUpdateMessage() {
        String successMessage = message.getText();
        assertThat(successMessage).containsIgnoringCase("Success! Request has been Updated successfully");
    }

    @Step("Enter comments for approval and complete the request")
    public void completeRequest() {
        btnComplete.click();
        setElementValue(txtApproveComment);
        btnCompleteRequest.click();
        validateRequestUpdateMessage();

    }


    @Step("Add approver's note to Cancel request")
    public void cancelRequest() {
        btnCancel.click();
        setElementValue(txtApproverNote);
        setElementValue(txtNote);
        btnCancelRequest.click();
        validateRequestUpdateMessage();

    }


    @Step("Validate the Work Status of the request after approve/reject")
    public void validateWorkStatus() {
        String workStatus = txtWorkStatus.getText();
        assertThat(workStatus).isEqualToIgnoringCase(txtWorkStatus.getData(DataTypes.Initial));

    }

    @Step("Perform operations to mark the request Resolve as duplicate")
    public void resolveDuplicate(String reqId, String reqId2) {
        lnkQueuedRequest.click();
        setElementValue(txtSearchRequest, reqId);
        btnSearchRequest.click();
        searchedRequest.click();
        closeCreateRequestButton.click();
        setElementValue(resolvedAs);
        setElementValue(txtDuplicateID, reqId2);
        btnResolvedDuplicate.click();
        Helper.waitForXHR();
        validateRequestUpdateMessage();
        closeCreateRequestButton.click();
        navResolvedList.click();
        navDuplicate.click();
        setElementValue(txtSearchRequest, reqId2);
        btnSearchRequest.click();
        Helper.waitToShow(searchedRequest);
        searchedRequest.click();
        closeCreateRequestButton.click();
        txtWorkStatus.validateData(DataTypes.Initial);

    }
}
