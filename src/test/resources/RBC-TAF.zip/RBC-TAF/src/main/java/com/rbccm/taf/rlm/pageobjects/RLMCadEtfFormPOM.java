package com.rbccm.taf.rlm.pageobjects;

import com.rbccm.taf.rlm.components.RLMRadioGroup;
import com.rbccm.taf.rlm.components.RLMSelect;
import com.rbccm.taf.ui.support.PageObjectModel;
import com.rbccm.taf.ui.utils.Helper;
import datainstiller.data.Data;
import org.openqa.selenium.support.FindBy;
import ru.yandex.qatools.allure.annotations.Step;
import ui.auto.core.components.WebComponent;
import ui.auto.core.pagecomponent.PageComponent;

import static org.assertj.core.api.Assertions.assertThat;

@SuppressWarnings("unused")
public class RLMCadEtfFormPOM extends PageObjectModel {
    @FindBy(id = "cadeftdurationtype")
    private RLMRadioGroup durationType;
    @FindBy(id = "cadetftypeofchange")
    private RLMSelect typeOfChange;
    @FindBy(id = "cadetfexistinglimit")
    private WebComponent existingLimit;
    @FindBy(id = "cadetfnewlimit")
    private WebComponent newLimit;
    @FindBy(id = "cadetfexpiredate")
    private WebComponent expireDate;
    @FindBy(id = "cadetfexpirehour")
    private RLMSelect expireHour;
    @FindBy(id = "cadetfexpireminute")
    private RLMSelect expireMinute;
    @FindBy(id = "cadetfamorpm")
    private RLMSelect amOrPm;

    //Fields for Form Validation
    @Data(skip = true)
    @FindBy(id = "cadetftypeofchange")
    private WebComponent valTypeOfChange;
    @Data(skip = true)
    @FindBy(id = "cadetfdurationtype")
    private WebComponent valDurationType;
    @Data(skip = true)
    @FindBy(id = "cadetfexpirydate")
    private WebComponent valExpiryDate;
    @Data(skip = true)
    @FindBy(id = "cadetfexistinglimit")
    private WebComponent valExistingLimit;
    @Data(skip = true)
    @FindBy(id = "cadetfnewlimit")
    private WebComponent valNewLimit;

    @Step("Populate CAD ETF Request Form with provided data")
    void fill() {
        autoFillPage();
    }

    @Step("Validate CAD ETF Request Form")
    public void validate() {
        if (isDataProvided(typeOfChange)) {
            validateComponentValue(valTypeOfChange, typeOfChange.getData(), "CAD ETF Type of Change");
        }
        if (isDataProvided(durationType)) {
            validateComponentValue(valDurationType, durationType.getData(), "CAD ETF Duration Type");
        }
        if (isDataProvided(existingLimit)) {
            validateComponentValue(valExistingLimit, existingLimit.getData(), "CAD ETF Existing limit");
        }
        if (isDataProvided(newLimit)) {
            validateComponentValue(valNewLimit, newLimit.getData(), "CAD ETF New Limit");
        }
        if (isDataProvided(expireDate)) {
            String expiryDateData = expireDate.getData() + " " + expireHour.getData() + ":" +
                    expireMinute.getData() + " " + amOrPm.getData();
            String data = Helper.convertDate("d-M-yyyy hh:mm a", "yyyy-MM-dd hh:mm a", expiryDateData);
            validateComponentValue(valExpiryDate, data, "CAD ETF Expiry Date");
        }
    }

    private boolean isDataProvided(PageComponent component) {
        return (component.getData() != null && !component.getData().isEmpty());
    }

    @Step("Validating field \"{2}\" has a value of \"{1}\"")
    private void validateComponentValue(PageComponent component, String data, String field) {
        if (data != null && !data.isEmpty()) {
            assertThat(component.getValue()).isEqualToIgnoringCase(data);
        }
    }
}
