package com.rbccm.taf.rlm.components;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import ui.auto.core.data.DataTypes;
import ui.auto.core.pagecomponent.PageComponent;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;


public class RLMRadioGroup extends PageComponent {

    @Override
    protected void init() {
    }

    @Override
    public void setValue() {
        WebElement radio = coreElement.findElement(By.cssSelector("input[value='" + getData() + "']+span"));
        if (!radio.isSelected()) {
            radio.click();
        }
    }

    @Override
    public String getValue() {
        List<WebElement> radios = coreElement.findElements(By.cssSelector("input[type=radio]"));
        for (WebElement radio : radios) {
            if (radio.isSelected()) {
                return radio.getAttribute("value");
            }
        }
        return null;
    }

    @Override
    public void validateData(DataTypes validationMethod) {
        assertThat(getValue()).isEqualToIgnoringCase(validationMethod.getData(this));
    }
}
