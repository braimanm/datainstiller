package com.rbccm.taf.rlm.pageobjects;

import com.rbccm.taf.rlm.components.RLMMultiSelect;
import com.rbccm.taf.rlm.components.RLMRadioGroup;
import com.rbccm.taf.rlm.components.RLMSelect;
import com.rbccm.taf.ui.support.PageObjectModel;
import com.rbccm.taf.ui.utils.Helper;
import datainstiller.data.Data;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import ru.yandex.qatools.allure.annotations.Step;
import ui.auto.core.components.WebComponent;
import ui.auto.core.pagecomponent.PageComponent;
import ui.auto.core.pagecomponent.SkipAutoFill;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

@SuppressWarnings("unused")
public class RLMNextGenFormPOM extends PageObjectModel{
    @FindBy(id = "nextgenclienttype")
    private RLMRadioGroup accountType;
    @FindBy(id = "accountname")
    private WebComponent accountName; //US only Field
    @FindBy(id = "internalaccountname")
    private WebComponent internalAccountName;
    @FindBy(id = "externalaccountname")
    private WebComponent externalAccountName;
    @SkipAutoFill
    @FindBy(id = "nextgenapplicabilitytype")
    private RLMRadioGroup applicabilityType;
    @FindBy(id = "nextgensymbol")
    private WebComponent symbol;
    @FindBy(id = "nextgensymboltypeofchange")
    private RLMSelect symbolTypeOfChange;
    @FindBy(id = "nextgenaccounttypeofchange")
    private RLMSelect accountTypeOfChange;
    @SkipAutoFill
    @FindBy(id = "nextgenstrategy")
    private WebComponent strategy;
    @SkipAutoFill
    @Data(skip = true)
    @FindBy(id = "country")  //US only Field and awkward id for strategy
    private RLMMultiSelect multiStartegy;
    @FindBy(id = "nextgenstrategytypeofchange")
    private RLMSelect strategyTypeOfChange;
    @FindBy(id = "nextgenrangelimit")
    private RLMSelect rangelimit;
    @FindBy(id = "nextgenorderlimit")
    private RLMSelect orderLimit;
    @FindBy(id = "nextgenexistinglimit")
    private WebComponent existingLimit;
    @FindBy(id = "nextgennewlimit")
    private WebComponent newLimit;
    @FindBy(id = "nextgendurationtype")
    private RLMRadioGroup durationType;
    @FindBy(id = "nextgenexpiredate")
    private WebComponent expireDate;
    @FindBy(id = "nextgenexpirehour")
    private RLMSelect expireHour;
    @FindBy(id = "nextgenexpireminute")
    private RLMSelect expireMinute;
    @FindBy(id = "nextgenamorpm")
    private RLMSelect amOrPm;

    //Fields for Form Validation
    @Data(skip = true)
    @FindAll({
            @FindBy(id = "nextgenrequestfor"),
            @FindBy(id = "nextgenapplicant"),
            @FindBy(id = "nexgenrequestfor") //US only Field
    })
    private WebComponent valRequestFor;
    @Data(skip = true)
    @FindAll({
            @FindBy(id = "nextgentypeofchange"),
            @FindBy(id = "nexgentypeofchange") //US only Field
    })
    private WebComponent valTypeOfChange;
    @Data(skip = true)
    @FindAll({
            @FindBy(id = "nextgendurationtype"),
            @FindBy(id = "nexgendurationtype") //US only Field
    })
    private WebComponent valDurationType;
    @Data(skip = true)
    @FindAll({
            @FindBy(id = "nextgenexpirydate"),
            @FindBy(id = "nexgenexpirydate") //US only Field
    })
    private WebComponent valExpiryDate;
    @Data(skip = true)
    @FindAll({
            @FindBy(id = "nextgenexistinglimit"),
            @FindBy(id = "nexgenexistinglimit") //US only Field
    })
    private WebComponent valExistingLimit;
    @Data(skip = true)
    @FindAll({
            @FindBy(id = "nextgennewlimit"),
            @FindBy(id = "nexgennewlimit")
    })
    private WebComponent valNewLimit;
    @Data(skip = true)
    @FindBy(id = "nexgenrange")
    private WebComponent valRange;
    @Data(skip = true)
    @FindAll({
            @FindBy(id = "nextgensymbol"),
            @FindBy(id = "nexgensymbol")
    })
    private WebComponent valSymbol;

    @Step("Populate NEXTGEN Request Form with provided data")
    void fill() {
        setElementValue(applicabilityType);
        List<WebElement> multiSelect = getDriver().findElements(By.cssSelector("multi-select-strategy-stencil"));
        if (!multiSelect.isEmpty()) {
            setElementValue(multiStartegy, strategy.getData());
        } else {
            setElementValue(strategy);
        }
        autoFillPage();
    }

    @Step("Validate NEXT GEN Request Form")
    public void validate() {
        String requestFor = "request for:";
        if (valRequestFor.getAttribute("id").contains("applicant")) {
            requestFor = "applicant";
        }
        if (isDataProvided(internalAccountName)) {
            validateComponentValue(valRequestFor, internalAccountName.getData(), "Next Gen " + requestFor);
        } else if (isDataProvided(externalAccountName)) {
            validateComponentValue(valRequestFor, externalAccountName.getData(), "Next Gen " + requestFor);
        }
        if (isDataProvided(symbolTypeOfChange)) {
            validateComponentValue(valTypeOfChange, symbolTypeOfChange.getData(), "Next Gen Type of Change");
        } else if (isDataProvided(strategyTypeOfChange)) {
            validateComponentValue(valTypeOfChange, strategyTypeOfChange.getData(), "Next Gen Type of Change");
        }
        if (isDataProvided(durationType)) {
            validateComponentValue(valDurationType, durationType.getData(), "Next Gen Duration Type");
        }
        if (isDataProvided(existingLimit)) {
            validateComponentValue(valExistingLimit, existingLimit.getData(), "Next Gen Existing Limit");
        }
        if (isDataProvided(newLimit)) {
            validateComponentValue(valNewLimit, newLimit.getData(), "Next Gen New Limit");
        }
        if (isDataProvided(expireDate)) {
            String expiryDateData = expireDate.getData() + " " + expireHour.getData() + ":" +
                    expireMinute.getData() + " " + amOrPm.getData();
            String data = Helper.convertDate("d-M-yyyy hh:mm a", "yyyy-MM-dd hh:mm a", expiryDateData);
            validateComponentValue(valExpiryDate, data, "Next Gen Expiry Date");
        }
        if (isDataProvided(rangelimit)) {
            validateComponentValue(valRange, rangelimit.getData(), "NexGen Range");
        } else if (isDataProvided(orderLimit)) {
            validateComponentValue(valRange, orderLimit.getData(), "NexGen Range");
        }
        if (isDataProvided(symbol)) {
            validateComponentValue(valSymbol, symbol.getData(), "Next Gen Symbol");
        }
    }

    private boolean isDataProvided(PageComponent component) {
        return (component.getData() != null && !component.getData().isEmpty());
    }

    @Step("Validating field \"{2}\" has a value of \"{1}\"")
    private void validateComponentValue(PageComponent component, String data, String field) {
        if (data != null && !data.isEmpty()) {
            assertThat(component.getValue()).isEqualToIgnoringCase(data);
        }
    }
}
