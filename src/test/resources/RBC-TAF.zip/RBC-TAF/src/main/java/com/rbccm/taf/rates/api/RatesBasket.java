package com.rbccm.taf.rates.api;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@SuppressWarnings("unused")
@JsonIgnoreProperties(ignoreUnknown=true)
public class RatesBasket {
    private String activitiId;
    private String id;
    private String name;
    private boolean selected;

    public String getActivitiId() {
        return activitiId;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public boolean isSelected() {
        return selected;
    }
}
