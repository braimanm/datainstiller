package com.rbccm.taf.commodities.pageobjects;


import com.rbccm.taf.ui.support.PageObjectModel;
import com.rbccm.taf.ui.utils.Helper;
import datainstiller.data.Data;
import org.openqa.selenium.support.FindBy;
import ru.yandex.qatools.allure.annotations.Step;
import ui.auto.core.components.WebComponent;

public class CommoditiesAnnotationsPOM extends PageObjectModel{

    @FindBy(css = "[id='annotationsModal'] [name='annTextArea']")
    WebComponent annotationTxtArea;

    @Data(skip=true)
    @FindBy(css="[id='annotationsModal'] [id='btnAddAnnotation']")
    WebComponent annotationAddBtn;

    @Data(skip=true)
    @FindBy(css="[id='annotationsModal'] [id='btnCloseAnnotation']")
    WebComponent annotationCloseBtn;


    @Step("Enter the comments in Please enter Annotation")
    public void addAnnotation(){

        setElementValue(annotationTxtArea);
        annotationAddBtn.click();
        Helper.waitForXHR();
    }

    public void closeAnnotation(){
        annotationCloseBtn.click();
        Helper.waitForXHR();
    }


}
