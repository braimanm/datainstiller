package com.rbccm.taf.sit.pageobjects;

import com.rbccm.taf.ui.support.AliasedString;
import com.rbccm.taf.ui.support.PageObjectModel;
import ru.yandex.qatools.allure.annotations.Step;

public class SITNavigation extends PageObjectModel {
    private AliasedString appUrl;

    @Step("Navigate to Dashboard")
    public void goToDashboard() {
        getDriver().get(appUrl.getData() + "/dashboard");
    }

    @Step("Navigate to Document Library")
    public void goToDocumentLibrary() {
        getDriver().get(appUrl.getData() + "/documentlibrary");
    }

}
