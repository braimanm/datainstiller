package com.rbccm.taf.rates.domainobjects;

import com.rbccm.taf.rates.api.RatesSession;
import com.rbccm.taf.rates.api.RatesTask;
import com.rbccm.taf.rates.components.RatesBasket;
import com.rbccm.taf.rates.pageobjects.RatesActiFlowPOM;
import com.rbccm.taf.rates.pageobjects.RatesLoginPOM;
import com.rbccm.taf.ui.support.EnvironmentsSetup;
import com.rbccm.taf.ui.support.TestContext;
import com.thoughtworks.xstream.annotations.XStreamAlias;
import org.omg.CORBA.Environment;
import ru.yandex.qatools.allure.annotations.Step;

import java.io.IOException;

@XStreamAlias("functional-step")
public class RatesStep {
    public RatesLoginPOM login;
    public RatesActiFlowPOM actiFlow;

    public void login(TestContext context) {
        if (login != null) {
            login.initPage(context);
            login.login();
        }
    }

    public RatesActiFlowPOM getActiFlow(TestContext context) {
        actiFlow.initPage(context);
        return actiFlow;
    }


    public void waitForTaskInBasket(String adviceId, RatesBasket basket) {
        String baseUrl = TestContext.getGlobalAliases().get("url");
        EnvironmentsSetup.User user = TestContext.getTestProperties().getTestEnvironment().getUser("reviewer1-11");
        try {
            RatesSession session = new RatesSession(baseUrl, user.getUserName(), user.getPassword());
            System.out.println("Waiting for task with adviceid " + adviceId + " in basket " + basket.getBasketName());
            new RatesTask().waitForTask(session, basket.getBasketId(), adviceId);
        } catch (IOException |InterruptedException ignore) {}
    }

}
