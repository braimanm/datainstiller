package com.rbccm.taf.mandate.api;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rbccm.taf.common.api.AlfrescoApiBase;
import com.rbccm.taf.ui.support.EnvironmentsSetup;
import com.rbccm.taf.ui.support.TestContext;
import com.rbccm.taf.ui.utils.Helper;
import org.apache.http.client.utils.URIBuilder;
import org.assertj.core.api.Assertions;
import org.jsoup.Connection;
import org.jsoup.nodes.Document;

import java.io.IOException;
import java.net.URISyntaxException;

@JsonIgnoreProperties(ignoreUnknown=true)
public class PositionMandate {
    public String positionTitle;
    public String positionStatus;

    public static PositionMandate[] getPositions(String userRole) {
        EnvironmentsSetup.Environment env = TestContext.getTestProperties().getTestEnvironment();
        EnvironmentsSetup.User user = env.getUser(userRole);
        String urlBase;
        try {
            URIBuilder uriBuilder = new URIBuilder(env.getUrl());
            urlBase = uriBuilder.setPath("").build().toString();
        } catch (URISyntaxException e) {
            throw new RuntimeException(e);
        }
        AlfrescoApiBase api = new AlfrescoApiBase(urlBase);
        Connection con = null;
        PositionMandate[] positionMandates = null;
        try {
            con = api.getAlfrescoConnection("/alfresco/s/com/microstrat/rbc/positionMandate", user.getUserName(), user.getPassword());
            con.method(Connection.Method.GET);
            con.data("userName",user.getUserName());
            Connection.Response res = con.execute();
            Document doc = res.parse();
            ObjectMapper mapper = new ObjectMapper();
            String content = doc.body().text();
            if (content.isEmpty()) {
                positionMandates = new PositionMandate[]{};
            } else {
                positionMandates = mapper.readValue(content, PositionMandate[].class);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return positionMandates;
    }

    public static PositionMandate getPosition(String userRole, String positionTitle) {
        PositionMandate[] positions = getPositions(userRole);
        for (PositionMandate position : positions) {
            if (position.positionTitle.equals(positionTitle)) {
                return position;
            }
        }
        return null;
    }

    public static void waitForPositionStatus(String userRole, String positionTitle, String status) {
        PositionMandate position = null;
        long t_o = System.currentTimeMillis() + 60000;
        boolean done = false;
        do {
            position = getPosition(userRole, positionTitle);
            if (position != null && position.positionStatus.equals(status)) {
                done = true;
            } else {
                Helper.sleep(500);
            }
        } while (System.currentTimeMillis() < t_o && !done);
        if (!done) {
            Assertions.assertThat(position.positionStatus).isEqualTo(status);
        }
    }

}
