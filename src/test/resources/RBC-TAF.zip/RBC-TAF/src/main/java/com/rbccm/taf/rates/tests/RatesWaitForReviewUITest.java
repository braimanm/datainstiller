package com.rbccm.taf.rates.tests;
import com.rbccm.taf.rates.components.RatesDocumentEntry;
import com.rbccm.taf.rates.components.RatesDocumentProperty;
import com.rbccm.taf.rates.components.RatesTaskEntry;
import com.rbccm.taf.rates.components.RatesTaskProperty;
import com.rbccm.taf.rates.domainobjects.RatesNoStepsDOM;
import com.rbccm.taf.rates.domainobjects.RatesStep;
import com.rbccm.taf.rates.pageobjects.RatesActiFlowPOM;
import com.rbccm.taf.rates.pageobjects.RatesFileCabinetPOM;
import com.rbccm.taf.rates.pageobjects.RatesLoginPOM;
import com.rbccm.taf.ui.testng.TestNGBase;
import org.assertj.core.api.Assertions;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.Description;
import ru.yandex.qatools.allure.annotations.Features;

import java.io.IOException;

@Features("Verify right click functionalities for Wait for review trade")
@Description("Vanilla Review 1 --> 2nd Review Vanilla -->Forward for review --> Wait for review--> Show Workflow status -->Show Annotation -->Show Document attributes-->Update reviewer-->Withdraw")
public class RatesWaitForReviewUITest extends TestNGBase {
    private String adviceId;


    @Parameters({"data-set1"})
    @Test
    public void tc004_01(@Optional("data/rates/TC004_Vanilla_ReviewII_Verify_the_right_click_functionalities_for_Wait_for_Review_trades/TC004_01.xml") String dataSet) throws IOException, InterruptedException {

        RatesNoStepsDOM rates = new RatesNoStepsDOM(dataSet);
        adviceId = rates.uploadGeneratedFeedFiles();

        RatesLoginPOM login = rates.getLoginPOM(getContext());
        login.login();

        RatesActiFlowPOM actiFlow = rates.getActiFlowPOM();
        actiFlow.selectBasket();

        RatesTaskEntry task = actiFlow.getTaskByAdviceId(adviceId);
        task.validateActions();
        task.doAction();

        new RatesStep().waitForTaskInBasket(adviceId, actiFlow.getDestinationBasket());

        actiFlow.validateTaskMigration(adviceId);

    }

    @Parameters({"data-set2"})
    @Test(dependsOnMethods = "tc004_01")
    public void tc004_02(@Optional("data/rates/TC004_Vanilla_ReviewII_Verify_the_right_click_functionalities_for_Wait_for_Review_trades/TC004_02.xml") String dataSet) throws IOException, InterruptedException {
        RatesNoStepsDOM rates = new RatesNoStepsDOM(dataSet);

        RatesLoginPOM login = rates.getLoginPOM(getContext());
        login.login();

        RatesActiFlowPOM actiFlow = rates.getActiFlowPOM();
        actiFlow.selectBasket();


        RatesTaskEntry task = actiFlow.getTaskByAdviceId(adviceId);
        task.validateActions();
        task.doAction();

        task = actiFlow.getTaskByAdviceId(adviceId);
        Assertions.assertThat(task.getProperty(RatesTaskProperty.Task)).isEqualTo("Wait For Review");
    }

    @Parameters({"data-set3"})
    @Test(dependsOnMethods = "tc004_02")
    public void tc004_03(@Optional("data/rates/TC004_Vanilla_ReviewII_Verify_the_right_click_functionalities_for_Wait_for_Review_trades/TC004_03.xml") String dataSet) throws IOException, InterruptedException{
        RatesNoStepsDOM rates = new RatesNoStepsDOM(dataSet);

        RatesLoginPOM login = rates.getLoginPOM(getContext());
        login.login();

        RatesActiFlowPOM actiFlow = rates.getActiFlowPOM();
        actiFlow.selectBasket();

        RatesTaskEntry task = actiFlow.getTaskByAdviceId(adviceId);
        task.validateActions();
        task.doAction();
    }

    @Parameters({"data-set4"})
    @Test(dependsOnMethods = "tc004_03")
    public void tc004_04(@Optional("data/rates/TC004_Vanilla_ReviewII_Verify_the_right_click_functionalities_for_Wait_for_Review_trades/TC004_04.xml") String dataSet) throws IOException, InterruptedException{
        RatesNoStepsDOM rates = new RatesNoStepsDOM(dataSet);

        RatesLoginPOM login = rates.getLoginPOM(getContext());
        login.login();

        RatesActiFlowPOM actiFlow = rates.getActiFlowPOM();
        actiFlow.selectBasket();

        RatesTaskEntry task = actiFlow.getTaskByAdviceId(adviceId);
        task.validateActions();
        task.doAction();
        RatesFileCabinetPOM fileCabinetPOM = actiFlow.getFileCabinetPOM();
        fileCabinetPOM.searchForDocument("Advice Id :" + adviceId);
        RatesDocumentEntry documentEntry = fileCabinetPOM.getDocument(0);
        Assertions.assertThat(documentEntry.getProperty(RatesDocumentProperty.StatusCode)).isEqualTo("NEW");
    }

    @Parameters({"data-set5"})
    @Test(dependsOnMethods = "tc004_04")
    public void tc004_05(@Optional("data/rates/TC004_Vanilla_ReviewII_Verify_the_right_click_functionalities_for_Wait_for_Review_trades/TC004_05.xml") String dataSet) throws IOException, InterruptedException{
        RatesNoStepsDOM rates = new RatesNoStepsDOM(dataSet);

        RatesLoginPOM login = rates.getLoginPOM(getContext());
        login.login();

        RatesActiFlowPOM actiFlow = rates.getActiFlowPOM();
        actiFlow.selectBasket();
        RatesTaskEntry task = actiFlow.getTaskByAdviceId(adviceId);
        task.doAction();
    }

    @Parameters({"data-set6"})
    @Test(dependsOnMethods = "tc004_05")
    public void tc004_06(@Optional("data/rates/TC004_Vanilla_ReviewII_Verify_the_right_click_functionalities_for_Wait_for_Review_trades/TC004_06.xml") String dataSet) throws IOException, InterruptedException{
        RatesNoStepsDOM rates = new RatesNoStepsDOM(dataSet);

        RatesLoginPOM login = rates.getLoginPOM(getContext());
        login.login();

        RatesActiFlowPOM actiFlow = rates.getActiFlowPOM();
        actiFlow.selectBasket();

        RatesTaskEntry task = actiFlow.getTaskByAdviceId(adviceId);
        task.doAction();
    }

    @Parameters({"data-set7"})
    @Test(dependsOnMethods = "tc004_06")
    public void tc004_07(@Optional("data/rates/TC004_Vanilla_ReviewII_Verify_the_right_click_functionalities_for_Wait_for_Review_trades/TC004_07.xml") String dataSet) throws IOException, InterruptedException{
        RatesNoStepsDOM rates = new RatesNoStepsDOM(dataSet);

        RatesLoginPOM login = rates.getLoginPOM(getContext());
        login.login();

        RatesActiFlowPOM actiFlow = rates.getActiFlowPOM();
        actiFlow.selectBasket();

        RatesTaskEntry task = actiFlow.getTaskByAdviceId(adviceId);
        task.doAction();
        RatesFileCabinetPOM fileCabinetPOM = actiFlow.getFileCabinetPOM();
        fileCabinetPOM.searchForDocument("Advice Id :" + adviceId);
        RatesDocumentEntry documentEntry = fileCabinetPOM.getDocument(0);
        Assertions.assertThat(documentEntry.getProperty(RatesDocumentProperty.StatusCode)).isEqualTo("NEW");
    }



}
