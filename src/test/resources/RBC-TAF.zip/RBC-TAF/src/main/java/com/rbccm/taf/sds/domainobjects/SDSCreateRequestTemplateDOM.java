package com.rbccm.taf.sds.domainobjects;


import com.rbccm.taf.sds.pageobjects.SDSCreateNewRequestPOM;
import com.rbccm.taf.sds.pageobjects.SDSLoginPOM;
import com.rbccm.taf.ui.support.DomainObjectModel;
import com.rbccm.taf.ui.support.TestContext;
import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("crete-request-template")
public class SDSCreateRequestTemplateDOM extends DomainObjectModel {
    public SDSLoginPOM loginPOM;
    public SDSCreateNewRequestPOM createRequestTemplate;

    public SDSCreateRequestTemplateDOM() {
    }

    public SDSCreateRequestTemplateDOM(TestContext context) {
        this.context = context;
    }

    public void login() {
        loginPOM.initPage(context);
        loginPOM.navigate();
        loginPOM.login();
    }

    public SDSCreateNewRequestPOM getNewRequest() {
        createRequestTemplate.initPage(context);
        createRequestTemplate.createNewRequest();
        return createRequestTemplate;
    }

}
