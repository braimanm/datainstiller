package com.rbccm.taf.commodities.api;

import com.rbccm.taf.rates.api.OrderedProperties;

import java.io.IOException;
import java.util.Map;

public class CommoditiesIndexFile {
    private String adviceId;
    private OrderedProperties props;

    public CommoditiesIndexFile(String adviceId) {
        this.adviceId = adviceId;
        props = new OrderedProperties();
        try {
            props.load(this.getClass().getResourceAsStream("/data/commodities/feed/ADVICE.index"));
        } catch (IOException e) {
            throw new RuntimeException("Can't read the ADVICE.index file!");
        }

        props.setProperty("DOCUMENT_ID" , adviceId);
        props.setProperty("ADVICE_ID" , adviceId);
        props.setProperty("TRADE_ID" , adviceId);
        props.setProperty("TRANS_ID" , adviceId);
    }

    public OrderedProperties getProps() {
        return props;
    }

      public CommoditiesIndexFile setFlag(CommoditiesIndexFileFlag flag, boolean value) {
        props.setProperty(flag.getName() , (value) ? "1" : "0");
        return this;
    }

    public CommoditiesIndexFile setAttribute(CommoditiesIndexFileAttribute field) {
        if (props.containsProperty(field.getName())) {
            props.setProperty(field.getName(), field.getValue());
        } else {
            throw new RuntimeException("The attribute " + field.getName() + " is not exists in the index file");
        }
        return this;
    }

    public byte[] getPropsAsBytes() throws IOException {
        StringBuilder out = new StringBuilder();
        for (Map.Entry<String, String> entry : props.entrySet()) {
            out.append(entry.getKey()).append(":     ").append(entry.getValue()).append("\n");
        }
        return out.toString().getBytes();
    }

    public String getProperty(String propertyName) {
        return props.getProperty(propertyName);
    }



}
