package com.rbccm.taf.rlm.pageobjects;

import com.rbccm.taf.rlm.components.RLMRadioGroup;
import com.rbccm.taf.rlm.components.RLMSelect;
import com.rbccm.taf.ui.support.PageObjectModel;
import com.rbccm.taf.ui.utils.Helper;
import datainstiller.data.Data;
import org.openqa.selenium.support.FindBy;
import ru.yandex.qatools.allure.annotations.Step;
import ui.auto.core.components.WebComponent;
import ui.auto.core.pagecomponent.PageComponent;

import static org.assertj.core.api.Assertions.assertThat;

@SuppressWarnings("unused")
public class RLMPortwareFormPOM extends PageObjectModel {
    @FindBy(id = "portwaredurationtype")
    private RLMRadioGroup durationType;
    @FindBy(id = "portwaretypeofchange")
    private RLMSelect typeOfChange;
    @FindBy(id = "portwarerangelimit")
    private RLMSelect rangeLimit;
    @FindBy(id = "portwareexistinglimit")
    private WebComponent existingLimit;
    @FindBy(id = "portwarenewlimit")
    private WebComponent newLimit;
    @FindBy(id = "portwareexpiredate")
    private WebComponent expireDate;
    @FindBy(id = "portwareexpirehour")
    private RLMSelect expireHour;
    @FindBy(id = "portwareexpireminute")
    private RLMSelect expireMinute;
    @FindBy(id = "portwareamorpm")
    private RLMSelect amOrPm;

    //Fields for Form Validation
    @Data(skip = true)
    @FindBy(id = "portwaretypeofchange")
    private WebComponent valTypeOfChange;
    @Data(skip = true)
    @FindBy(id = "portwaredurationtype")
    private WebComponent valDurationType;
    @Data(skip = true)
    @FindBy(id = "portwareexpirydate")
    private WebComponent valExpiryDate;
    @Data(skip = true)
    @FindBy(id = "portwarerangelimit")
    private WebComponent valRangelimit;
    @Data(skip = true)
    @FindBy(id = "portwareexistinglimit")
    private WebComponent valExistingLimit;
    @Data(skip = true)
    @FindBy(id = "portwarenewlimit")
    private WebComponent valNewLimit;

    @Step("Populate PORTWARE Request Form with provided data")
    void fill() {
        autoFillPage();
    }

    @Step("Validate PORTWARE Request Form")
    public void validate() {
        if (isDataProvided(typeOfChange)) {
            validateComponentValue(valTypeOfChange, typeOfChange.getData(), "Portware Type of Change");
        }
        if (isDataProvided(durationType)) {
            validateComponentValue(valDurationType, durationType.getData(), "Portware Duration Type");
        }
        if (isDataProvided(rangeLimit)) {
            validateComponentValue(valRangelimit, rangeLimit.getData(), "Portware Range Limit");
        }
        if (isDataProvided(existingLimit)) {
            validateComponentValue(valExistingLimit, existingLimit.getData(), "Portware Existing limit");
        }
        if (isDataProvided(newLimit)) {
            validateComponentValue(valNewLimit, newLimit.getData(), "Portware New Limit");
        }
        if (isDataProvided(expireDate)) {
            String expiryDateData = expireDate.getData() + " " + expireHour.getData() + ":" +
                    expireMinute.getData() + " " + amOrPm.getData();
            String data = Helper.convertDate("d-M-yyyy hh:mm a", "yyyy-MM-dd hh:mm a", expiryDateData);
            validateComponentValue(valExpiryDate, data, "Portware Expiry Date");
        }
    }

    private boolean isDataProvided(PageComponent component) {
        return (component.getData() != null && !component.getData().isEmpty());
    }

    @Step("Validating field \"{2}\" has a value of \"{1}\"")
    private void validateComponentValue(PageComponent component, String data, String field) {
        if (data != null && !data.isEmpty()) {
            assertThat(component.getValue()).isEqualToIgnoringCase(data);
        }
    }
}
