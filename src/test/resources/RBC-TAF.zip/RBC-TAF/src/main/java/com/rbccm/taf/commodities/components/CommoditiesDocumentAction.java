package com.rbccm.taf.commodities.components;

public enum CommoditiesDocumentAction {
    Open("Open"),
    ShowAnnotation("Show Annotations"),
    AddDocuments("Add Documents"),
    Download("Download"),
    Compare("Compare");
    String action;

    CommoditiesDocumentAction(String action) {
        this.action = action;
    }

    public String getAction() {
        return action;
    }
}
