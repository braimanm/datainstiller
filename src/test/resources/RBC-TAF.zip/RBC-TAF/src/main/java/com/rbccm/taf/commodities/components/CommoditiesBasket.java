package com.rbccm.taf.commodities.components;


public enum CommoditiesBasket {

    InvoiceRepair("Invoice Repair", "1"),
    InvoiceReview("Invoice Review", "2"),
    VanillaReviewI("Vanilla Confirmations Review I", "3"),
    VanillaReviewII("Vanilla Confirmations Review II", "4"),
    ReleaseDelay("Release Delay", "5"),
    Remove("Remove", "6"),
    FaxEmailError("Fax/Email Error", "7"),
    OutstandingConfirmations("Outstanding Confirmations", "8"),
    OutstandingInvoices("Outstanding Invoices", "9"),
    ManualIndex("Manual Index", "10"),
    ReviewReturnedConfirmation("Review Returned Confirmations", "11"),
    DeleteIncomingEmailOrFax("Delete Incoming Email/Fax", "12"),
    Investigations("Investigations", "13"),
    SecondReviewIncoming("2nd Review Incoming", "14"),
    StpReview("STP Review", "15"),
    ErrorRetry("Error Retry", "16");


    String basketName;
    String basketId;

    CommoditiesBasket(String name, String id) {
        basketName = name;
        basketId = id;
    }

    public String getBasketName() {
        return basketName;
    }

    public String getBasketId() {
        return basketId;
    }

    public static CommoditiesBasket getBasketForName(String basketName) {
        for (CommoditiesBasket basket : CommoditiesBasket.values()) {
            if (basket.getBasketName().equals(basketName)) return basket;
        }
        return null;
    }

}
