package com.rbccm.taf.rates.tests.perf;

import com.rbccm.taf.rates.tests.perf.RatesStatistics2;
import org.testng.annotations.Factory;

public class RatesStatistics2Factory {

    @Factory()
    public Object[] createInstances() {
        int threads = 10;
        Object[] result = new Object[threads];
        for (int i = 0; i < threads; i++) {
            result[i] = new RatesStatistics2(i + 1);
        }
        return result;
    }
}
