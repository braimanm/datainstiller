package com.rbccm.taf.commodities.domainobjects;

import com.rbccm.taf.commodities.api.CommoditiesIndexFile;
import com.rbccm.taf.commodities.api.CommoditiesIndexFileAttribute;
import com.rbccm.taf.commodities.api.CommoditiesIndexFileFlag;
import com.rbccm.taf.commodities.api.CommoditiesSCP;
import com.rbccm.taf.ui.support.AliasedString;
import com.rbccm.taf.ui.support.DomainObjectModel;
import com.rbccm.taf.ui.support.EnvironmentsSetup;
import com.rbccm.taf.ui.support.TestContext;
import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;
import org.apache.commons.io.IOUtils;
import ru.yandex.qatools.allure.annotations.Step;

import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Set;


@XStreamAlias("commodities-domain-object")
public class CommoditiesDOM extends DomainObjectModel {
    private AliasedString envUrl;
    private AliasedString feedDestinationFolder;
    private AliasedString adviceId;
    private Set<CommoditiesIndexFileFlag> indexFlags;
    private Set<CommoditiesIndexFileAttribute> indexAttributes;
    @XStreamImplicit
    private List<CommoditiesStep> functionalSteps;

    public CommoditiesDOM() {}
    public CommoditiesDOM(String dataset) {
        initData(fromResource(dataset));
    }

    private void uploadFiles(CommoditiesIndexFile indexFile) throws IOException, InterruptedException {
        String doc = "data/commodities/feed/ADVICE.html";
        InputStream isDoc = getClass().getClassLoader().getResourceAsStream(doc);
        byte[] document = IOUtils.toByteArray(isDoc);
        IOUtils.closeQuietly(isDoc);
        String timestamp = DateTimeFormatter.ofPattern("yyMMddkkmmss").format(LocalDateTime.now()) + Thread.currentThread().getId();
        String adviceId = "E" + timestamp;
        byte[] index = indexFile.getPropsAsBytes();
        EnvironmentsSetup.User usr = TestContext.getTestProperties().getTestEnvironment().getUser("ssh");
        String sshServer = envUrl.getData();
        sshServer = sshServer.substring(sshServer.indexOf(":") + 3, sshServer.lastIndexOf(":"));
        CommoditiesSCP scp = new CommoditiesSCP(sshServer, usr.getUserName(), usr.getPassword());
        scp.transferFile(document, adviceId + ".html", feedDestinationFolder.getData());
        scp.transferFile(index, adviceId + ".INDEX", feedDestinationFolder.getData());
        System.out.println("Task with advice id " + adviceId + " was created and moved to server");
    }

    @Step("Upload feed files and wait for task to appear in destination folder")
    public String uploadGeneratedFeedFiles() throws IOException, InterruptedException {
        CommoditiesStep step = functionalSteps.get(0);
        CommoditiesIndexFile indexFile = new CommoditiesIndexFile(adviceId.getData());
        if (indexFlags != null) {
            for (CommoditiesIndexFileFlag flag : indexFlags) {
                indexFile.setFlag(flag, true);
            }
        }
        if (indexAttributes != null) {
            for (CommoditiesIndexFileAttribute attribute : indexAttributes) {
                indexFile.setAttribute(attribute);
            }
        }
        String adviceId = indexFile.getProperty("ADVICE_ID");
        uploadFiles(indexFile);
        step.waitForTaskInBasket(adviceId, step.actiFlow.getSourceBasket());
        return adviceId;
    }


    public CommoditiesStep getFunctionalStep(int i) {
        return functionalSteps.get(i);
    }

    public List<CommoditiesStep> getfunctionalSteps() {
        return functionalSteps;
    }
}
