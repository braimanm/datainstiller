package com.rbccm.taf.commodities.tests.functional;

import com.rbccm.taf.commodities.components.CommoditiesTaskEntry;
import com.rbccm.taf.commodities.domainobjects.CommoditiesNoStepsDOM;
import com.rbccm.taf.commodities.pageobjects.CommoditiesActiFlowPOM;
import com.rbccm.taf.commodities.pageobjects.CommoditiesLoginPOM;
import com.rbccm.taf.ui.testng.TestNGBase;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.Description;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

import java.io.IOException;

@Features("Maker Checker functionality")
@Stories("Verify trade can be forwarded to Invoice Review and verify the maker checker functionality")
@Description("Invoice Repair --> Invoice Review --> Maker Checker validation")
public class CommoditiesInvoiceFlowUITest extends TestNGBase {
    private String adviceId;


    @Parameters({"data-set1"})
    @Test
    public void tc003_01(@Optional("data/commodities/functional/InvoiceFlow/TC002_TC003_TC004_Invoice_Flow/TC001_01.xml") String dataSet) throws IOException, InterruptedException {

        CommoditiesNoStepsDOM comm = new CommoditiesNoStepsDOM(dataSet);
        adviceId = comm.uploadGeneratedFeedFiles();

        CommoditiesLoginPOM login = comm.getLoginPOM(getContext());
        login.login();

        CommoditiesActiFlowPOM actiFlow = comm.getActiFlowPOM();

        actiFlow.selectBasket();

        CommoditiesTaskEntry task = actiFlow.getTaskByAdviceId(adviceId);
        task.validateActions();
        task.doAction();
        actiFlow.validateTaskMigration(adviceId);
    }

    @Parameters({"data-set2"})
    @Test(dependsOnMethods = "tc003_01")
    public void tc003_02(@Optional("data/commodities/functional/InvoiceFlow/TC002_TC003_TC004_Invoice_Flow/TC001_02.xml") String dataSet) throws IOException, InterruptedException{
        CommoditiesNoStepsDOM comm = new CommoditiesNoStepsDOM(dataSet);

        CommoditiesLoginPOM login = comm.getLoginPOM(getContext());
        login.login();

        CommoditiesActiFlowPOM actiFlow = comm.getActiFlowPOM();

        actiFlow.selectBasket();

        CommoditiesTaskEntry task = actiFlow.getTaskByAdviceId(adviceId);
        task.validateActions();
        task.doAction();
        actiFlow.validateTaskMigration(adviceId);
        task.doubleClick(adviceId);
    }

}
