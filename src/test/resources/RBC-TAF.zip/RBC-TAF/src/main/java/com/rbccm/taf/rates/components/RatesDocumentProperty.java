package com.rbccm.taf.rates.components;

public enum RatesDocumentProperty {

    DocumentName,
    ConfirmationType,
    DocumentType,
    StatusCode,
    Created,
    Counterparty,
    AdviceId,
    TransID,
    TradeId,
    Product,
    PaymentDate,
    Annotations

}
