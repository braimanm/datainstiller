package com.rbccm.taf.rlm.pageobjects;

import com.rbccm.taf.ui.support.AliasedString;
import com.rbccm.taf.ui.support.PageObjectModel;
import com.rbccm.taf.ui.utils.Helper;
import datainstiller.data.Data;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import ru.yandex.qatools.allure.annotations.Step;
import ui.auto.core.components.WebComponent;
import ui.auto.core.pagecomponent.PageComponent;
import ui.auto.core.pagecomponent.SkipAutoValidate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

import static org.assertj.core.api.Assertions.assertThat;

@SuppressWarnings("unused")
public class RLMAuditTrailPOM extends RLMMainPOM {
    @Data(skip = true)
    @FindBy(xpath = "//table[@class='table table-dash']//span[.='  New']/../..//button")
    private WebComponent openNew;
    @Data(skip = true)
    @FindBy(xpath = "//table[@class='table table-dash']//span[.='  Approved']/../..//button")
    private WebComponent openApproved;
    @Data(skip = true)
    @FindBy(xpath = "//table[@class='table table-dash']//span[.='  Change Complete']/../..//button")
    private WebComponent openChangeComplete;
    @Data(skip = true)
    @FindBy(xpath = "//table[@class='table table-dash']//span[.='  Rejected']/../..//button")
    private WebComponent openRejected;
    @Data(skip = true)
    @FindBy(xpath = "//table[@class='table table-dash']//span[.='  Cancelled']/../..//button")
    private WebComponent openCancelled;


    @Data(alias = "requestor-name")
    @FindBy(xpath = "//table[@class='table table-dash']//span[.='  New']/../../td[2]")
    private WebComponent newUsers;
    @Data(alias = "requestor-submit-time")
    @FindBy(xpath = "//table[@class='table table-dash']//span[.='  New']/../../td[3]")
    private WebComponent newTime;
    @Data(alias = "requestor-submit-date")
    @FindBy(xpath = "//table[@class='table table-dash']//span[.='  New']/../../td[4]")
    private WebComponent newDate;
    @Data(alias = "approver-name")
    @FindAll({
            @FindBy(xpath = "//table[@class='table table-dash']//span[.='  Approved']/../../td[2]"),
            @FindBy(xpath = "//table[@class='table table-dash']//span[.='  Rejected']/../../td[2]")
    })
    private WebComponent approvedUsers;
    @Data(alias = "approver-submit-time")
    @FindAll({
            @FindBy(xpath = "//table[@class='table table-dash']//span[.='  Approved']/../../td[3]"),
            @FindBy(xpath = "//table[@class='table table-dash']//span[.='  Rejected']/../../td[3]")
    })
    private WebComponent approvedTime;
    @Data(alias = "approver-submit-date")
    @FindAll({
            @FindBy(xpath = "//table[@class='table table-dash']//span[.='  Approved']/../../td[4]"),
            @FindBy(xpath = "//table[@class='table table-dash']//span[.='  Rejected']/../../td[4]")
    })
    private WebComponent approvedDate;
    @Data(alias = "implementor-name")
    @FindAll({
            @FindBy(xpath = "//table[@class='table table-dash']//span[.='  Change Complete']/../../td[2]"),
            @FindBy(xpath = "//table[@class='table table-dash']//span[.='  Cancelled']/../../td[2]")
    })
    private WebComponent changeCompleteUsers;
    @Data(alias = "implementor-submit-time")
    @FindAll({
            @FindBy(xpath = "//table[@class='table table-dash']//span[.='  Change Complete']/../../td[3]"),
            @FindBy(xpath = "//table[@class='table table-dash']//span[.='  Cancelled']/../../td[3]")
    })
    private WebComponent changeCompleteTime;
    @Data(alias = "implementor-submit-date")
    @FindAll({
            @FindBy(xpath = "//table[@class='table table-dash']//span[.='  Change Complete']/../../td[4]"),
            @FindBy(xpath = "//table[@class='table table-dash']//span[.='  Cancelled']/../../td[4]")
    })
    private WebComponent changeCompleteDate;
    @Data("Submitted,Approved,Implemented")
    @FindBy(xpath = "//div[@class='audit-info']//td[.=' Action:']/following-sibling::td")
    private WebComponent action;
    @Data("${requestor-name},${approver-name},${implementor-name}")
    @FindBy(xpath = "//div[@class='audit-info']//td[.='User:']/following-sibling::td")
    private WebComponent user;

    private FidessaAuditTrail fidessa;
    private ThorAuditTrail thor;
    private TitanAuditTrail titan;
    private PortwareAuditTrail portware;
    private CadEtfAuditTrail cadetf;
    private NextGenAuditTrail nextgen;

    @Data(alias = "effective-date")
    @FindBy(xpath = "//div[@class='audit-info']//td[.='Effective Date:']/following-sibling::td")
    private WebComponent effectiveDate;
    @Data(alias = "requestor-comments")
    @FindBy(xpath = "//div[@class='audit-info']//td[.='Requestor Comments:']/following-sibling::td")
    private WebComponent requestorComments;
    @Data(alias = "approver-coments")
    @FindBy(xpath = "//div[@class='audit-info']//td[.='Approver / Rejecter Comments:']/following-sibling::td")
    private WebComponent approverComments;
    @Data(alias = "implementor-comments")
    @FindBy(xpath = "//div[@class='audit-info']//td[contains(.,'Implementor Comments')]/following-sibling::td")
    private WebComponent implementorComments;


    private static class FidessaAuditTrail extends PageObjectModel {
        @SkipAutoValidate
        @Data(alias = "fidessa-include")
        private AliasedString validate;
        @Data(alias = "fidessa-traderName")
        @FindBy(xpath = "//div[@class='audit-info']//td[.='Fidessa']/../following-sibling::tr/td[.='Trader Name:']/following-sibling::td")
        private WebComponent traderName;
        @Data(alias = "fidessa-clientName")
        @FindBy(xpath = "//div[@class='audit-info']//td[.='Fidessa']/../following-sibling::tr/td[.='Client/Account Name:']/following-sibling::td")
        private WebComponent clientName;
        @Data(alias = "fidessa-existingLimit")
        @FindBy(xpath = "//div[@class='audit-info']//td[.='Fidessa']/../following-sibling::tr/td[.='Existing Limit:']/following-sibling::td")
        private WebComponent existingLimit;
        @Data(alias = "fidessa-newLimit")
        @FindBy(xpath = "//div[@class='audit-info']//td[.='Fidessa']/../following-sibling::tr/td[.='New Limit:']/following-sibling::td")
        private WebComponent newLimit;
        @Data(alias = "fidessa-typeOfChange")
        @FindBy(xpath = "//div[@class='audit-info']//td[.='Fidessa']/../following-sibling::tr/td[.='Type of Change:']/following-sibling::td")
        private WebComponent typeOfChange;
        @Data(alias = "fidessa-priceToleranceSoftWarningRange")
        @FindBy(xpath = "//div[@class='audit-info']//td[.='Fidessa']/../following-sibling::tr/td[.='Ranges:']/following-sibling::td")
        private WebComponent ranges;
        @Data(alias = "fidessa-durationType")
        @FindBy(xpath = "//div[@class='audit-info']//td[.='Fidessa']/../following-sibling::tr/td[.='Duration Type:']/following-sibling::td")
        private WebComponent durationType;
        @SkipAutoValidate
        @Data("${fidessa-expireDate} ${fidessa-expireHour}:${fidessa-expireMinute} ${fidessa-amOrPm}")
        @FindBy(xpath = "//div[@class='audit-info']//td[.='Fidessa']/../following-sibling::tr/td[.=' Expiry Date:']/following-sibling::td")
        private WebComponent expiryDate;

        void validateInfo() {
            if (validate.getData().equals("true")) {
                validate();
            }
        }

        @Step("Validate Audit Trail for Fidessa")
        private void validate() {
            autoValidatePage();
            if (expiryDate.getData() != null && !expiryDate.getData().isEmpty() ) {
                String date = Helper.convertDate("d-M-yyyy hh:mm a", "yyyy-MM-dd h:mm a", expiryDate.getData());
                expiryDate.validateData(date);
            }
        }
    }

    private static class ThorAuditTrail extends PageObjectModel {
        @SkipAutoValidate
        @Data(alias = "thor-include")
        private AliasedString validate;
        @Data(alias = "thor-existingLimit")
        @FindBy(xpath = "//div[@class='audit-info']//td[.='Thor']/../following-sibling::tr/td[.='Existing Limit:']/following-sibling::td")
        private WebComponent existingLimit;
        @Data(alias = "thor-newLimit")
        @FindBy(xpath = "//div[@class='audit-info']//td[.='Thor']/../following-sibling::tr/td[.='New Limit:']/following-sibling::td")
        private WebComponent newLimit;
        @Data(alias = "thor-typeOfChange")
        @FindBy(xpath = "//div[@class='audit-info']//td[.='Thor']/../following-sibling::tr/td[.='Type of Change:']/following-sibling::td")
        private WebComponent typeOfChange;
        @Data(alias = "thor-durationType")
        @FindBy(xpath = "//div[@class='audit-info']//td[.='Thor']/../following-sibling::tr/td[.='Duration Type:']/following-sibling::td")
        private WebComponent durationType;
        @SkipAutoValidate
        @Data("${thor-expireDate} ${thor-expireHour}:${thor-expireMinute} ${thor-amOrPm}")
        @FindBy(xpath = "//div[@class='audit-info']//td[.='Thor']/../following-sibling::tr/td[.=' Expiry Date:']/following-sibling::td")
        private WebComponent expiryDate;

        void validateInfo() {
            if (validate.getData().equals("true")) {
                validate();
            }
        }

        @Step("Validate Audit Trail for Thor")
        private void validate() {
            autoValidatePage();
            if (expiryDate.getData() != null && !expiryDate.getData().isEmpty()) {
                String date = Helper.convertDate("d-M-yyyy hh:mm a", "yyyy-MM-dd h:mm a", expiryDate.getData());
                expiryDate.validateData(date);
            }
        }
    }

    private static class TitanAuditTrail extends PageObjectModel {
        @SkipAutoValidate
        @Data(alias = "titan-include")
        private AliasedString validate;
        @Data(alias = "titan-existingLimit")
        @FindBy(xpath = "//div[@class='audit-info']//td[.='Titan']/../following-sibling::tr/td[.='Existing Limit:']/following-sibling::td")
        private WebComponent existingLimit;
        @Data(alias = "titan-newLimit")
        @FindBy(xpath = "//div[@class='audit-info']//td[.='Titan']/../following-sibling::tr/td[.='New Limit:']/following-sibling::td")
        private WebComponent newLimit;
        @Data(alias = "titan-typeOfChange")
        @FindBy(xpath = "//div[@class='audit-info']//td[.='Titan']/../following-sibling::tr/td[.='Type of Change:']/following-sibling::td")
        private WebComponent typeOfChange;
        @Data(alias = "titan-durationType")
        @FindBy(xpath = "//div[@class='audit-info']//td[.='Titan']/../following-sibling::tr/td[.='Duration Type:']/following-sibling::td")
        private WebComponent durationType;
        @SkipAutoValidate
        @Data("${thor-expireDate} ${titan-expireHour}:${titan-expireMinute} ${titan-amOrPm}")
        @FindBy(xpath = "//div[@class='audit-info']//td[.='Titan']/../following-sibling::tr/td[.=' Expiry Date:']/following-sibling::td")
        private WebComponent expiryDate;

        void validateInfo() {
            if (validate.getData().equals("true")) {
                validate();
            }
        }

        @Step("Validate Audit Trail for Titan")
        private void validate() {
            autoValidatePage();
           if (expiryDate.getData() != null && !expiryDate.getData().isEmpty()) {
                String date = Helper.convertDate("d-M-yyyy hh:mm a", "yyyy-MM-dd h:mm a", expiryDate.getData());
                expiryDate.validateData(date);
            }
        }
    }

    private static class PortwareAuditTrail extends PageObjectModel {
        @SkipAutoValidate
        @Data(alias = "portware-include")
        private AliasedString validate;
        @Data(alias = "portware-existingLimit")
        @FindBy(xpath = "//div[@class='audit-info']//td[.='Portware']/../following-sibling::tr/td[.='Existing Limit:']/following-sibling::td")
        private WebComponent existingLimit;
        @Data(alias = "portware-newLimit")
        @FindBy(xpath = "//div[@class='audit-info']//td[.='Portware']/../following-sibling::tr/td[.='New Limit:']/following-sibling::td")
        private WebComponent newLimit;
        @Data(alias = "portware-typeOfChange")
        @FindBy(xpath = "//div[@class='audit-info']//td[.='Portware']/../following-sibling::tr/td[.='Type of Change:']/following-sibling::td")
        private WebComponent typeOfChange;
        @Data(alias = "portware-rangeLimit")
        @FindBy(xpath = "//div[@class='audit-info']//td[.='Portware']/../following-sibling::tr/td[.='Ranges:']/following-sibling::td")
        private WebComponent ranges;
        @Data(alias = "portware-durationType")
        @FindBy(xpath = "//div[@class='audit-info']//td[.='Portware']/../following-sibling::tr/td[.='Duration Type:']/following-sibling::td")
        private WebComponent durationType;
        @SkipAutoValidate
        @Data("${portware-expireDate} ${portware-expireHour}:${portware-expireMinute} ${portware-amOrPm}")
        @FindBy(xpath = "//div[@class='audit-info']//td[.='Portware']/../following-sibling::tr/td[.=' Expiry Date:']/following-sibling::td")
        private WebComponent expiryDate;

        void validateInfo() {
            if (validate.getData().equals("true")) {
                validate();
            }
        }

        @Step("Validate Audit Trail for Portware")
        private void validate() {
            autoValidatePage();
           if (expiryDate.getData() != null && !expiryDate.getData().isEmpty()) {
                String date = Helper.convertDate("d-M-yyyy hh:mm a", "yyyy-MM-dd h:mm a", expiryDate.getData());
                expiryDate.validateData(date);
            }
        }
    }

    private static class CadEtfAuditTrail extends PageObjectModel {
        @SkipAutoValidate
        @Data(alias = "cadetf-include")
        private AliasedString validate;
        @Data(alias = "cadetf-existingLimit")
        @FindBy(xpath = "//div[@class='audit-info']//td[.='CAD ETF']/../following-sibling::tr/td[.='Existing Limit:']/following-sibling::td")
        private WebComponent existingLimit;
        @Data(alias = "cadetf-newLimit")
        @FindBy(xpath = "//div[@class='audit-info']//td[.='CAD ETF']/../following-sibling::tr/td[.='New Limit:']/following-sibling::td")
        private WebComponent newLimit;
        @Data(alias = "cadetf-typeOfChange")
        @FindBy(xpath = "//div[@class='audit-info']//td[.='CAD ETF']/../following-sibling::tr/td[.='Type of Change:']/following-sibling::td")
        private WebComponent typeOfChange;
        @Data(alias = "cadetf-durationType")
        @FindBy(xpath = "//div[@class='audit-info']//td[.='CAD ETF']/../following-sibling::tr/td[.='Duration Type:']/following-sibling::td")
        private WebComponent durationType;
        @SkipAutoValidate
        @Data("${cadetf-expireDate} ${cadetf-expireHour}:${cadetf-expireMinute} ${cadetf-amOrPm}")
        @FindBy(xpath = "//div[@class='audit-info']//td[.='CAD ETF']/../following-sibling::tr/td[.=' Expiry Date:']/following-sibling::td")
        private WebComponent expiryDate;

        void validateInfo() {
            if (validate.getData().equals("true")) {
                validate();
            }
        }

        @Step("Validate Audit Trail for CAD ETF")
        private void validate() {
            autoValidatePage();
           if (expiryDate.getData() != null && !expiryDate.getData().isEmpty()) {
                String date = Helper.convertDate("d-M-yyyy hh:mm a", "yyyy-MM-dd h:mm a", expiryDate.getData());
                expiryDate.validateData(date);
            }
        }
    }

    private static class NextGenAuditTrail extends PageObjectModel {
        @SkipAutoValidate
        @Data(alias = "nextgen-include")
        private AliasedString validate;
        @Data(alias = "nextgen-externalAccountName")
        @FindAll({
                @FindBy(xpath = "//div[@class='audit-info']//td[.='Next Gen']/../following-sibling::tr/td[.='Client/Account Name:']/following-sibling::td"),
                @FindBy(xpath = "//div[@class='audit-info']//td[.='NexGen']/../following-sibling::tr/td[.='Client/Account Name:']/following-sibling::td") //US only Field
        })
        private WebComponent clientName;
        @Data(alias = "nextgen-existingLimit")
        @FindAll({
                @FindBy(xpath = "//div[@class='audit-info']//td[.='Next Gen']/../following-sibling::tr/td[.='Existing Limit:']/following-sibling::td"),
                @FindBy(xpath = "//div[@class='audit-info']//td[.='NexGen']/../following-sibling::tr/td[.='Existing Limit:']/following-sibling::td") //US only Field
        })
        private WebComponent existingLimit;
        @Data(alias = "nextgen-newLimit")
        @FindAll({
                @FindBy(xpath = "//div[@class='audit-info']//td[.='Next Gen']/../following-sibling::tr/td[.='New Limit:']/following-sibling::td"),
                @FindBy(xpath = "//div[@class='audit-info']//td[.='NexGen']/../following-sibling::tr/td[.='New Limit:']/following-sibling::td") //US only Field
        })
        private WebComponent newLimit;
        @Data(alias = "nextgen-accountTypeOfChange")
        @FindAll({
                @FindBy(xpath = "//div[@class='audit-info']//td[.='Next Gen']/../following-sibling::tr/td[.='Type of Change:']/following-sibling::td"),
                @FindBy(xpath = "//div[@class='audit-info']//td[.='NexGen']/../following-sibling::tr/td[.='Type of Change:']/following-sibling::td") //US only Field
        })
        private WebComponent typeOfChange;
        @Data(alias = "nextgen-durationType")
        @FindAll({
                @FindBy(xpath = "//div[@class='audit-info']//td[.='Next Gen']/../following-sibling::tr/td[.='Duration Type:']/following-sibling::td"),
                @FindBy(xpath = "//div[@class='audit-info']//td[.='NexGen']/../following-sibling::tr/td[.='Duration Type:']/following-sibling::td") //US only Field
        })
        private WebComponent durationType;
        @SkipAutoValidate
        @Data("${nextgen-expireDate} ${nextgen-expireHour}:${nextgen-expireMinute} ${nextgen-amOrPm}")
        @FindAll({
                @FindBy(xpath = "//div[@class='audit-info']//td[.='Next Gen']/../following-sibling::tr/td[.=' Expiry Date:']/following-sibling::td"),
                @FindBy(xpath = "//div[@class='audit-info']//td[.='NexGen']/../following-sibling::tr/td[.=' Expiry Date:']/following-sibling::td") //US only Field
        })
        private WebComponent expiryDate;

        void validateInfo() {
            if (validate.getData().equals("true")) {
                validate();
            }
        }

        @Step("Validate Audit Trail for Next Gen")
        private void validate() {
            autoValidatePage();
           if (expiryDate.getData() != null && !expiryDate.getData().isEmpty()) {
                String date = Helper.convertDate("d-M-yyyy hh:mm a", "yyyy-MM-dd h:mm a", expiryDate.getData());
                expiryDate.validateData(date);
            }
        }
    }

    @Step("Validate Audit Trail for New Entry" )
    public void validateNew() {
        validateNewInfo();
        openNew.click();
        validateAction(0);
        validateUser(0);
        validateAuditTrailCommon();
    }

    @Step("Validate Audit Trail for Approved Entry" )
    public void validateApproved() {
        validateApprovedInfo("Approved");
        openApproved.click();
        validateAction(1);
        validateUser(1);
        validateAuditTrailCommon();
    }

    @Step("Validate Audit Trail for Rejected Entry" )
    public void validateRejected() {
        validateApprovedInfo("Rejected");
        openRejected.click();
        validateAction(1);
        validateUser(1);
        validateAuditTrailCommon();
    }

    @Step("Validate Audit Trail for 'Change Complete' Entry" )
    public void validateChangeComplete() {
        validateChangeCompleteInfo();
        openChangeComplete.click();
        validateAction(2);
        validateUser(2);
        validateAuditTrailCommon();
    }

    @Step("Validate Audit Trail for Cancelled Entry" )
    public void validateCancelled() {
        validateCancelledInfo();
        openCancelled.click();
        validateAction(2);
        validateUser(2);
        validateAuditTrailCommon();
    }

    private void validateAuditTrailCommon() {
        if (fidessa != null) {
            fidessa.initPage(getContext());
            fidessa.validateInfo();
        }
        if (thor != null) {
            thor.initPage(getContext());
            thor.validateInfo();
        }
        if (titan != null) {
            titan.initPage(getContext());
            titan.validateInfo();
        }
        if (portware != null){
            portware.initPage(getContext());
            portware.validateInfo();
        }
        if (cadetf != null) {
            cadetf.initPage(getContext());
            cadetf.validateInfo();
        }
        if (nextgen != null) {
            nextgen.initPage(getContext());
            nextgen.validateInfo();
        }
        validateEffectiveDate();
        validateRequestorComments();
        validateApproverComments();
        validateImplementorComments();
    }

    @Step("Validate Audit Trail Action")
    private void validateAction(int index) {
        String expectedAction = action.getData().split(",")[index];
        action.validateData(expectedAction);

    }

    @Step("Validate Audit Trail User")
    private void validateUser(int index) {
        String expectedUser = user.getData().split(",")[index];
        user.validateData(expectedUser);
    }

    @Step("Validate Effective Date")
    private void validateEffectiveDate() {
        String date = Helper.convertDate("d-MM-yyyy", "yyyy-MM-dd", effectiveDate.getData());
        effectiveDate.validateData(date);
    }

    @Step("Validate Requestor Comments")
    private void validateRequestorComments() {
        requestorComments.validateData();
    }

    @Step("Validate Approver Comments")
    private void validateApproverComments() {
        approverComments.validateData();
    }

    @Step("Validate Implementor Comments")
    private void validateImplementorComments() {
        implementorComments.validateData();
    }

    @Step("Validate table entry with status New ")
    private void validateNewInfo() {
        newUsers.validateData();
        validateTime(newTime);
        newDate.validateData();
    }

    @Step("Validate table entry with status {0}")
    private void validateApprovedInfo(String action) {
        approvedUsers.validateData();
        validateTime(approvedTime);
        approvedDate.validateData();
    }

    @Step("Validate table entry with status Change Complete")
    private void validateChangeCompleteInfo() {
        changeCompleteUsers.validateData();
        validateTime(changeCompleteTime);
        changeCompleteDate.validateData();
    }

    @Step("Validate table entry with status Cancelled")
    private void validateCancelledInfo() {
        changeCompleteUsers.validateData();
        validateTime(changeCompleteTime);
        changeCompleteDate.validateData();
    }


    private void validateTime(PageComponent component) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("h:mm a");
        LocalTime actualTime = LocalTime.parse(component.getValue(), formatter);
        LocalTime expectedTime = LocalTime.parse(component.getData(), formatter);
        assertThat(actualTime).isBetween(expectedTime.minusMinutes(3),expectedTime.plusMinutes(3));
    }

}
