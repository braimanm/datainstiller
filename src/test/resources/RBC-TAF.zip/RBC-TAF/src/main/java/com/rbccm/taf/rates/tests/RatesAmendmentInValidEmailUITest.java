package com.rbccm.taf.rates.tests;

import com.rbccm.taf.rates.components.RatesDocumentEntry;
import com.rbccm.taf.rates.components.RatesDocumentProperty;
import com.rbccm.taf.rates.components.RatesTaskEntry;
import com.rbccm.taf.rates.domainobjects.RatesNoStepsDOM;
import com.rbccm.taf.rates.pageobjects.RatesActiFlowPOM;
import com.rbccm.taf.rates.pageobjects.RatesFileCabinetPOM;
import com.rbccm.taf.rates.pageobjects.RatesLoginPOM;
import com.rbccm.taf.ui.testng.TestNGBase;
import org.assertj.core.api.Assertions;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.Description;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

import java.io.IOException;

@Features("Fax error Basket Invalid Email Amendment watch flow")
@Stories("Amendment watch flow when old trade fax error basket and New trade inserted in ReviewI basket")
@Description("Trade1 inserted in ReviewI -->Forwarded to ReviewII-->Release Delay-->Fax Error Basket-->Trade2 inserted in ReviewI-->StatusCode verify in FileCabinet")
public class RatesAmendmentInValidEmailUITest extends TestNGBase {
    private String adviceId;

    @Parameters({"data-set1"})
    @Test
    public void tc001_01(@Optional("data/rates/TC001_Assign_Verify_the_Amendment_Watch_flow_ScenarioV/TC001_01.xml") String dataSet) throws IOException, InterruptedException {
        RatesNoStepsDOM rates = new RatesNoStepsDOM(dataSet);
        adviceId = rates.uploadGeneratedFeedFiles();

        RatesLoginPOM login = rates.getLoginPOM(getContext());
        login.login();

        RatesActiFlowPOM actiFlow = rates.getActiFlowPOM();

        actiFlow.selectBasket();

        RatesTaskEntry task = actiFlow.getTaskByAdviceId(adviceId);
        task.validateActions();
        task.doAction();
        actiFlow.validateTaskRemoval(adviceId);
        actiFlow.validateTaskMigration(adviceId);
    }

    @Parameters({"data-set2"})
    @Test (dependsOnMethods = "tc001_01")
    public void tc001_02(@Optional("data/rates/TC001_Assign_Verify_the_Amendment_Watch_flow_ScenarioV/TC001_02.xml") String dataSet) throws IOException, InterruptedException {
        RatesNoStepsDOM rates = new RatesNoStepsDOM(dataSet);

        RatesLoginPOM login = rates.getLoginPOM(getContext());
        login.login();

        RatesActiFlowPOM actiFlow = rates.getActiFlowPOM();

        actiFlow.selectBasket();

        RatesTaskEntry task = actiFlow.getTaskByAdviceId(adviceId);
        task.validateActions();
        task.doAction();
        actiFlow.validateTaskRemoval(adviceId);
        actiFlow.validateTaskMigration(adviceId);
    }

    @Parameters({"data-set3"})
    @Test(dependsOnMethods = "tc001_02")
    public void tc001_03(@Optional("data/rates/TC001_Assign_Verify_the_Amendment_Watch_flow_ScenarioV/TC001_03.xml") String dataSet) throws IOException, InterruptedException {
        RatesNoStepsDOM rates = new RatesNoStepsDOM(dataSet);

        RatesLoginPOM login = rates.getLoginPOM(getContext());
        login.login();

        RatesActiFlowPOM actiFlow = rates.getActiFlowPOM();

        actiFlow.selectBasket();

        RatesTaskEntry task = actiFlow.getTaskByAdviceId(adviceId);
        task.validateActions();
        task.doAction();
    }
    @Parameters({"data-set4"})
    @Test(dependsOnMethods = "tc001_03")
    public void tc001_04(@Optional("data/rates/TC001_Assign_Verify_the_Amendment_Watch_flow_ScenarioV/TC001_04.xml") String dataSet) throws IOException, InterruptedException {
        RatesNoStepsDOM rates = new RatesNoStepsDOM(dataSet);

        RatesLoginPOM login = rates.getLoginPOM(getContext());
        login.login();

        RatesActiFlowPOM actiFlow = rates.getActiFlowPOM();

        actiFlow.selectBasket();

        RatesTaskEntry task = actiFlow.getTaskByAdviceId(adviceId);
        task.validateActions();
        task.doAction();
        actiFlow.validateTaskRemoval(adviceId);
        actiFlow.validateTaskMigration(adviceId);
    }

    @Parameters({"data-set5"})
    @Test(dependsOnMethods = "tc001_04")
    public void tc001_05(@Optional("data/rates/TC001_Assign_Verify_the_Amendment_Watch_flow_ScenarioV/TC001_05.xml") String dataSet) throws IOException, InterruptedException {
        RatesNoStepsDOM rates = new RatesNoStepsDOM(dataSet);
        adviceId = rates.uploadGeneratedFeedFiles();
        RatesLoginPOM login = rates.getLoginPOM(getContext());
        login.login();

        RatesActiFlowPOM actiFlow = rates.getActiFlowPOM();

        actiFlow.selectBasket();

        RatesTaskEntry task = actiFlow.getTaskByAdviceId(adviceId);
        task.validateActions();
        RatesFileCabinetPOM fileCabinetPOM = actiFlow.getFileCabinetPOM();
        fileCabinetPOM.searchForDocument("Advice Id :" + adviceId);
        RatesDocumentEntry documentEntry = fileCabinetPOM.getDocument(1);
        Assertions.assertThat(documentEntry.getProperty(RatesDocumentProperty.StatusCode)).isEqualTo("AMENDED");
    }
}
