package com.rbccm.taf.commodities.pageobjects;

import com.rbccm.taf.commodities.components.CommoditiesCabinetSearchPannel;
import com.rbccm.taf.commodities.components.CommoditiesDocumentEntry;
import com.rbccm.taf.commodities.components.CommoditiesFileCabinetTable;
import com.rbccm.taf.ui.support.PageObjectModel;
import com.rbccm.taf.ui.utils.Helper;
import datainstiller.data.Data;
import org.openqa.selenium.support.FindBy;
import ui.auto.core.components.WebComponent;

public class CommoditiesFileCabinetPOM extends PageObjectModel {

    @FindBy(css = "#divVariableList")
    CommoditiesCabinetSearchPannel searchPannel;
    @Data(skip = true)
    @FindBy(css="[ng-click='search()']")
    public WebComponent cabinateSearchBtn;
    @Data(skip = true)
    @FindBy(css = "[ng-click='reset()']")
    public WebComponent cabinateResetBtn;
    @Data(skip = true)
    @FindBy(css = "#kendoFileGrid")
    public CommoditiesFileCabinetTable fileCabinetTable;


    public void searchForDocument(String search){
        cabinateResetBtn.click();
        searchPannel.setValue(search);
        cabinateSearchBtn.click();
        Helper.waitForXHR();
    }

    public CommoditiesDocumentEntry getDocument(int index) {
        return fileCabinetTable.getDocumentEntry(index);
    }

}

