package com.rbccm.taf.commodities.components;

import com.rbccm.taf.rates.components.RatesDocumentEntry;
import org.assertj.core.api.Assertions;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import ui.auto.core.pagecomponent.PageComponentNoDefaultAction;

import java.util.List;


public class CommoditiesFileCabinetTable extends PageComponentNoDefaultAction {

    @Override
    protected void init() {
    }

    public CommoditiesDocumentEntry getDocumentEntry (int index) {
        By by = By.cssSelector(".k-grid-content tr");
        List<WebElement> elements = getCoreElement().findElements(by);
        Assertions.assertThat(index).isLessThan(elements.size());
        return new CommoditiesDocumentEntry(elements.get(index));
    }

}
