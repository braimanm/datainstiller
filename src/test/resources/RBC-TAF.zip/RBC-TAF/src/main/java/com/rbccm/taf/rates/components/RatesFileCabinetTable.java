package com.rbccm.taf.rates.components;

import org.assertj.core.api.Assertions;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import ui.auto.core.pagecomponent.PageComponentNoDefaultAction;

import java.util.List;


public class RatesFileCabinetTable extends PageComponentNoDefaultAction {

    @Override
    protected void init() {
    }

    public RatesDocumentEntry getDocumentEntry (int index) {
        By by = By.cssSelector(".k-grid-content tr");
        List<WebElement> elements = getCoreElement().findElements(by);
        Assertions.assertThat(index).isLessThan(elements.size());
        return new RatesDocumentEntry(elements.get(index));
    }

}
