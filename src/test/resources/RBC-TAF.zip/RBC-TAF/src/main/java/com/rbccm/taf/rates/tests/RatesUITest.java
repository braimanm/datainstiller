package com.rbccm.taf.rates.tests;

import com.rbccm.taf.rates.components.RatesBasket;
import com.rbccm.taf.rates.components.RatesTaskEntry;
import com.rbccm.taf.rates.domainobjects.RatesDOM;
import com.rbccm.taf.rates.domainobjects.RatesStep;
import com.rbccm.taf.rates.pageobjects.RatesActiFlowPOM;
import com.rbccm.taf.ui.support.TestContext;
import com.rbccm.taf.ui.testng.TestNGBase;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import java.awt.*;
import java.io.IOException;


public class RatesUITest extends TestNGBase {

    @Parameters({"data-set"})
    @Test
    public void functionalSteps(@Optional("data/rates/TC007_Release_Delay_Verify_trade_moves_to_Fax_Error_when_sent_to_incorrect_CP_email.xml") String dataSet) throws IOException,InterruptedException{

        RatesDOM rates = new RatesDOM(dataSet);
        if (System.getenv().containsKey("APP_ENTITY") && System.getenv("APP_ENTITY").trim().toUpperCase().equals("LONDON")) {
            String curr = TestContext.getGlobalAliases().get("advice-id");
            TestContext.getGlobalAliases().put("advice-id",curr.replaceFirst("T","L"));
        }
        String adviceId = rates.uploadGeneratedFeedFiles();

        for (RatesStep step : rates.getfunctionalSteps()) {
            step.login(getContext());
            RatesActiFlowPOM actiFlow = step.getActiFlow(getContext());
            actiFlow.selectBasket();
            RatesTaskEntry task = actiFlow.getTaskByAdviceId(adviceId);
            task.validateActions();
            task.doAction();

            //There is a problem with specific case where source basket is Release Delay and destination basket is Fax Email Error
            //In this case we need to wait until task will propagate successfully to destination basket before we continue
            RatesBasket sourceBasket = actiFlow.getSourceBasket();
            RatesBasket destBasket = actiFlow.getDestinationBasket();
            if (destBasket != null && destBasket.equals(RatesBasket.FaxEmailError) && sourceBasket.equals(RatesBasket.ReleaseDelay)) {
                step.waitForTaskInBasket(adviceId, actiFlow.getDestinationBasket());
            }

            actiFlow.validateTaskMigration(adviceId);
        }
    }

}
