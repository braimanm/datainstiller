package com.rbccm.taf.commodities.tests.perf;

import com.rbccm.taf.commodities.api.CommoditiesTask;
import com.rbccm.taf.commodities.domainobjects.CommoditiesPerfDOM;
import com.rbccm.taf.rates.tests.perf.RatesStatistics;
import com.rbccm.taf.ui.support.TestContext;
import com.rbccm.taf.ui.testng.TestNGBase;
import org.assertj.core.api.SoftAssertions;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.Stories;
import ru.yandex.qatools.allure.model.SeverityLevel;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class CommoditiesStats extends TestNGBase {

    public static class RStat {
        public String key;
        public long count;
        public long val;
        public long min;
        public long max;
        public long sum;

        public long getAverage() {
            return sum / count;
        }

        @Override
        public String toString() {
            return key + " -> MIN: " + min + " MAX: " + max + " MEAN: " + getAverage() + " SUM: " + sum + " COUNT: " + count;
        }
    }

    private void setUsers(int num) {
        TestContext.getGlobalAliases().put("user1", "reviewer1-" + num);
        TestContext.getGlobalAliases().put("user2", "reviewer2-" + num);
        TestContext.getGlobalAliases().put("user3", "trader1-" + num);
    }

    private void calc(CommoditiesTask task, Map<String, RatesStatistics.RStat> stats , String key) {
        long actual = task.getExecTime();
        RatesStatistics.RStat stat = stats.get(key);
        if (stat == null) {
            stat = new RatesStatistics.RStat();
            stat.key = key;
            stat.val = actual;
            stat.count = 1;
            stat.max = actual;
            stat.min = actual;
            stat.sum = actual;
            stats.put(key, stat);
        } else {
            stat.count++;
            if (actual < stat.min) stat.min = actual;
            if (actual > stat.max) stat.max = actual;
            stat.sum += actual;
        }
    }


    @Parameters({"perf-data-set"})
    @Features("Performance Test")
    @Stories("Measure Load Time For Different 'Rates' Operations")
    @Severity(SeverityLevel.CRITICAL)
    @Test
    public void performanceTest(@Optional("data/commodities/perf/commodities_perf_qa3.xml") String dataSet) throws IOException, InterruptedException {

        Map<String, RatesStatistics.RStat> stats = new HashMap<>();

        for (int i=0; i<100; i++) {

            try {
                setUsers(12);
                SoftAssertions soft = new SoftAssertions();
                CommoditiesPerfDOM perf = new CommoditiesPerfDOM().fromResource(dataSet);
                CommoditiesTask task = perf.transferFeedFiles();
                calc(task, stats, "Test Case 1");
                task = perf.moveTaskFromReview1ToRevie2(task);
                calc(task, stats, "Test Case 2");
                task = perf.moveFromReview2ToTrader1(task);
                calc(task, stats, "Test Case 3");
                task = perf.moveFromTrader1ToReview2(task);
                calc(task, stats, "Test Case 4");
                task = perf.moveFromReview2ToReleaseDelay(task);
                calc(task, stats, "Test Case 5");
                task = perf.moveFromReleaseDelayToOutstandingConfirmation(task);
                calc(task, stats, "Test Case 6");
                String useEmail = System.getenv("USE_EMAIL");
                if (useEmail != null && useEmail.toLowerCase().trim().equals("true")) {
                    perf.getAndForwardEmail(task.getAdviceId());
                } else {
                    perf.getEmailAndCreateEML(task.getAdviceId());
                }
                task = perf.waitForTradeInReviewReturned(task.getAdviceId());
                task = perf.moveFromRviewReturnedToReview2Incoming(task);
                calc(task, stats, "Test Case 7");
                task = perf.moveOutTradeFromAllBaskets(task);
                calc(task, stats, "Test Case 8");
            } catch (Throwable e) {
                e.printStackTrace();
            }

            for (int c = 1; c < 9; c++) {
                System.out.println(stats.get("Test Case " + c));
            }
        }
    }


}
