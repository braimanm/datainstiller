package com.rbccm.taf.rlm.components;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import ui.auto.core.pagecomponent.PageComponentNoDefaultAction;

import java.util.List;

public class RLMTable extends PageComponentNoDefaultAction {

    @Override
    protected void init() {
    }

    private List<WebElement> getRows() {
        return coreElement.findElements(By.cssSelector("tr.parent"));
    }

    private WebElement findRowById(String id) {
        for (WebElement row : getRows()) {
           if (row.findElement(By.cssSelector(".req-id")).getText().contains(id)){
               return row;
            }
        }
        return null;
    }

    public void clickRequestId(String requestId) {
        WebElement row = findRowById(requestId);
        if (row == null) {
            throw new RuntimeException("Request with ID " + requestId + " was not found!");
        }
        row.findElement(By.cssSelector(".req-id")).click();
    }

    public void clickAuditTrail(String requestId) {
        WebElement row = findRowById(requestId);
        if (row == null) {
            throw new RuntimeException("Request with ID " + requestId + " was not found!");
        }
        row.findElement(By.cssSelector(".actions .fa-eye")).click();
    }

    public String getStatusByRequestId(String requestId) {
        WebElement row = findRowById(requestId);
        if (row == null) {
            throw new RuntimeException("Request with ID " + requestId + " was not found!");
        }
        return row.findElement(By.cssSelector(".label-status")).getText();
    }

    public int getNumberOfRows() {
        return getRows().size();
    }

}
