package com.rbccm.taf.commodities.api;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.jsoup.Connection;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@SuppressWarnings("unused")
@JsonIgnoreProperties(ignoreUnknown=true)
public class CommoditiesTask {
    private String taskId;
    private String taskName;
    private String alfrescoNodeRef;
    private String alfrescoId;
    private String adviceId;
    private String counterptyName;
    private String tradeId;
    private String instrumentRef;
    private String currency;
    private long execTime;
    private long expectedTime;

    public String getTaskId() {
        return taskId;
    }
    public String getTaskName() {
        return taskName;
    }
    public String getAlfrescoNodeRef() {
        return alfrescoNodeRef;
    }
    public String getAlfrescoId() {
        return alfrescoId;
    }
    public String getAdviceId() {
        return adviceId;
    }
    public String getCounterptyName() {
        return counterptyName;
    }
    public String getTradeId() {
        return tradeId;
    }
    public String getInstrumentRef() {
        return instrumentRef;
    }
    public String getCurrency() {
        return currency;
    }

    public List<CommoditiesTask> getEntities(CommoditiesSession session, String basketIds ) throws IOException {
        Connection con = session.getConnection("/app/tasks");
        con.maxBodySize(10000000);
        con.method(Connection.Method.POST);
        con.header("Content-Type", "application/json;charset=UTF-8");
        con.requestBody("{\"basketids\":[\"" + basketIds + "\"],\"siteids\":[]}");
        Connection.Response res = con.execute();
        if (res.body().isEmpty()) return new ArrayList<>();
        ObjectMapper mapper = new ObjectMapper();
        CommoditiesTask[] tasks = mapper.readValue(res.body(), CommoditiesTask[].class);
        return Arrays.asList(tasks);
    }

    public CommoditiesTask waitForTask (CommoditiesSession session, String basketId, String adviceId) throws IOException, InterruptedException {
        return waitForTask(session, basketId, adviceId, null);
    }

    public CommoditiesTask waitForTask (CommoditiesSession session, String basketId, String adviceId, String status) throws IOException, InterruptedException {
        long time_out = System.currentTimeMillis() + 180000;
        do {
            List<CommoditiesTask> taskList = getEntities(session, basketId);
            if (!taskList.isEmpty()) {
                for (CommoditiesTask task : taskList) {
                    if (task.getAdviceId() != null && task.getAdviceId().equals(adviceId)) {
                        if (status == null) {
                            return task;
                        } else if (task.getTaskName().equals(status)) {
                                return task;
                        }
                    }
                }
            }
            Thread.sleep(100);
        } while (System.currentTimeMillis() < time_out);
        return null;
    }

    public int completeTaskAction (CommoditiesSession session, String taskId, String actionOrUser, boolean isAction) throws IOException {
        Connection con = session.getConnection("/api/action/completetask/"+ taskId);
        con.method(Connection.Method.PUT);
        con.header("Content-Type", "application/json;charset=UTF-8");
        if (isAction) {
            con.requestBody("{\"action\":[\"" + actionOrUser + "\"]}");
        } else {
            con.requestBody("{\"userName\":[\"" + actionOrUser + "\"]}");
        }
        Connection.Response res = con.execute();
        return res.statusCode();
    }

    public void setExecTime(long execTime) {
        this.execTime = execTime;
    }

    public long getExecTime() {
        return execTime;
    }

    public void setExpectedTime(long expectedTime) {
        this.expectedTime = expectedTime;
    }

    public long getExpectedTime() {
        return expectedTime;
    }

    @Override
    public String toString() {
        return "AdviceId: " + adviceId + " | Task: " + taskName + " | Counterparty: " + counterptyName;
    }
}
