package com.rbccm.taf.rlm.pageobjects;

import com.rbccm.taf.ui.support.PageObjectModel;
import com.rbccm.taf.ui.support.TestContext;
import com.rbccm.taf.ui.utils.Helper;
import datainstiller.data.Data;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import ru.yandex.qatools.allure.annotations.Step;
import ui.auto.core.components.WebComponent;

import java.util.concurrent.TimeUnit;

@SuppressWarnings("unused")
public class RLMMainPOM extends PageObjectModel {
    @Data(skip = true)
    @FindBy(xpath = "//a[.='DASHBOARD']")
    private WebComponent dashboardTab;
    @Data(skip = true)
    @FindBy(xpath = "//a[.='REQUEST FORM']")
    private WebComponent requestFormTab;
    @Data(skip = true)
    @FindBy(xpath = "//button[.='CREATE REQUEST']")
    private WebComponent createRequestButton;
    @Data(skip = true)
    @FindBy(css = "a#title-tab1")
    private WebComponent generalInfoTab;
    @Data(skip = true)
    @FindBy(css = "checkbox-widget>label[for=fidessa]")
    private WebComponent fidessa;
    @Data(skip = true)
    @FindBy(xpath = "//h3[starts-with(.,'Loading Request Form')]")
    private WebComponent loadingRequestFormMsg;
    @Data(skip = true)
    @FindBy(css = "td.req-id")
    private WebComponent requestId;

    void validateRequestSubmition(String message) {
        ExpectedCondition<WebElement> cond1 = ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class, 'toast-message') and contains(.,'Request is being processed')]"));
        ExpectedCondition<WebElement> cond2 = ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class, 'toast-message') and contains(.,'" + message + "')]"));
        Helper.getWebDriiverWait().pollingEvery(10, TimeUnit.MILLISECONDS).until(cond1);
        Helper.getWebDriiverWait().pollingEvery(10, TimeUnit.MILLISECONDS).until(cond2);
    }


    @Step("Navigate to Request Form")
    public void navigateToRequestForm() {
        requestFormTab.click();
        createRequestButton.click();
        waitForUrl("/request-form?createDraft=true");
        Helper.waitForXHR();
        String reqId = requestId.getText();
        TestContext.getGlobalAliases().put("request-id", reqId);
    }

    @Step("Navigate to Dashboard")
    public void navigateToDashboard() {
        dashboardTab.click();
        waitForUrl("/rlm-dashboard");
        Helper.waitForXHR();
    }


}
