package com.rbccm.taf.rates.tests;
import com.rbccm.taf.rates.components.RatesTaskEntry;
import com.rbccm.taf.rates.components.RatesTaskProperty;
import com.rbccm.taf.rates.domainobjects.RatesNoStepsDOM;
import com.rbccm.taf.rates.domainobjects.RatesStep;
import com.rbccm.taf.rates.pageobjects.RatesActiFlowPOM;
import com.rbccm.taf.rates.pageobjects.RatesLoginPOM;
import com.rbccm.taf.ui.testng.TestNGBase;
import org.assertj.core.api.Assertions;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.Description;
import ru.yandex.qatools.allure.annotations.Features;
import java.io.IOException;

@Features("Verify required approvals from multiple reviewers (trader and SPBS)")
@Description("Vanilla Review 1 --> 2nd Review Vanilla --> Trader and SPBS Reviews --> Trader Approve Without Comment --> Wait For Review --> SPBS Approve Without Comment --> Received")
public class RatesMultipleReviewersUITest extends TestNGBase {
    private String adviceId;


    @Parameters({"data-set1"})
    @Test
    public void tc007_01(@Optional("data/rates/TC007_Vanilla_Review_II_Verify_trade_approval_with_multiple_reviewers/TC007_01.xml") String dataSet) throws IOException, InterruptedException {

        RatesNoStepsDOM rates = new RatesNoStepsDOM(dataSet);
        adviceId = rates.uploadGeneratedFeedFiles();

        RatesLoginPOM login = rates.getLoginPOM(getContext());
        login.login();

        RatesActiFlowPOM actiFlow = rates.getActiFlowPOM();
        actiFlow.selectBasket();

        RatesTaskEntry task = actiFlow.getTaskByAdviceId(adviceId);
        task.validateActions();
        task.doAction();

        new RatesStep().waitForTaskInBasket(adviceId, actiFlow.getDestinationBasket());

        actiFlow.validateTaskMigration(adviceId);

    }

    @Parameters({"data-set2"})
    @Test(dependsOnMethods = "tc007_01")
    public void tc007_02(@Optional("data/rates/TC007_Vanilla_Review_II_Verify_trade_approval_with_multiple_reviewers/TC007_02.xml") String dataSet) throws IOException, InterruptedException {
        RatesNoStepsDOM rates = new RatesNoStepsDOM(dataSet);

        RatesLoginPOM login = rates.getLoginPOM(getContext());
        login.login();

        RatesActiFlowPOM actiFlow = rates.getActiFlowPOM();
        actiFlow.selectBasket();


        RatesTaskEntry task = actiFlow.getTaskByAdviceId(adviceId);
        task.validateActions();
        task.doAction();

        task = actiFlow.getTaskByAdviceId(adviceId);
        Assertions.assertThat(task.getProperty(RatesTaskProperty.Task)).isEqualTo("Wait For Review");
    }

    @Parameters({"data-set3"})
    @Test(dependsOnMethods = "tc007_02")
    public void tc007_03(@Optional("data/rates/TC007_Vanilla_Review_II_Verify_trade_approval_with_multiple_reviewers/TC007_03.xml") String dataSet) throws IOException, InterruptedException{
        RatesNoStepsDOM rates = new RatesNoStepsDOM(dataSet);

        RatesLoginPOM login = rates.getLoginPOM(getContext());
        login.login();

        RatesActiFlowPOM actiFlow = rates.getActiFlowPOM();
        actiFlow.selectBasket();

        RatesTaskEntry task = actiFlow.getTaskByAdviceId(adviceId);
        task.validateActions();
        task.doAction();

        actiFlow.validateTaskRemoval(adviceId);
    }

    @Parameters({"data-set4"})
    @Test(dependsOnMethods = "tc007_03")
    public void tc007_04(@Optional("data/rates/TC007_Vanilla_Review_II_Verify_trade_approval_with_multiple_reviewers/TC007_04.xml") String dataSet) throws IOException, InterruptedException{
        RatesNoStepsDOM rates = new RatesNoStepsDOM(dataSet);

        RatesLoginPOM login = rates.getLoginPOM(getContext());
        login.login();

        RatesActiFlowPOM actiFlow = rates.getActiFlowPOM();
        actiFlow.selectBasket();

        RatesTaskEntry task = actiFlow.getTaskByAdviceId(adviceId);
        task.validateActions();
        task.doAction();

        actiFlow.validateTaskRemoval(adviceId);
    }

    @Parameters({"data-set5"})
    @Test(dependsOnMethods = "tc007_04")
    public void tc007_05(@Optional("data/rates/TC007_Vanilla_Review_II_Verify_trade_approval_with_multiple_reviewers/TC007_05.xml") String dataSet) throws IOException, InterruptedException{
        RatesNoStepsDOM rates = new RatesNoStepsDOM(dataSet);

        RatesLoginPOM login = rates.getLoginPOM(getContext());
        login.login();

        RatesActiFlowPOM actiFlow = rates.getActiFlowPOM();
        actiFlow.selectBasket();

        RatesTaskEntry task = actiFlow.getTaskByAdviceId(adviceId);

        Assertions.assertThat(task.getProperty(RatesTaskProperty.Task)).isEqualTo("Review approved");
    }



}
