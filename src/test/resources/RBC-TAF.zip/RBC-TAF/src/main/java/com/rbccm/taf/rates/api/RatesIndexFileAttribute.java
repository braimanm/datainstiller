package com.rbccm.taf.rates.api;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamConverter;
import com.thoughtworks.xstream.converters.Converter;
import com.thoughtworks.xstream.converters.MarshallingContext;
import com.thoughtworks.xstream.converters.UnmarshallingContext;
import com.thoughtworks.xstream.io.HierarchicalStreamReader;
import com.thoughtworks.xstream.io.HierarchicalStreamWriter;

@XStreamConverter(RatesIndexFileAttribute.class)
@XStreamAlias("attribute")
public class RatesIndexFileAttribute implements Converter{
    private String name;
    private String value;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    @Override
    public boolean canConvert(Class type) {
        return type.equals(RatesIndexFileAttribute.class);
    }

    @Override
    public void marshal(Object source, HierarchicalStreamWriter writer, MarshallingContext context) {
        RatesIndexFileAttribute attr = (RatesIndexFileAttribute) source;
        writer.addAttribute("name", attr.name);
        writer.setValue(attr.value);
    }

    @Override
    public Object unmarshal(HierarchicalStreamReader reader, UnmarshallingContext context) {
        RatesIndexFileAttribute attr = new RatesIndexFileAttribute();
        attr.setName(reader.getAttribute("name"));
        attr.setValue(reader.getValue());
        return attr;
    }

}
