package com.rbccm.taf.rates.components;

public enum RatesDocumentAction {
    Open("Open"),
    ShowAnnotation("Show Annotations"),
    AddDocuments("Add Documents"),
    Download("Download"),
    Compare("Compare");
    String action;

    RatesDocumentAction(String action) {
        this.action = action;
    }

    public String getAction() {
        return action;
    }
}
