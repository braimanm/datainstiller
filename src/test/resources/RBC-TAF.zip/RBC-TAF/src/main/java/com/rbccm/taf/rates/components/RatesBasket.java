package com.rbccm.taf.rates.components;


public enum RatesBasket {
    VanillaReview1("Vanilla Review 1", "1"),
    SecondReviewVanila("2nd Review Vanilla", "2"),
    SpecialFeatureRepair("Special Feature Repair", "3"),
    SecondReviewSpecialFeature("2nd Review Special Feature", "4"),
    StructuredRepair("Structured Repair", "5"),
    SecondReviewStructured("2nd Review Structured", "6"),
    AssignRepair("Assign Repair", "7"),
    SecondReviewAssigned("2nd Review Assigned", "8"),
    CustomConfReview1("Custom Conf. Review 1", "9"),
    SecondReviewCustom("2nd Review Custom", "10"),
    ReleaseDelay("Release Delay", "13"),
    OtstandingConfirmations("Outstanding Confirmation", "14"),
    FaxEmailError("Fax/Email Error", "15"),
    ManualIndex("Manual Index", "16"),
    Investigations("Investigations", "17"),
    ReviewReturnedConfirmation("Review Returned Confirmation", "18"),
    SecondReviewIncoming("2nd Review Incoming", "19"),
    Remove("Remove", "20"),
    DeleteIncomingEmailOrFax("Delete Incoming Email/Fax", "21"),
    RateResetRepair("Rate Reset Repair", "22"),
    SupervisorRateResetReview("Supervisor Rate Reset Review", "23"),
    ErrorRetry("Error Retry", "24");


    String basketName;
    String basketId;

    RatesBasket(String name, String id) {
        basketName = name;
        basketId = id;
    }

    public String getBasketName() {
        return basketName;
    }

    public String getBasketId() {
        return basketId;
    }

    public static RatesBasket getBasketForName(String basketName) {
        for (RatesBasket basket : RatesBasket.values()) {
            if (basket.getBasketName().equals(basketName)) return basket;
        }
        return null;
    }

}
