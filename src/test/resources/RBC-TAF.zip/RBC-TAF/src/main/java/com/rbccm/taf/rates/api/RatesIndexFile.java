package com.rbccm.taf.rates.api;

import java.io.IOException;
import java.util.Map;

public class RatesIndexFile {
    private String adviceId;
    private OrderedProperties props;

    public RatesIndexFile(String adviceId) {
        this.adviceId = adviceId;
        props = new OrderedProperties();
        try {
            props.load(this.getClass().getResourceAsStream("/data/rates/feed/ADVICE.index"));
        } catch (IOException e) {
            throw new RuntimeException("Can't read the ADVICE.index file!");
        }
        String tradeId = adviceId.replace("T","");
        props.setProperty("DOCUMENT_ID" , adviceId);
        props.setProperty("ADVICE_ID" , adviceId);
        props.setProperty("TRADE_ID" , tradeId);
        props.setProperty("TRANS_ID" , tradeId);
    }

    public OrderedProperties getProps() {
        return props;
    }

    public RatesIndexFile setFlag(RatesIndexFileFlag flag, boolean value) {
        props.setProperty(flag.getName() , (value) ? "1" : "0");
        return this;
    }

    public RatesIndexFile setAttribute(RatesIndexFileAttribute field) {
        if (props.containsProperty(field.getName())) {
            props.setProperty(field.getName(), field.getValue());
        } else {
            throw new RuntimeException("The attribute " + field.getName() + " is not exists in the index file");
        }
        return this;
    }

    public byte[] getPropsAsBytes() throws IOException {
        StringBuilder out = new StringBuilder();
        for (Map.Entry<String, String> entry : props.entrySet()) {
            out.append(entry.getKey()).append(":     ").append(entry.getValue()).append("\n");
        }
        return out.toString().getBytes();
    }

    public String getProperty(String propertyName) {
        return props.getProperty(propertyName);
    }



}
