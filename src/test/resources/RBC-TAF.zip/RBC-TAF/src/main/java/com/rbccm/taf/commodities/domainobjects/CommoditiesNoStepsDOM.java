package com.rbccm.taf.commodities.domainobjects;

import com.rbccm.taf.commodities.api.CommoditiesIndexFile;
import com.rbccm.taf.commodities.api.CommoditiesIndexFileAttribute;
import com.rbccm.taf.commodities.api.CommoditiesIndexFileFlag;
import com.rbccm.taf.commodities.api.CommoditiesSCP;
import com.rbccm.taf.commodities.pageobjects.CommoditiesActiFlowPOM;
import com.rbccm.taf.commodities.pageobjects.CommoditiesLoginPOM;
import com.rbccm.taf.mail.EWSMail;
import com.rbccm.taf.ui.support.AliasedString;
import com.rbccm.taf.ui.support.DomainObjectModel;
import com.rbccm.taf.ui.support.EnvironmentsSetup;
import com.rbccm.taf.ui.support.TestContext;
import com.thoughtworks.xstream.annotations.XStreamAlias;
import microsoft.exchange.webservices.data.core.service.item.Item;
import microsoft.exchange.webservices.data.search.FindItemsResults;
import org.apache.commons.io.IOUtils;
import org.assertj.core.api.Assertions;
import ru.yandex.qatools.allure.annotations.Step;

import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Set;

@XStreamAlias("commodities-no-steps-domain-object")
public class CommoditiesNoStepsDOM extends DomainObjectModel {
    private AliasedString envUrl;
    private AliasedString feedDestinationFolder;
    private AliasedString adviceId;
    private AliasedString mailUserName;
    private AliasedString mailPassWord;
    private AliasedString forwardEmailID;
    private AliasedString emailPrefixBody;
    private Set<CommoditiesIndexFileFlag> indexFlags;
    private Set<CommoditiesIndexFileAttribute> indexAttributes;
    private CommoditiesLoginPOM login;
    private CommoditiesActiFlowPOM actiFlow;

    public CommoditiesNoStepsDOM(){}
    public CommoditiesNoStepsDOM(String dataSet) {
        initData(fromResource(dataSet));
    }

    @Step("Upload feed files")
    public String uploadGeneratedFeedFiles() throws IOException, InterruptedException {

        CommoditiesIndexFile indexFile = new CommoditiesIndexFile(adviceId.getData());
        if (indexFlags != null) {
            for (CommoditiesIndexFileFlag flag : indexFlags) {
                indexFile.setFlag(flag, true);
            }
        }
        if (indexAttributes != null) {
            for (CommoditiesIndexFileAttribute attribute : indexAttributes) {
                indexFile.setAttribute(attribute);
            }
        }

        String doc = "data/commodities/feed/ADVICE.html";
        InputStream isDoc = getClass().getClassLoader().getResourceAsStream(doc);
        byte[] document = IOUtils.toByteArray(isDoc);
        IOUtils.closeQuietly(isDoc);
        String timestamp = DateTimeFormatter.ofPattern("yyMMddkkmmss").format(LocalDateTime.now()) + Thread.currentThread().getId();
        String strAdviceID = "E" + timestamp;
        byte[] index = indexFile.getPropsAsBytes();
        EnvironmentsSetup.User usr = TestContext.getTestProperties().getTestEnvironment().getUser("ssh");
        String sshServer = envUrl.getData();
        sshServer = sshServer.substring(sshServer.indexOf(":") + 3, sshServer.lastIndexOf(":"));
        CommoditiesSCP scp = new CommoditiesSCP(sshServer, usr.getUserName(), usr.getPassword());
        scp.transferFile(document, strAdviceID + ".html", feedDestinationFolder.getData());
        scp.transferFile(index, strAdviceID + ".INDEX", feedDestinationFolder.getData());
        System.out.println("Task with advice id " + strAdviceID + " was created and moved to server");
        CommoditiesStep step = new CommoditiesStep();
        step.waitForTaskInBasket(adviceId.getData(), actiFlow.getSourceBasket());
        return adviceId.getData();
    }

    @Step("Verify that Email is triggered for the trade in counterParty's mailbox and Sending it back to ActiFlow")

    public String verifyAndForwardMail(){
        EWSMail mail = new EWSMail();
        mail.setCredentials(mailUserName.getData(),mailPassWord.getData());
        FindItemsResults<Item> items = mail.waitForEmailWithSubject(adviceId.getData());
        Assertions.assertThat(items.getTotalCount()).isGreaterThan(0);
        mail.forwardEmail(items.getItems().get(0), forwardEmailID.getData(), emailPrefixBody.getData());
        CommoditiesStep step = new CommoditiesStep();
        step.waitForTaskInBasket(adviceId.getData(), actiFlow.getSourceBasket());
        return adviceId.getData();
    }


    public CommoditiesLoginPOM getLoginPOM(TestContext context) {
        this.context = context;
        login.initPage(context);
        return login;
    }

    public CommoditiesActiFlowPOM getActiFlowPOM () {
        actiFlow.initPage(getContext());
        return actiFlow;
    }

}
