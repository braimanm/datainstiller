package com.rbccm.taf.sds.domainobjects;


import com.rbccm.taf.sds.pageobjects.SDSCreateNewRequestPOM;
import com.rbccm.taf.sds.pageobjects.SDSLoginPOM;
import com.rbccm.taf.sds.pageobjects.SDSMainPO;
import com.rbccm.taf.ui.support.DomainObjectModel;
import com.rbccm.taf.ui.support.TestContext;
import com.rbccm.taf.ui.utils.Helper;

public class SDSCreateNewRequestDOM extends DomainObjectModel {
    SDSLoginPOM loginPOM;
    SDSCreateNewRequestPOM createNewRequestPOM;

    public SDSCreateNewRequestDOM() {
    }

    public SDSCreateNewRequestDOM(TestContext context) {
        this.context = context;
    }

    public void createRequest() {
        loginPOM.initPage(context);
        loginPOM.navigate();
        loginPOM.login();
        Helper.waitForXHR();
        createNewRequestPOM.initPage(context);
        createNewRequestPOM.fillTemplateAndValidate();
    }

    public SDSLoginPOM getLoginPOM() {
        loginPOM.initPage(context);
        return loginPOM;
    }

    public SDSCreateNewRequestPOM getRequestPOM() {
        createNewRequestPOM.initPage(context);
        return createNewRequestPOM;
    }

    public void signOut() {
        SDSMainPO mainPO = new SDSMainPO();
        mainPO.initPage(context);
        mainPO.logOut();
    }

}
