package com.rbccm.taf.rates.tests.perf;

import com.rbccm.taf.rates.api.RatesTask;
import com.rbccm.taf.rates.domainobjects.RatesPerfDOM;
import com.rbccm.taf.ui.support.TestContext;
import com.rbccm.taf.ui.testng.TestNGBase;
import org.apache.commons.io.FileUtils;
import org.influxdb.InfluxDB;
import org.influxdb.InfluxDBFactory;
import org.influxdb.dto.BatchPoints;
import org.influxdb.dto.Point;
import org.influxdb.dto.Query;
import org.influxdb.dto.QueryResult;
import org.testng.annotations.*;

import java.io.*;
import java.nio.charset.Charset;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;


public class RatesStatistics2 extends TestNGBase {
    private static final int numberOfSteps = 8;
    private static final String influxDBUrl ="http://10.95.151.40:8086";
    private static final String resFile = "RatesValues.txt";
    private int num;

    public RatesStatistics2(){}
    public RatesStatistics2(int i) {
        num = i;
    }


    private void setUsers(int num) {
        TestContext.getGlobalAliases().put("user1", "reviewer1-" + num);
        TestContext.getGlobalAliases().put("user2", "reviewer2-" + num);
        TestContext.getGlobalAliases().put("user3", "trader1-" + num);
    }


    private void cleanStats(Map<Integer, Long> stats, long cleanValue) {
        for (int i = 0; i < numberOfSteps; i++) {
            stats.put(i, cleanValue);
        }
    }

    private void writeValue(InfluxDB influxDB, String dbName, String retentionPolicyName, String line) {
        List<String> values = Arrays.asList(line.split("\t"));
        BatchPoints batchPoints = BatchPoints.database(dbName)
                .retentionPolicy(retentionPolicyName)
                .consistency(InfluxDB.ConsistencyLevel.ALL)
                .build();

        String threadNum = values.get(0).trim();
        boolean thread = true;
        for (int i = 1 ; i < values.size(); i++) {
           long val = Long.parseLong(values.get(i).trim());
           Point point = Point.measurement("rate")
                   .tag("thread_num", threadNum)
                   .tag("test_case", i + "")
                   .addField("value", val)
                   .build();
            batchPoints.point(point);
        }

        influxDB.write(batchPoints);
    }

    private void generate(Map<Integer, Long> stats) {
        for (int key : stats.keySet()) {
            Long rand = ThreadLocalRandom.current().nextLong(0, 40) * 1000;
            if (rand == 0) break;
            stats.put(key, rand);
        }
        try {
            Long rand = ThreadLocalRandom.current().nextLong(1, 7) * 10000;
            Thread.sleep(rand);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @BeforeTest
    public void setup() throws IOException {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss");
        String timeStamp = dtf.format(LocalDateTime.now());
        String dbName = "rates_perf_test";
        String retentionPolicyName = timeStamp;
        InfluxDB influxDB = InfluxDBFactory.connect(influxDBUrl);
        influxDB.createRetentionPolicy(retentionPolicyName, dbName, "0s", 1, false);
        Query query = new Query("show retention policies", dbName);
        QueryResult res;
        long time_out = System.currentTimeMillis() + 3000;
        do {
            res = influxDB.query(query);
        } while (System.currentTimeMillis() < time_out || !res.toString().contains(timeStamp));

        FileUtils.write(new File(resFile), "", Charset.defaultCharset());
        Thread fileWatchDog = new Thread(() -> {
            FileReader fr;
            try {
                fr = new FileReader(resFile);
                BufferedReader br = new BufferedReader(fr);
                while (true) {
                    String line = br.readLine();
                    if (line != null) {
                        writeValue(influxDB, dbName, retentionPolicyName, line);
                    }
                    Thread.sleep(1000);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

        });
        fileWatchDog.start();

    }

    @Parameters({"perf-data-set"})
    @Test
    public void performanceTest(@Optional("data/rates/perf/rates_perf_qa3.xml") String dataSet) throws IOException {
        int testDurationInMinutes = 20;
        String title = "Thread\tTest1\tTest2\tTest3\tTest4\tTest5\tTest6\tTest7\tTest8";
        Map<Integer, Long> stats = new HashMap<>();

        BufferedWriter writer = new BufferedWriter(new FileWriter(resFile, true));
        long testEnd = System.currentTimeMillis() + (testDurationInMinutes * 60000);
        boolean firstSample = true;
        boolean generate = false;
        do {
            cleanStats(stats, -9999L);
            if (generate) {
                generate(stats);
            } else {
                try {
                    setUsers(num);
                    RatesPerfDOM perf = new RatesPerfDOM().fromResource(dataSet);
                    RatesTask task = perf.transferFeedFiles();
                    stats.put(0, task.getExecTime());
                    task = perf.moveTaskFromReview1ToRevie2(task);
                    stats.put(1, task.getExecTime());
                    task = perf.moveFromReview2ToTrader1(task);
                    stats.put(2, task.getExecTime());
                    task = perf.moveFromTrader1ToReview2(task);
                    stats.put(3, task.getExecTime());
                    task = perf.moveFromReview2ToReleaseDelay(task);
                    stats.put(4, task.getExecTime());
                    task = perf.moveFromReleaseDelayToOutstandingConfirmation(task);
                    stats.put(5, task.getExecTime());
                    String useEmail = System.getenv("USE_EMAIL");
                    if (useEmail != null && useEmail.toLowerCase().trim().equals("true")) {
                        perf.getAndForwardEmail(task.getAdviceId());
                    } else {
                        perf.getEmailAndCreateEML(task.getAdviceId());
                    }
                    task = perf.waitForTradeInReviewReturned(task.getAdviceId());
                    task = perf.moveFromRviewReturnedToReview2Incoming(task);
                    stats.put(6, task.getExecTime());
                    task = perf.moveOutTradeFromAllBaskets(task);
                    stats.put(7, task.getExecTime());
                } catch (Throwable e) {
                    e.printStackTrace();
                }
            }

            if (firstSample) {
                firstSample = false;
                testEnd = System.currentTimeMillis() + (testDurationInMinutes * 60000);
            }

            StringBuilder results = new StringBuilder("    " + Thread.currentThread().getId() + "\t");
            for (int key : stats.keySet()) {
                Long result = stats.get(key);
                results.append(result + "\t");
            }

            System.out.println(title + "\n" + results.toString());
            synchronized (this) {
                writer.write(results.toString() + "\n");
                writer.flush();
            }

        } while (System.currentTimeMillis() < testEnd);

        writer.close();
    }

    @AfterTest
    public void clean() throws InterruptedException {
        Thread.sleep(10000);
    }

}
