package com.rbccm.taf.sit.components;

import com.rbccm.taf.ui.testng.TestNGBase;
import com.rbccm.taf.ui.utils.Helper;
import org.assertj.core.api.Assertions;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import ru.yandex.qatools.allure.Allure;
import ru.yandex.qatools.allure.annotations.Step;
import ru.yandex.qatools.allure.events.MakeAttachmentEvent;
import ru.yandex.qatools.ashot.AShot;
import ru.yandex.qatools.ashot.Screenshot;
import ru.yandex.qatools.ashot.comparison.ImageDiff;
import ru.yandex.qatools.ashot.comparison.ImageDiffer;
import ru.yandex.qatools.ashot.coordinates.Coords;
import ru.yandex.qatools.ashot.cropper.DefaultCropper;
import ru.yandex.qatools.ashot.util.ImageTool;
import ui.auto.core.pagecomponent.PageComponentNoDefaultAction;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashSet;
import java.util.Set;

public class SITDocumentViewer extends PageComponentNoDefaultAction {
    private WebDriver driver;

    @Override
    protected void init() {
        driver = TestNGBase.CONTEXT().getDriver();
    }


    @Step("Validate Document Image")
    public void validateDocument(String documentPath, String documentName, String folderName) throws IOException {
        driver.switchTo().frame(getCoreElement());
        driver.switchTo().defaultContent();

        Screenshot source = cropImage(new AShot().takeScreenshot(driver, getCoreElement()).getImage());

//        String debugPath = "src/main/resources/data/sit/documents/images/debug/";
//        File outfile = new File( debugPath + documentName + ".png");
//        ImageIO.write(source.getImage(), "png", outfile);

        String imgPath = "images/";
        if (driver.getClass().equals(RemoteWebDriver.class)) {
            imgPath += "remote/";
        }
        InputStream stream = getClass().getClassLoader().getResourceAsStream(documentPath + imgPath + documentName + ".png");
        Screenshot target = new Screenshot(ImageIO.read(stream));
        stream.close();

        ImageDiff screenDiff = new ImageDiffer().makeDiff(source, target);

        System.out.println(documentName + " DIFF SIZE " + screenDiff.getDiffSize());
        if (screenDiff.getDiffSize() != 0) {
            byte[] attachment = ImageTool.toByteArray(screenDiff.getMarkedImage());
            MakeAttachmentEvent ev = new MakeAttachmentEvent(attachment, "Image Diff", "image/png");
            Allure.LIFECYCLE.fire(ev);
            Assertions.assertThat(screenDiff.getDiffSize()).isEqualTo(0);
        }
        WebElement folder = driver.findElement(By.xpath("//a[.='" + folderName + "']"));
        folder.click();
        Helper.waitForXHR();
    }

    private Screenshot cropImage(BufferedImage image) {
        Set<Coords> coords = new HashSet<>();
        coords.add(new Coords(50, 100, 500, 155));
        DefaultCropper cropper = new DefaultCropper();
        return cropper.crop(image, coords);
    }

}
