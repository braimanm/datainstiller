package com.rbccm.taf.sit.tests;

import com.rbccm.taf.sit.domainobjects.SITGeneralFlowDOM;
import com.rbccm.taf.sit.pageobjects.SITDocumentLibraryPOM;
import com.rbccm.taf.sit.pageobjects.SITNavigation;
import com.rbccm.taf.ui.testng.TestNGBase;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.Description;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.Stories;
import ru.yandex.qatools.allure.model.SeverityLevel;

import java.io.IOException;

public class SITGeneralTest extends TestNGBase {

    @Parameters("sit-data-set")
    @Description("Test for validating general application behaviour")
    @Features("SIT Test")
    @Stories("Validate Multiple Applications On The Same Alfresco Instance")
    @Severity(SeverityLevel.CRITICAL)
    @Test
    public void testSIT(@Optional("data/sit/sit-project-clients-data.xml") String dataSet) throws IOException {
        SITGeneralFlowDOM flowDOM = new SITGeneralFlowDOM(getContext()).fromResource(dataSet);
        SITNavigation navigation = flowDOM.getNavigation();
        SITDocumentLibraryPOM documentLibrary = flowDOM.getDocumentLibrary();
        flowDOM.login();
        navigation.goToDocumentLibrary();
        documentLibrary.createNewFolder("-move");
        documentLibrary.createNewFolder();
        documentLibrary.openFolder();
        documentLibrary.uploadDocuments();
        documentLibrary.validateDocuments();
        documentLibrary.moveDocument("-move");
        navigation.goToDocumentLibrary();
        documentLibrary.searchForFolder("-move");
        documentLibrary.validateMovedDocument("-move");
    }
}
