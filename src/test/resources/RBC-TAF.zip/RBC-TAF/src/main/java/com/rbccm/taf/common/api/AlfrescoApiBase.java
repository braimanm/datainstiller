package com.rbccm.taf.common.api;

import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

import java.io.IOException;

public class AlfrescoApiBase {
    private String baseUrl;

    public AlfrescoApiBase(String baseURL) {
        this.baseUrl = baseURL;
    }

    public Connection getConnection(String url) {
        Connection con = Jsoup.connect(baseUrl + url);
        con.timeout(180000);
        con.validateTLSCertificates(false);
        con.ignoreContentType(true);
        con.followRedirects(true);
        con.header("Accept", "application/json, text/plain, */*");
        con.header("Accept-Encoding", "gzip, deflate");
        con.header("Accept-Language", "en-US,en;q=0.8");
        con.header("Connection", "keep-alive");
        return con;
    }

    private String getAlfTicket(String user , String password) throws IOException {
        Connection con = getConnection("/alfresco/s/api/login");
        con.method(Connection.Method.GET);
        con.data("u", user);
        con.data("pw",password);
        Connection.Response res = con.execute();
        Document doc = res.parse();
        return doc.getElementsByTag("ticket").get(0).text();
    }

    public Connection getAlfrescoConnection(String endPoint, String user , String password) throws IOException {
        String alfTicket = getAlfTicket(user, password);
        Connection con = getConnection(endPoint);
        con.data("alf_ticket", alfTicket);
        return con;
    }


}
