package com.rbccm.taf.commodities.domainobjects;

import com.rbccm.taf.commodities.api.CommoditiesSession;
import com.rbccm.taf.commodities.api.CommoditiesTask;
import com.rbccm.taf.commodities.components.CommoditiesBasket;
import com.rbccm.taf.commodities.pageobjects.CommoditiesActiFlowPOM;
import com.rbccm.taf.commodities.pageobjects.CommoditiesLoginPOM;
import com.rbccm.taf.ui.support.EnvironmentsSetup;
import com.rbccm.taf.ui.support.TestContext;
import com.thoughtworks.xstream.annotations.XStreamAlias;

import java.io.IOException;

@XStreamAlias("functional-step")
public class CommoditiesStep {
    public CommoditiesLoginPOM login;
    public CommoditiesActiFlowPOM actiFlow;

    public void login(TestContext context) {
        if (login != null) {
            login.initPage(context);
            login.login();
        }
    }

    public CommoditiesActiFlowPOM getActiFlow(TestContext context) {
        actiFlow.initPage(context);
        return actiFlow;
    }


    public void waitForTaskInBasket(String adviceId, CommoditiesBasket basket) {
        String baseUrl = TestContext.getGlobalAliases().get("url");
        EnvironmentsSetup.User user = TestContext.getTestProperties().getTestEnvironment().getUser("reviewer1-0");
        try {
            CommoditiesSession session = new CommoditiesSession(baseUrl, user.getUserName(), user.getPassword());
            System.out.println("Waiting for task with adviceid " + adviceId + " in basket " + basket.getBasketName());
            new CommoditiesTask().waitForTask(session, basket.getBasketId(), adviceId);
        } catch (IOException |InterruptedException ignore) {}
    }

}
