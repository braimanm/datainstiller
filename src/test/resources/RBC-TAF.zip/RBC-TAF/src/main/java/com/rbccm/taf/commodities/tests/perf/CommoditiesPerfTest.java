package com.rbccm.taf.commodities.tests.perf;

import com.rbccm.taf.commodities.api.CommoditiesTask;
import com.rbccm.taf.commodities.domainobjects.CommoditiesPerfDOM;
import com.rbccm.taf.ui.support.TestContext;
import com.rbccm.taf.ui.testng.TestNGBase;
import org.assertj.core.api.SoftAssertions;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.Stories;
import ru.yandex.qatools.allure.model.SeverityLevel;

import java.io.IOException;

public class CommoditiesPerfTest extends TestNGBase {
    private int num;

    public CommoditiesPerfTest() {
        num = 0;
    }

    CommoditiesPerfTest(int i) {
        num = i;
    }

    private void setUsers(int num) {
        TestContext.getGlobalAliases().put("user1", "reviewer1-" + num);
        TestContext.getGlobalAliases().put("user2", "reviewer2-" + num);
        TestContext.getGlobalAliases().put("user3", "trader1-" + num);
    }


    private void assertTask (CommoditiesTask task, SoftAssertions soft) {
        long expected = task.getExpectedTime();
        long actual = task.getExecTime();
        String msg = "[" + actual + "] is expected to be less than or equal to [" + expected + "]";
        soft.assertThat(actual).withFailMessage(msg).isLessThanOrEqualTo(expected);
    }

    @Parameters({"perf-data-set"})
    @Features("Performance Test")
    @Stories("Measure Load Time For Different 'Rates' Operations")
    @Severity(SeverityLevel.CRITICAL)
    @Test
    public void performanceTest(@Optional("data/commodities/perf/commodities_perf_qa3.xml") String dataSet) throws IOException, InterruptedException {
        setUsers(num);
        SoftAssertions soft = new SoftAssertions();
        CommoditiesPerfDOM perf = new CommoditiesPerfDOM().fromResource(dataSet);
        CommoditiesTask task = perf.transferFeedFiles();
        assertTask(task, soft);
        task = perf.moveTaskFromReview1ToRevie2(task);
        assertTask(task, soft);
        task = perf.moveFromReview2ToTrader1(task);
        assertTask(task, soft);
        task = perf.moveFromTrader1ToReview2(task);
        assertTask(task, soft);
        task = perf.moveFromReview2ToReleaseDelay(task);
        assertTask(task, soft);
        task = perf.moveFromReleaseDelayToOutstandingConfirmation(task);
        assertTask(task, soft);
        String useEmail = System.getenv("USE_EMAIL");
        if (useEmail != null && useEmail.toLowerCase().trim().equals("true")) {
            perf.getAndForwardEmail(task.getAdviceId());
        } else {
            perf.getEmailAndCreateEML(task.getAdviceId());
        }
        task = perf.waitForTradeInReviewReturned(task.getAdviceId());
        task = perf.moveFromRviewReturnedToReview2Incoming(task);
        assertTask(task, soft);
        task = perf.moveOutTradeFromAllBaskets(task);
        assertTask(task, soft);
        soft.assertAll();
    }



}
