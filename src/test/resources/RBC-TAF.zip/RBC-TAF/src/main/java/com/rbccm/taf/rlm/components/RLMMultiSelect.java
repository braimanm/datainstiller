package com.rbccm.taf.rlm.components;

import com.rbccm.taf.ui.utils.Helper;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import ui.auto.core.data.DataTypes;
import ui.auto.core.pagecomponent.PageComponent;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

public class RLMMultiSelect extends PageComponent {

    @Override
    protected void init() {

    }


    private String setElementAndGetValue(String keys) {
        coreElement.clear();
        coreElement.sendKeys(keys);
        return coreElement.getAttribute("value");
    }

    @Override
    public void setValue() {
        String[] data = getData().split(",");
        for (String s : data) {
            for (int i =0; i<3; i++) {
                String val = setElementAndGetValue(s);
                Helper.waitForXHR();
                if (val.equals(s)) break;
            }
            coreElement.findElement(By.xpath("../..//li[contains(.,'" + s + "')]")).click();
            Helper.waitForXHR();
        }
    }

    @Override
    public String getValue() {
        List<WebElement> values = coreElement.findElements(By.xpath("../..//div[@class='selected']/span"));
        StringBuilder value = new StringBuilder();
        for (WebElement val : values) {
            if (value.length() == 0) {
                value = new StringBuilder(val.getText());
            } else {
                value.append(",").append(val.getText());
            }
        }
        return value.toString();
    }

    @Override
    public void validateData(DataTypes validationMethod) {
        assertThat(getValue()).isEqualTo(validationMethod.getData(this));
    }
}
