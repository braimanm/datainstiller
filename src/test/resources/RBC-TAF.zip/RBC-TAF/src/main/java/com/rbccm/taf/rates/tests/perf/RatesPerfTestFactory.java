package com.rbccm.taf.rates.tests.perf;

import com.rbccm.taf.rates.tests.perf.RatesPerfTest;
import org.testng.annotations.Factory;

public class RatesPerfTestFactory {

    @Factory()
    public Object[] createInstances() {
        int threads = 1;
        if (System.getenv().containsKey("LOAD_FLOWS")) {
            threads = Integer.parseInt(System.getenv().get("LOAD_FLOWS"));
        }
        Object[] result = new Object[threads];
        for (int i = 0; i < threads; i++) {
            result[i] = new RatesPerfTest(i + 1);
        }
        return result;
    }

}
