package com.rbccm.taf.rates.tests;

import com.rbccm.taf.rates.components.RatesTaskEntry;
import com.rbccm.taf.rates.domainobjects.RatesNoStepsDOM;
import com.rbccm.taf.rates.pageobjects.RatesActiFlowPOM;
import com.rbccm.taf.rates.pageobjects.RatesLoginPOM;
import com.rbccm.taf.ui.testng.TestNGBase;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.Description;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

import java.io.IOException;
@Features("Right click functionalities")
@Stories("Verify right click functionalities of Review Returned and Investigation baskets")
@Description("Mail Sent to Oounterparty mailbox-->Sending the trade back to Actiflow-->Trade inserted in Review returned-->Forwarded to Investigation basket")

public class RatesIncomingRightClickUITest extends TestNGBase {
    private String adviceId;
    @Parameters({"data-set1"})
    @Test
    public void tc006_tc03_01(@Optional("data/rates/TC006_TC03_Verify_Right_click_functionality_for_Review_returned_and_Investigation_Baskets/TC006_TC03_01.xml") String dataSet) throws IOException, InterruptedException {
        RatesNoStepsDOM rates = new RatesNoStepsDOM(dataSet);
        adviceId = rates.uploadGeneratedFeedFiles();

        RatesLoginPOM login = rates.getLoginPOM(getContext());
        login.login();

        RatesActiFlowPOM actiFlow = rates.getActiFlowPOM();

        actiFlow.selectBasket();

        RatesTaskEntry task = actiFlow.getTaskByAdviceId(adviceId);
        task.validateActions();
        task.doAction();
        actiFlow.validateTaskRemoval(adviceId);
        actiFlow.validateTaskMigration(adviceId);
    }

    @Parameters({"data-set2"})
    @Test (dependsOnMethods = "tc006_tc03_01")
    public void tc006_tc03_02(@Optional("data/rates/TC006_TC03_Verify_Right_click_functionality_for_Review_returned_and_Investigation_Baskets/TC006_TC03_02.xml") String dataSet) throws IOException, InterruptedException {
        RatesNoStepsDOM rates = new RatesNoStepsDOM(dataSet);

        RatesLoginPOM login = rates.getLoginPOM(getContext());
        login.login();

        RatesActiFlowPOM actiFlow = rates.getActiFlowPOM();

        actiFlow.selectBasket();

        RatesTaskEntry task = actiFlow.getTaskByAdviceId(adviceId);
        task.validateActions();
        task.doAction();
        actiFlow.validateTaskRemoval(adviceId);
        actiFlow.validateTaskMigration(adviceId);
    }

    @Parameters({"data-set3"})
    @Test(dependsOnMethods = "tc006_tc03_02")
    public void tc006_tc03_03(@Optional("data/rates/TC006_TC03_Verify_Right_click_functionality_for_Review_returned_and_Investigation_Baskets/TC006_TC03_03.xml") String dataSet) throws IOException, InterruptedException {
        RatesNoStepsDOM rates = new RatesNoStepsDOM(dataSet);

        RatesLoginPOM login = rates.getLoginPOM(getContext());
        login.login();

        RatesActiFlowPOM actiFlow = rates.getActiFlowPOM();

        actiFlow.selectBasket();

        RatesTaskEntry task = actiFlow.getTaskByAdviceId(adviceId);
        task.validateActions();
        task.doAction();
        actiFlow.validateTaskRemoval(adviceId);
        actiFlow.validateTaskMigration(adviceId);
    }

    @Parameters({"data-set4"})
    @Test(dependsOnMethods = "tc006_tc03_03")
    public void tc006_tc03_04(@Optional("data/rates/TC006_TC03_Verify_Right_click_functionality_for_Review_returned_and_Investigation_Baskets/TC006_TC03_04.xml") String dataSet) throws IOException, InterruptedException {

        RatesNoStepsDOM rates = new RatesNoStepsDOM(dataSet);
        adviceId = rates.verifyAndForwardMail();
        RatesLoginPOM login = rates.getLoginPOM(getContext());
        login.login();

        RatesActiFlowPOM actiFlow = rates.getActiFlowPOM();

        actiFlow.selectBasket();

        RatesTaskEntry task = actiFlow.getTaskByAdviceId(adviceId);
        task.validateActions();
        task.doAction();
        actiFlow.validateTaskRemoval(adviceId);
        actiFlow.validateTaskMigration(adviceId);
    }
    @Parameters({"data-set5"})
    @Test(dependsOnMethods = "tc006_tc03_04")
    public void tc006_tc03_05(@Optional("data/rates/TC006_TC03_Verify_Right_click_functionality_for_Review_returned_and_Investigation_Baskets/TC006_TC03_05.xml") String dataSet) throws IOException, InterruptedException {

        RatesNoStepsDOM rates = new RatesNoStepsDOM(dataSet);

        RatesLoginPOM login = rates.getLoginPOM(getContext());
        login.login();

        RatesActiFlowPOM actiFlow = rates.getActiFlowPOM();

        actiFlow.selectBasket();

        RatesTaskEntry task = actiFlow.getTaskByAdviceId(adviceId);
        task.validateActions();
    }
}
