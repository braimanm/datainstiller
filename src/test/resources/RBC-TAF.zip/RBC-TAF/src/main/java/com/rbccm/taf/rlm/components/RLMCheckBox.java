package com.rbccm.taf.rlm.components;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import ui.auto.core.data.DataTypes;
import ui.auto.core.pagecomponent.PageComponent;
import static org.assertj.core.api.Assertions.assertThat;

public class RLMCheckBox extends PageComponent {

    @Override
    protected void init() {
    }

    @Override
    public void setValue() {
        if (coreElement.isSelected() != Boolean.valueOf(getData().toLowerCase())) {
            coreElement.click();
        }
    }

    @Override
    public String getValue() {
        WebElement input = coreElement.findElement(By.cssSelector("input"));
        return String.valueOf(input.isSelected());
    }

    @Override
    public void validateData(DataTypes validationMethod) {
        assertThat(getValue()).isEqualToIgnoringCase(validationMethod.getData(this));
    }
}
