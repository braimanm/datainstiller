package com.rbccm.taf.mandate.pageobjects;


import com.rbccm.taf.mandate.api.EmployeeMandate;
import com.rbccm.taf.mandate.api.PositionMandate;
import com.rbccm.taf.ui.support.PageObjectModel;
import com.rbccm.taf.ui.support.TestContext;
import com.rbccm.taf.ui.utils.Helper;
import datainstiller.data.Data;
import org.assertj.core.api.Assertions;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import ru.yandex.qatools.allure.annotations.Step;
import ui.auto.core.components.CheckBox;
import ui.auto.core.components.SelectComponent;
import ui.auto.core.components.WebComponent;
import ui.auto.core.data.DataTypes;

import java.io.IOException;

public class MandateFormPOM extends PageObjectModel {
    @FindBy(xpath = "//b[starts-with(.,'Position Title')]/..")
    private WebComponent positionTitle;
    @FindBy(xpath = "//b[.='Employee Name:']/..")
    private WebComponent employeeName;
    @FindBy(xpath = "//b[.='Last Update:']/..")
    private WebComponent lastUpdate;
    @FindBy(xpath = "//b[.='Department:']/..")
    private WebComponent department;
    @FindBy(xpath = "//b[.='Employee ID:']/..")
    private WebComponent employeeID;
    @FindBy(xpath = "//b[.='Status:']/..")
    private WebComponent status;
    @FindBy(xpath = "//b[.='This role has direct reports: ']/..")
    private WebComponent thisRoleHasDirectReports;
    @FindBy(xpath = "//b[.='Functional Line Manager:']/..")
    private WebComponent functionalLineManager;
    @FindBy(id = "activiti-registeredRole")
    private CheckBox isRegisteredRole;
    @FindBy(id = "activiti-effectiveDate")
    private WebComponent effectiveDate;
    @FindBy(id = "activiti-level")
    private WebComponent level;
    @FindBy(id = "localManagerId")
    private WebComponent localManager;
    @Data(skip = true)
    @FindBy(xpath = "//a[.='Conduct']")
    private WebComponent conductTab;
    @Data(skip = true)
    @FindBy(id = "activiti-readandunderstood")
    private CheckBox acknowledgeCheckBox;
    @Data(skip = true)
    @FindBy(id ="activiti-employeeSelectedAction")
    private SelectComponent action;
    @Data(skip = true)
    @FindBy(css = "[form-data=formData] #form_complete_button")
    private WebComponent completeButton;
    @Data(skip = true)
    @FindBy(xpath = "//a[.='Approval']")
    private WebComponent approvalTab;
    @Data(skip = true)
    @FindBy(id ="activiti-managerSelectedAction")
    private SelectComponent managerAction;
    @Data(skip = true)
    @FindBy(css = "#message")
    private WebComponent message;
    @Data(skip = true)
    @FindBy(xpath = "//div[@id='formsection']//button[.='Create Mandate']")
    private WebComponent buttonCreateMandate;
    @Data(skip = true)
    @FindBy(xpath = "//button[.='Okay']")
    private WebComponent buttonOkayDelete;
    @Data(skip = true)
    @FindBy(css = "#prompt .bd")
    private WebComponent prompt;
    @Data(skip = true)
    @FindBy(css = "#prompt button")
    private WebComponent buttonPromptOk;


    @Step("Validate form's initial values")
    public void validateFormInitialValues() {
        autoValidatePage(DataTypes.Initial);
    }

    @Step("Fill form with provided data")
    public void fill() {
        autoFillPage();
    }

    @Step("Sign and complete the Job Mandate form")
    public void signAndComplete() throws IOException {
        EmployeeMandate.getEmployees("employee")[0].waitForWorkflowStatus("Employee Review" );
        conductTab.click();
        acknowledgeCheckBox.check();
        setElementValue(action, "Sign Mandate");
        Helper.getWebDriiverWait().until(ExpectedConditions.elementToBeClickable(completeButton.getCoreElement()));
        completeButton.click();
        Assertions.assertThat(message.getText()).isEqualTo("Task completed");
        waitForUrlToChange();
    }

    @Step("Cancel Job Mandate")
    public void cancel() {
        conductTab.click();
        setElementValue(action,"Cancel Mandate");
        Assertions.assertThat(completeButton.isEnabled());
        Helper.getWebDriiverWait().until(ExpectedConditions.elementToBeClickable(completeButton.getCoreElement()));
        completeButton.click();
        Assertions.assertThat(message.getText()).isEqualTo("Task completed");
        waitForUrlToChange();
    }

    @Step("Approve Job Mandate")
    public void managerApprove() {
        approvalTab.click();
        setElementValue(managerAction,"Approved");
        Helper.getWebDriiverWait().until(ExpectedConditions.elementToBeClickable(completeButton.getCoreElement()));
        completeButton.click();
        Assertions.assertThat(message.getText()).isEqualTo("Task completed");
        waitForUrlToChange();
        EmployeeMandate.getEmployees("employee")[0].waitForWorkflowStatus("Signed");
    }

    @Step("Create Job Mandate")
    public void createManagersMandate() {
        buttonCreateMandate.click();
        Helper.waitToShow(message);
        Assertions.assertThat(message.getText()).isEqualTo("Task completed");
        waitForUrlToChange();
        String posTitle = TestContext.getGlobalAliases().get("time-stamp");
        PositionMandate.waitForPositionStatus("manager", posTitle, "Complete");
    }

    @Step("Delete Job Mandate Template")
    public void deleteJobMandate() {
        String posTitle = TestContext.getGlobalAliases().get("time-stamp");
        By by = By.xpath("//span[.='" + posTitle + "']/../../../..//button");
        WebElement deleteButton = Helper.waitToShow(by);
        Assertions.assertThat(deleteButton.getText()).isEqualTo("Delete");
        deleteButton.click();
        buttonOkayDelete.click();
        //Assertions.assertThat(prompt.getText()).isEqualTo("Mandate Template Deleted.");
        //buttonPromptOk.click();
    }
}
