package com.rbccm.taf.sds.components;

import com.rbccm.taf.ui.utils.Helper;
import org.openqa.selenium.By;
import ui.auto.core.data.DataTypes;
import ui.auto.core.pagecomponent.PageComponent;

import static org.assertj.core.api.Assertions.assertThat;

public class SDSAutocomplete extends PageComponent {

    @Override
    protected void init() {
    }

    @Override
    public void setValue() {
        String data = getData();
        coreElement.clear();
        coreElement.sendKeys(data);
        Helper.waitForXHR();
        coreElement.findElement(By.xpath("..//li[starts-with(.,'" + data + "')]")).click();
    }

    @Override
    public String getValue() {
        return coreElement.getAttribute("value");
    }

    @Override
    public void validateData(DataTypes dataTypes) {
        String valdata = dataTypes.getData(this);
        assertThat(getValue()).isEqualTo(valdata);
    }
}
