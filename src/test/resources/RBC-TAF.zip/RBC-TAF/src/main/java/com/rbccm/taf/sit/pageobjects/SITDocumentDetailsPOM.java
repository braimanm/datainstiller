package com.rbccm.taf.sit.pageobjects;

import com.rbccm.taf.sit.components.SITDocumentViewer;
import com.rbccm.taf.ui.support.AliasedString;
import com.rbccm.taf.ui.support.PageObjectModel;
import com.rbccm.taf.ui.utils.Helper;
import com.thoughtworks.xstream.annotations.XStreamAlias;
import datainstiller.data.Data;
import org.apache.commons.io.FileUtils;
import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import ru.yandex.qatools.allure.annotations.Step;
import ui.auto.core.components.WebComponent;
import ui.auto.core.pagecomponent.PageComponent;
import java.io.File;
import java.io.IOException;
import java.util.List;

@XStreamAlias("document-details")
public class SITDocumentDetailsPOM extends PageObjectModel {
    @Data(skip = true)
    @FindBy(css = "iframe[name=Embed]")
    SITDocumentViewer documentViewer;
    AliasedString documentFolderName;
    AliasedString documentFileName;
    DocumentActions documentActions;
    DocumentProperties documentProperties;

    public static class DocumentActions extends PageObjectModel {
        @FindBy(xpath = "//a[.='Download']")
        WebComponent actionDownload;
        @FindBy(css = ".document-view-content")
        WebComponent actionViewInBrowser;
        @FindBy(css = ".document-edit-metadata")
        WebComponent actionEditProperties;
        @FindBy(css = ".document-upload-new-version")
        WebComponent actionUploadNewVersion;
        @FindBy(css = ".document-edit-online-aos")
        WebComponent actionEditOnline;
        @FindBy(css = ".document-edit-offline")
        WebComponent actionEditOffline;
        @FindBy(css = ".document-copy-to")
        WebComponent actionCopyTo;
        @FindBy(css = ".document-move-to")
        WebComponent actionMoveTo;
        @FindBy(css = ".document-delete")
        WebComponent actionDeleteDocument;
        @FindBy(css = ".document-assign-workflow")
        WebComponent actionStartWorkflow;
        @FindBy(css = ".document-manage-granular-permissions")
        WebComponent actionManagePermissions;
        @FindBy(css = ".document-manage-aspects")
        WebComponent actionManageAspects;
        @FindBy(css = ".document-change-type")
        WebComponent actionChangeType;

        @Step("Validate Actions")
        public void validateActions(SoftAssertions softAssertions) {
            enumerateFields((pageComponent, field) -> {
                String actionName = field.getName().replace("action","");
                validateAction(actionName, pageComponent, softAssertions);
            });
        }

        @Step("Validate action \"{0}\" Is Displayed")
        private void validateAction(String actionName, PageComponent action, SoftAssertions softAssertions) {
            if (action.getData().trim().toLowerCase().equals("true")) {
                List<WebElement> els = getDriver().findElements(action.getLocator());
                softAssertions.assertThat(els).withFailMessage("Action " + actionName + " was not found!").isNotEmpty();
            } else  {
                List<WebElement> els = getDriver().findElements(action.getLocator());
                softAssertions.assertThat(els).withFailMessage("Action " + actionName + " should not be displayed!").isEmpty();
            }
        }

        @Step("Validate file download for file \"{1}\"")
        public synchronized void validateDownload(String documentFolderName, String documentFileName, SoftAssertions softAssertions) throws IOException {
            File downloadFile = new File(System.getProperty("user.home") + "/Downloads/" + documentFileName);
            if (downloadFile.exists()) {
                downloadFile.delete();
            }
            actionDownload.click();
            long t_o = System.currentTimeMillis() + 5000;
            boolean done = false;
            do {
                Helper.sleep(100);
                if (downloadFile.exists() && downloadFile.canRead() && downloadFile.canWrite()) {
                    done = true;
                }
            } while (!done && System.currentTimeMillis() < t_o);
            long checkSumOriginal = FileUtils.checksumCRC32( new File(documentFolderName + documentFileName));
            long checkSumDownload = 0;
            long t_0 = System.currentTimeMillis() + 5000;
            do {
                try {
                    checkSumDownload = FileUtils.checksumCRC32(downloadFile);
                } catch (Exception e) {
                    Helper.sleep(100);
                }
            } while (checkSumDownload == 0 && System.currentTimeMillis()<t_o);
            softAssertions.assertThat(checkSumOriginal).withFailMessage("The downloaded file " + documentFileName + " is not the same as original!").isEqualTo(checkSumDownload);
        }
    }

    public static class DocumentProperties extends PageObjectModel {
        @FindBy(xpath = "//h2[contains(@id,'document-metadata')]//..//span[.='Name:']//../span[@class='viewmode-value']")
        WebComponent propName;
        @FindBy(xpath = "//h2[contains(@id,'document-metadata')]//..//span[.='Title:']//../span[@class='viewmode-value']")
        WebComponent propTitle;
        @FindBy(xpath = "//h2[contains(@id,'document-metadata')]//..//span[.='Description:']//../span[@class='viewmode-value']")
        WebComponent propDescription;
        @FindBy(xpath = "//h2[contains(@id,'document-metadata')]//..//span[.='Mimetype (File Extension Type):']//../span[@class='viewmode-value']")
        WebComponent propMimeType;
        @FindBy(xpath = "//h2[contains(@id,'document-metadata')]//..//span[.='Author:']//../span[@class='viewmode-value']")
        WebComponent propAuthor;
        @FindBy(xpath = "//h2[contains(@id,'document-metadata')]//..//span[.='Size:']//../span[@class='viewmode-value']")
        WebComponent propSize;
        @FindBy(xpath = "//h2[contains(@id,'document-metadata')]//..//span[.='Creator:']//../span[@class='viewmode-value']")
        WebComponent propCreator;
        @FindBy(xpath = "//h2[contains(@id,'document-metadata')]//..//span[.='Created Date:']//../span[@class='viewmode-value']")
        WebComponent propCreatedDate;
        @FindBy(xpath = "//h2[contains(@id,'document-metadata')]//..//span[.='Modifier:']//../span[@class='viewmode-value']")
        WebComponent propModifier;
        @FindBy(xpath = "//h2[contains(@id,'document-metadata')]//..//span[.='Modified Date:']//../span[@class='viewmode-value']")
        WebComponent propModifiedDate;

        @Step("Validate properties")
        public void validateProperties (SoftAssertions softAssertions) {
            enumerateFields((pageComponent, field) -> {
                String propName = field.getName().replace("prop","");
                validateProperty(propName, pageComponent, softAssertions);
            });
        }


        private void validateProperty (String propName, PageComponent property, SoftAssertions softAssertions) {
            String propData = property.getData();
            if (propData != null && !propData.isEmpty()) {
                List<WebElement> els = getDriver().findElements(property.getLocator());
                softAssertions.assertThat(els).withFailMessage("RatesTaskProperty " + propName + " is not displayed!").isNotEmpty();
                if (!els.isEmpty()) {
                    String propValue = property.getValue();
                    assertProperty(propName, propValue, propData, softAssertions);
                }
            }
        }

        @Step("Validate property \"{0}\" has value of \"{2}\"")
        private void assertProperty(String propName, String actual, String expected, SoftAssertions softAssertions) {
            softAssertions.assertThat(actual).isEqualTo(expected);
        }


    }

    public void validateDocument(String folderName) throws IOException {
        SoftAssertions softAssertions = new SoftAssertions();
        documentActions.initPage(getContext());
        documentActions.validateActions(softAssertions);
        //documentActions.validateDownload(documentFolderName.getData(), documentFileName.getData(), softAssertions);
        documentProperties.initPage(getContext());
        documentProperties.validateProperties(softAssertions);
        softAssertions.assertAll();
        documentViewer.validateDocument(documentFolderName.getData(), documentFileName.getData(), folderName);

    }

}
