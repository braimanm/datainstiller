package com.rbccm.taf.rates.pageobjects;


import com.rbccm.taf.ui.support.PageObjectModel;
import com.rbccm.taf.ui.testng.TestNGBase;
import com.rbccm.taf.ui.utils.Helper;
import datainstiller.data.Data;
import org.openqa.selenium.support.FindBy;
import ru.yandex.qatools.allure.annotations.Step;
import ui.auto.core.components.WebComponent;
import ui.auto.core.data.DataTypes;

public class RatesWorkFlowStatusPOM extends PageObjectModel{

    @Data(skip = true)
    @FindBy(css = "#workflow-status_wnd_title")
    WebComponent title;

    @FindBy(css = "[kendo-grid='wfStatusGrid']>div:nth-child(2)>table>tbody>tr:nth-child(1)>td:nth-child(3)")
    WebComponent taskName;

    @Data(skip = true)
    @FindBy(xpath = "//*[@id='workflow-status_wnd_title']//following::span[text()='Close']")
    WebComponent closeBtn;

    @Step("Verify the workflow status of the trade")
    public void validateWorkFlowStatus(){
            taskName.validateData(DataTypes.Data);
            closeBtn.click();
            Helper.waitForXHR();
        }
    }

