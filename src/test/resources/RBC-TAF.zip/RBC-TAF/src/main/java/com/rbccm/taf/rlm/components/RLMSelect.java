package com.rbccm.taf.rlm.components;

import com.rbccm.taf.ui.testng.TestNGBase;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import ui.auto.core.data.DataTypes;
import ui.auto.core.pagecomponent.PageComponent;


public class RLMSelect extends PageComponent {

    @Override
    protected void init() {
    }


    private void waitForOptionWithValue(String value) {
        boolean done = false;
        long to = System.currentTimeMillis() + TestNGBase.CONTEXT().getAjaxTimeOut() * 1000;
        do {
            if (coreElement.findElements(By.cssSelector("option[value='" + value + "'")).size() > 0) {
                done = true;
            }
        } while(!done && System.currentTimeMillis() < to);
        if (!done) {
            throw new RuntimeException("Option with value " + value + " was not found!");
        }
    }

    @Override
    public void setValue() {
        waitForOptionWithValue(getData());
        new Select(coreElement).selectByVisibleText(getData());
    }

    @Override
    public String getValue() {
        if (coreElement.getTagName().equals("select")) {
            return new Select(coreElement).getFirstSelectedOption().getText();
        } else {
            return coreElement.getAttribute("value");
        }
    }

    @Override
    public void validateData(DataTypes validationMethod) {
        Assert.assertEquals(getValue(), validationMethod.getData(this));
    }

}
