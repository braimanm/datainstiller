package com.rbccm.taf.common.components;

import org.openqa.selenium.WebElement;
import ui.auto.core.data.DataTypes;
import ui.auto.core.pagecomponent.PageComponent;

import static org.assertj.core.api.Assertions.assertThat;

public class RadioButton extends PageComponent {


    public RadioButton(){}

    public RadioButton(WebElement element) {
        super(element);
    }

    @Override
    protected void init() {
        if (!coreElement.getAttribute("tupe").equals("radio")) {
            throw new RuntimeException("Given element is not radio button");
        }
    }

    @Override
    public void setValue() {
        coreElement.click();
    }

    @Override
    public String getValue() {
        return Boolean.toString(coreElement.isSelected());
    }

    @Override
    public void validateData(DataTypes validationMethod) {
        assertThat(getValue()).isEqualToIgnoringCase(validationMethod.getData(this));
    }

    public void validateData() {
        validateData(DataTypes.Data);
    }

}
