package com.rbccm.taf.rates.components;

import com.rbccm.taf.ui.support.TestContext;
import com.rbccm.taf.ui.support.WebDriverTypeEnum;
import com.rbccm.taf.ui.utils.Helper;
import org.assertj.core.api.Assertions;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import ui.auto.core.data.DataTypes;
import ui.auto.core.pagecomponent.PageComponent;

import java.util.List;

public class RatesBasketsPanel extends PageComponent {

    @Override
    protected void init() {}

    private void removeAll() {
        List<WebElement> selectedBaskets = coreElement.findElements(By.cssSelector("tr img[src$='/check.png']"));
        for (WebElement basket : selectedBaskets) {
            basket.click();
            //There is a IE problem: Selenium IE web-driver can't clean cookies and last selected basket is selected
            //at the begging of each new session, and during the basket un-select we need to wait for action completion
            if(TestContext.getTestProperties().getBrowserType().equals(WebDriverTypeEnum.IE)) {
                Helper.waitToHide(By.id("loadingModal"));
                Helper.waitToHide(By.id("ngProgress"));
            }
        }
    }

    @Override
    public void setValue() {
        removeAll();
        String[] baskets = getData().split(",");
        for (int i = 0; i < baskets.length; i++) {
            WebElement basket = Helper.waitToShow(coreElement, By.xpath(".//span[contains(.,'" + baskets[i] + "')]"));
            if (basket.findElement(By.tagName("img")).getAttribute("src").contains("uncheck.png")) {
                basket.click();
                Helper.waitForXHR(5000, 100);
                Helper.waitToHide(By.id("loadingModal"));
                Helper.waitToHide(By.id("ngProgress"));
            }
        }
    }

    @Override
    public String getValue() {
        String values = "";
        boolean start = true;
        List<WebElement> selectedBaskets = coreElement.findElements(By.cssSelector("tr img[src$='/check.png']"));
        for (WebElement basket : selectedBaskets) {
            values += (start ? "" : ",") + basket.findElement(By.xpath("..")).getText();
            start = false;
        }
        return values;
    }

    @Override
    public void validateData(DataTypes validationMethod) {
        String value = getValue();
        String[] baskets = validationMethod.getData(this).split(",");
        for (String basket : baskets) {
            Assertions.assertThat(value).contains(basket);
        }
    }

}
