package com.rbccm.taf.commodities.api;

import org.apache.sshd.client.SshClient;
import org.apache.sshd.client.keyverifier.AcceptAllServerKeyVerifier;
import org.apache.sshd.client.keyverifier.KnownHostsServerKeyVerifier;
import org.apache.sshd.client.scp.DefaultScpClient;
import org.apache.sshd.client.scp.ScpClient;
import org.apache.sshd.client.session.ClientSession;
import org.apache.sshd.common.config.keys.FilePasswordProvider;
import org.apache.sshd.common.keyprovider.ClassLoadableResourceKeyPairProvider;
import org.apache.sshd.common.keyprovider.KeyPairProvider;

import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.attribute.PosixFilePermissions;


public class CommoditiesSCP {
    private String host;
    private String user;
    private String encPswd;

    public CommoditiesSCP(String host, String user, String encPswd) {
        this.host = host;
        this.user = user;
        this.encPswd = encPswd;
    }

    public void transferFile(byte[] content, String fileName, String destFolder) throws IOException, InterruptedException {
        SshClient client = SshClient.setUpDefaultClient();
        client.setServerKeyVerifier(new KnownHostsServerKeyVerifier(AcceptAllServerKeyVerifier.INSTANCE, FileSystems.getDefault().getPath("","hostkeys" )));
        client.start();

        try (ClientSession session = client.connect(user, host, 22).verify(10000).getSession()) {

            ClassLoadableResourceKeyPairProvider provider = new ClassLoadableResourceKeyPairProvider("data/commodities/feed/id_rsa");
            provider.setPasswordFinder(FilePasswordProvider.of(System.getenv("SSH_PKEYPASS")));
            session.addPublicKeyIdentity(provider.loadKey(KeyPairProvider.SSH_RSA));

            boolean done = false;
            int retry = 5;
            do {
                try {
                    session.auth().verify(10000);
                    done = true;
                } catch (Exception ignore) {
                    retry--;
                    Thread.sleep(100);
                }
            } while (!done && retry > 0);
            if (!done) {
                throw new RuntimeException("SCP authentication failed" );
            }

            ScpClient scp = new DefaultScpClient(session, null, null);
            scp.upload(content, destFolder + fileName, PosixFilePermissions.fromString("rw-rw-rw-"), null);

        } finally {
            client.stop();
        }
    }
}
