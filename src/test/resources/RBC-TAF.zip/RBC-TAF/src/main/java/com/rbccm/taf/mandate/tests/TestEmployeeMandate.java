package com.rbccm.taf.mandate.tests;

import com.rbccm.taf.mandate.api.EmployeeMandate;
import com.rbccm.taf.mandate.domainobjects.MandateWorkflowDOM;
import com.rbccm.taf.mandate.pageobjects.MandateDashboardPOM;
import com.rbccm.taf.mandate.pageobjects.MandateFormPOM;
import com.rbccm.taf.ui.testng.Retry;
import com.rbccm.taf.ui.testng.TestNGBase;
import org.testng.annotations.*;
import ru.yandex.qatools.allure.annotations.*;
import ru.yandex.qatools.allure.model.SeverityLevel;

import java.io.IOException;

public class TestEmployeeMandate extends TestNGBase {
    private MandateWorkflowDOM mandateWorkflowDOM;

    @BeforeMethod
    @Parameters("employee-data-set")
    @Step("Setup & Cleanup")
    private void cleanUp(@Optional("data/mandate/mandate-employee-workflow-data.xml") String dataSet) {
        mandateWorkflowDOM = new MandateWorkflowDOM(getContext()).fromResource(dataSet);
        EmployeeMandate employeeMandate = EmployeeMandate.getEmployees("employee")[0];
        System.out.println(employeeMandate.workflowStatus);
        try {
            if (employeeMandate.workflowStatus.equals("Manager Review")) {
                MandateDashboardPOM dashboard = mandateWorkflowDOM.login("manager");
                dashboard.getMandateForUser(employeeMandate.displayName, "Edit");
                mandateWorkflowDOM.getMandateFormPOM().managerApprove();
                mandateWorkflowDOM.deleteDocumentFolderForUser(employeeMandate.displayName);
            }
            if (employeeMandate.workflowStatus.equals("Signed")) {
                mandateWorkflowDOM.login("manager");
                mandateWorkflowDOM.deleteDocumentFolderForUser(employeeMandate.displayName);
            }
            if (employeeMandate.workflowStatus.equals("Employee Review")) {
                MandateDashboardPOM dashboard = mandateWorkflowDOM.login();
                dashboard.getMandateForUser(employeeMandate.displayName, "Edit");
                mandateWorkflowDOM.getMandateFormPOM().cancel();
                getContext().getDriver().manage().deleteAllCookies();
            }
        } catch (Exception e) {
            takeScreenshot("Failure during setup");
            throw new RuntimeException(e);
        }
    }


    @Description("Test for validating general application behaviour")
    @Features("Mandate Test")
    @Stories("Validate employee mandate creation workflow")
    @Severity(SeverityLevel.CRITICAL)
    @Test
    @Retry
    public void testEmployeeMandate() throws IOException {
        EmployeeMandate employeeMandate = EmployeeMandate.getEmployees("employee")[0];
        MandateDashboardPOM dashboard = mandateWorkflowDOM.login();
        dashboard.getMandateForUser(employeeMandate.displayName, "Create");
        MandateFormPOM mandateForm = mandateWorkflowDOM.getMandateFormPOM();
        mandateForm.validateFormInitialValues();
        mandateForm.fill();
        mandateForm.signAndComplete();
        dashboard = mandateWorkflowDOM.login("manager");
        dashboard.getMandateForUser(employeeMandate.displayName, "Edit");
        mandateWorkflowDOM.getMandateFormPOM().managerApprove();
        mandateWorkflowDOM.deleteDocumentFolderForUser(employeeMandate.displayName);
    }
}
