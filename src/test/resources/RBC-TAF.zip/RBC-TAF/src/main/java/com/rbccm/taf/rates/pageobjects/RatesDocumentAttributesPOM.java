package com.rbccm.taf.rates.pageobjects;


import com.rbccm.taf.ui.support.PageObjectModel;
import com.rbccm.taf.ui.utils.Helper;
import datainstiller.data.Data;
import org.modelmapper.internal.util.Assert;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import ru.yandex.qatools.allure.annotations.Step;
import ui.auto.core.components.WebComponent;
import ui.auto.core.data.DataTypes;

import static org.assertj.core.api.Assertions.assertThat;

public class RatesDocumentAttributesPOM extends PageObjectModel{

    @FindBy(css = "[kendo-grid='docAttrGrid']>div:nth-child(2)>table>tbody>tr:nth-child(6)>td:nth-child(2)")
    WebComponent adviceID;

    @FindBy(css="[kendo-grid='docAttrGrid']>div:nth-child(2)>table>tbody>tr:nth-child(10)>td:nth-child(2)")
    WebComponent cpty;

    @FindBy(css="[kendo-grid='docAttrGrid']>div:nth-child(2)>table>tbody>tr:nth-child(11)>td:nth-child(2)")
    WebComponent cptyName;

    @FindBy(css="[kendo-grid='docAttrGrid']>div:nth-child(2)>table>tbody>tr:nth-child(20)>td:nth-child(2)")
    WebComponent product;

    @FindBy(css="[kendo-grid='docAttrGrid']>div:nth-child(2)>table>tbody>tr:nth-child(21)>td:nth-child(2)")
    WebComponent confirmationType;

    @FindBy(css="[kendo-grid='docAttrGrid']>div:nth-child(2)>table>tbody>tr:nth-child(32)>td:nth-child(2)")
    WebComponent businessType;

    @Data(skip = true)
    @FindBy(xpath = "//*[@id='worklist-doc-attrs_wnd_title']//following::span[text()='Close']")
    WebComponent closeBtn;

    @Step("Validate Document Attributes table displayed with the correct attributes and their values.")
    public void validateDocumentAttributes(){

        adviceID.validateData(DataTypes.Data);
        cpty.validateData(DataTypes.Data);
        cptyName.validateData(DataTypes.Data);
        product.validateData(DataTypes.Data);
        confirmationType.validateData(DataTypes.Expected);
        businessType.validateData(DataTypes.Data);
        closeBtn.click();
        Helper.waitForXHR();
    }

}
