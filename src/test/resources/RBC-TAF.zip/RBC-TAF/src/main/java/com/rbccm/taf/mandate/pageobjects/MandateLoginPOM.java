package com.rbccm.taf.mandate.pageobjects;

import com.rbccm.taf.ui.support.AliasedString;
import com.rbccm.taf.ui.support.PageObjectModel;
import com.rbccm.taf.ui.support.TestContext;
import datainstiller.data.Data;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.FindBy;
import ru.yandex.qatools.allure.annotations.Step;
import ui.auto.core.components.WebComponent;

public class MandateLoginPOM extends PageObjectModel {
    public AliasedString url;
    @FindBy(name = "username")
    private WebComponent userName;
    @FindBy(name = "password")
    private WebComponent password;
    @Data(skip = true)
    @FindBy(css = "button[type=button]")
    private WebComponent loginButton;
    @Data(skip = true)
    @FindBy(css = "#employeeMandateId tbody[tabindex='0']")
    private WebComponent tableEntry;

    public MandateLoginPOM(){}
    public MandateLoginPOM(TestContext context) {
        initPage(context);
    }

    @Step("Login to RBC Mandate application")
    public MandateDashboardPOM login() {
        return login(userName.getData(), password.getData());
    }

    @Step("Login using user \"{0}\" and password \"{1}\"")
    public MandateDashboardPOM login(String user, String pswrd) {
        getDriver().manage().deleteAllCookies();
        getDriver().get(url.getData() + "?pt=login");
        int retry = 3;
        boolean entered = false;
        do {
            setElementValue(userName, user + Keys.TAB, false);
            setElementValue(password, pswrd);
            if (userName.getValue().equals(user) && password.getValue().equals(pswrd)) {
                entered = true;
            } else {
                retry--;
            }
        } while (retry != 0 && !entered);
        loginButton.click();
        getDriver().get(url.getData() + "/site/rbc-mandate/dashboard");
        tableEntry.isDisplayed();
        return new MandateDashboardPOM(getContext());
    }

}
