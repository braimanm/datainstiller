package com.rbccm.taf.rates.domainobjects;

import com.rbccm.taf.mail.EWSMail;
import com.rbccm.taf.rates.api.RatesIndexFile;
import com.rbccm.taf.rates.api.RatesSCP;
import com.rbccm.taf.rates.api.RatesSession;
import com.rbccm.taf.rates.api.RatesTask;
import com.rbccm.taf.ui.support.*;
import datainstiller.data.Data;
import microsoft.exchange.webservices.data.core.service.item.Item;
import microsoft.exchange.webservices.data.search.FindItemsResults;
import org.apache.commons.io.IOUtils;
import org.assertj.core.api.Assertions;
import ru.yandex.qatools.allure.Allure;
import ru.yandex.qatools.allure.annotations.Step;
import ru.yandex.qatools.allure.events.StepEvent;
import ru.yandex.qatools.allure.model.Status;

import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@SuppressWarnings("unused")
public class RatesPerfDOM extends DomainObjectModel {
    private AliasedString feedDestinationFolder;
    private AliasedString emlDestinationFolder;
    private AliasedString baseUrl;
    private AliasedString emailCredentials;
    private AliasedString forwardEmail;
    private AliasedString user1;
    private AliasedString user2;
    private AliasedString user3;
    private int expectedResult1;
    private int expectedResult2;
    private int expectedResult3;
    private int expectedResult4;
    private int expectedResult5;
    private int expectedResult6;
    private int expectedResult7;
    private int expectedResult8;
    @Data(skip = true)
    private Map<AliasedString, RatesSession> sessions;


    private RatesSession getSession(AliasedString user)  {
        if (sessions == null) {
            sessions = new HashMap<>();
            EnvironmentsSetup.User u1 = TestContext.getTestProperties().getTestEnvironment().getUser(user1.getData());
            EnvironmentsSetup.User u2 = TestContext.getTestProperties().getTestEnvironment().getUser(user2.getData());
            EnvironmentsSetup.User u3 = TestContext.getTestProperties().getTestEnvironment().getUser(user3.getData());
            try {
                sessions.put(user1, new RatesSession(baseUrl.getData(), u1.getUserName(), u1.getPassword()));
                sessions.put(user2, new RatesSession(baseUrl.getData(), u2.getUserName(), u2.getPassword()));
                sessions.put(user3, new RatesSession(baseUrl.getData(), u3.getUserName(), u3.getPassword()));
            } catch (IOException e) {
                throw new RuntimeException("Can't create session", e);
            }
        }
        return sessions.get(user);
    }

    @Step("Data Feed into Rates")
    private RatesTask createDataFeed(RatesSession session,
                                     String adviceId) throws IOException, InterruptedException {
        long time = System.currentTimeMillis();
        RatesTask task = new RatesTask().waitForTask(session, "1", adviceId);
        final long finalTime = System.currentTimeMillis() - time;
        System.out.println("'Upload feed files and wait for task' (" + finalTime + "ms)");
        Allure.LIFECYCLE.fire((StepEvent) step -> {
            step.setTitle(step.getTitle() + " (" + finalTime + "ms)");
            if (finalTime > expectedResult1 * 1000) {
                step.setStatus(Status.FAILED);
            }
        });
        Assertions.assertThat(task).withFailMessage("Timeout has been reached").isNotNull();
        task.setExecTime(finalTime);
        task.setExpectedTime(expectedResult1 * 1000);
        return task;
    }

    @Step
    private RatesTask moveTask(String stepName, RatesTask rTask,
                               AliasedString u1, String actionOrUser, boolean isAction,
                               AliasedString u2, String basketId, String status,
                               int expectedResult) throws IOException, InterruptedException {
        long start = System.currentTimeMillis();
        int statusCode;
        int retry = 0;
        do {
            retry++;
            statusCode = new RatesTask().completeTaskAction(getSession(u1), rTask.getTaskId(), actionOrUser, isAction);
            if (statusCode != 200) Thread.sleep(100);
        } while (statusCode != 200 && retry < 10 );
        if (statusCode != 200) {
            throw new RuntimeException("Move task failed, tried " + retry + " times");
        }
        RatesTask task;
        if (!basketId.isEmpty()) {
            task = new RatesTask().waitForTask(getSession(u2), basketId, rTask.getAdviceId(), status);
        } else {
            task = new RatesTask();
        }
        long finalTime = System.currentTimeMillis() - start;
        stepName = stepName.replace("<id>", rTask.getAdviceId());
        if (!basketId.isEmpty()) {
            Assertions.assertThat(task).withFailMessage("Transfer was failed for test : " + stepName).isNotNull();
        }
        String stepDescription = stepName + " (" + finalTime + "ms)";
        System.out.println(stepDescription);
        Allure.LIFECYCLE.fire((StepEvent) step -> {
            step.setTitle(stepDescription);
            if (finalTime > expectedResult * 1000) {
                step.setStatus(Status.FAILED);
            }
        });
        task.setExecTime(finalTime);
        task.setExpectedTime(expectedResult * 1000);
        return task;
    }

    public RatesTask transferFeedFiles() throws IOException, InterruptedException {
        String doc = "data/rates/feed/ADVICE.html";
        InputStream isDoc = getClass().getClassLoader().getResourceAsStream(doc);
        byte[] document = IOUtils.toByteArray(isDoc);
        IOUtils.closeQuietly(isDoc);

        String timestamp = DateTimeFormatter.ofPattern("yyMMddkkmmss").format(LocalDateTime.now()) + Thread.currentThread().getId();
        String adviceId = "T" + timestamp;
        String fileName = "ADVICE_" + timestamp + "_" + adviceId;
        RatesIndexFile indexFile = new RatesIndexFile(adviceId);
        byte[] index = indexFile.getPropsAsBytes();

        EnvironmentsSetup.User usr = TestContext.getTestProperties().getTestEnvironment().getUser("ssh");
        String sshServer = baseUrl.getData();
        sshServer = sshServer.substring(sshServer.indexOf(":") + 3, sshServer.lastIndexOf(":"));
        RatesSCP scp = new RatesSCP(sshServer, usr.getUserName(), usr.getPassword());

        scp.transferFile(document, fileName + ".html", feedDestinationFolder.getData());
        scp.transferFile(index, fileName + ".index", feedDestinationFolder.getData());
        System.out.println("Task with advice id " + adviceId + " was created and moved to server");
        return createDataFeed(getSession(user1), adviceId);
    }

    public RatesTask moveTaskFromReview1ToRevie2(RatesTask rTask) throws IOException, InterruptedException {
        String testName = "Trade <id> forwarded from Vanilla Review 1 basket to 2nd Review Vanilla basket";
        return moveTask(testName, rTask, user1, "review2", true, user1, "2", null, expectedResult2 );
    }

    public RatesTask moveFromReview2ToTrader1(RatesTask rTask) throws IOException, InterruptedException {
        String testName = "Trade <id> forwarded from 2nd Review Vanilla to Review Trader";
        String user = TestContext.getTestProperties().getTestEnvironment().getUser(user3.getData()).getUserName();
        return moveTask(testName, rTask, user2, user, false, user3, "11", null, expectedResult3);
    }

    public RatesTask moveFromTrader1ToReview2(RatesTask rTask) throws IOException, InterruptedException {
        String testName = "Trade <id> moved from Review Trader to 2nd Review Vanilla";
        return moveTask(testName, rTask, user3, "approvewithoutcomment", true, user2, "2", "Review approved", expectedResult4 );
    }

    public RatesTask moveFromReview2ToReleaseDelay(RatesTask rTask) throws IOException, InterruptedException {
        String testName = "Trade <id> moved from 2nd Review Vanilla to Release Delay";
        return moveTask(testName, rTask, user2, "releaseDelay", true, user2, "13", null, expectedResult5);
    }

    public RatesTask moveFromReleaseDelayToOutstandingConfirmation(RatesTask rTask) throws IOException, InterruptedException {
        String testName = "Trade <id> moved from Release Delay to Outstanding Confirmation";
        return moveTask(testName, rTask, user2, "faxTask", true, user2, "14", null, expectedResult6);
    }

    @Step("Wait for email with Advice Id {0} and forward it to counterparty")
    public void getAndForwardEmail(String adviceId) {
        long start = System.currentTimeMillis();
        EWSMail mail = new EWSMail();
        String[] cred = emailCredentials.getData().split(",");
        mail.setCredentials(cred[0], cred[1]);
        FindItemsResults<Item> mailItems = mail.waitForEmailWithSubject(adviceId);
        Assertions.assertThat(mailItems.getTotalCount()).withFailMessage("No email was reseived!").isGreaterThan(0);
        mail.forwardEmail(mailItems.getItems().get(0), forwardEmail.getData(), "EMAIL FORWARDED");
        long finalTime = System.currentTimeMillis() - start;
        System.out.println("Wait for email with Advice Id " + adviceId + " and forward it to counterparty (" + finalTime + "ms)");
    }


    @Step("Wait for email for task with Advice Id {0} and generate EML file in destination folder")
    public void getEmailAndCreateEML(String adviceId) throws IOException, InterruptedException {
        long start = System.currentTimeMillis();
        String timestamp = DateTimeFormatter.ofPattern("yyMMddkkmmssSSS").format(LocalDateTime.now());
        EWSMail mail = new EWSMail();
        String[] cred = emailCredentials.getData().split(",");
        mail.setCredentials(cred[0], cred[1]);
        FindItemsResults<Item> mailItems = mail.waitForEmailWithSubject(adviceId);
        Assertions.assertThat(mailItems.getTotalCount()).withFailMessage("No email was reseived!").isGreaterThan(0);
        byte[] eml = mail.getEmailAsEml(mailItems.getItems().get(0));
        EnvironmentsSetup.User usr = TestContext.getTestProperties().getTestEnvironment().getUser("ssh");
        String sshServer = baseUrl.getData();
        sshServer = sshServer.substring(sshServer.indexOf(":") + 3, sshServer.lastIndexOf(":"));
        RatesSCP scp = new RatesSCP(sshServer, usr.getUserName(), usr.getPassword());
        scp.transferFile(eml,timestamp + ".eml", emlDestinationFolder.getData() );
        long finalTime = System.currentTimeMillis() - start;
        System.out.println("Wait for email for task with Advice Id " + adviceId + " and generate EML file in destination folder (" + finalTime + "ms)");
    }


    @Step("Wait for trade with Advice Id {0} to appear in Review Returned basket")
    public RatesTask waitForTradeInReviewReturned(String adviceId) throws IOException, InterruptedException {
        long start = System.currentTimeMillis();
        RatesTask task = new RatesTask().waitForTask(getSession(user2), "18", adviceId, null);
        long finalTime = System.currentTimeMillis() - start;
        Assertions.assertThat(task).withFailMessage("Transfer was failed for task with Advice Id " + adviceId + " after " + finalTime).isNotNull();
        System.out.println("Waiting for trade " + adviceId + " to appear in Review Returned (" + finalTime + "ms)");
        return task;
    }

    public RatesTask moveFromRviewReturnedToReview2Incoming(RatesTask rTask) throws IOException, InterruptedException {
        String testName = "Trade <id> forwarded from Review Returned to Review2 Incoming";
        return moveTask(testName, rTask, user2, "review2Incoming", true, user2, "19", null, expectedResult7);
    }

    public RatesTask moveOutTradeFromAllBaskets(RatesTask rTask) throws IOException, InterruptedException {
        String testName = "Trade <id> is done";
        return moveTask(testName, rTask, user1, "Document OK - Done", true, user2, "", null, expectedResult8);
    }

//    public RatesTask getTaskByAdviceId(String basketId, String adviceId) throws IOException, InterruptedException {
//        return RatesTask.waitForTask(getSession(user1), basketId, adviceId);
//    }
}
