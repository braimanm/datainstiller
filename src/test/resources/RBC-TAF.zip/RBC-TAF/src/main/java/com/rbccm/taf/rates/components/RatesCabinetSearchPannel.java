package com.rbccm.taf.rates.components;

import org.openqa.selenium.By;
import ui.auto.core.pagecomponent.PageComponentNoDefaultAction;

public class RatesCabinetSearchPannel extends PageComponentNoDefaultAction {

    @Override
    protected void init() {}

    @Override
    public void setValue() {
       setValue(getData());
    }

    public void setValue(String searchValue) {
        String[] searches = searchValue.split(",");
        for (String search : searches) {
            String[] searchParts = search.trim().split(":");
            By by = By.xpath(".//span[.='" + searchParts[0].trim() + "']/../..//input");
            coreElement.findElement(by).sendKeys(searchParts[1].trim());
        }

    }

}
