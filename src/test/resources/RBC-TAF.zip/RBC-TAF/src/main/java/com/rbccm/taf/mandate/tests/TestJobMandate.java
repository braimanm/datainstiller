package com.rbccm.taf.mandate.tests;

import com.rbccm.taf.mandate.domainobjects.MandateWorkflowDOM;
import com.rbccm.taf.mandate.pageobjects.MandateDashboardPOM;
import com.rbccm.taf.mandate.pageobjects.MandateFormPOM;
import com.rbccm.taf.ui.testng.Retry;
import com.rbccm.taf.ui.testng.TestNGBase;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.Description;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.Stories;
import ru.yandex.qatools.allure.model.SeverityLevel;

public class TestJobMandate extends TestNGBase {

    @Parameters("job-data-set")
    @Description("Test for validating general application behaviour")
    @Features("Mandate Test")
    @Stories("Validate job mandate creation workflow")
    @Severity(SeverityLevel.CRITICAL)
    @Test
    @Retry
    public void testManagersMandate(@Optional("data/mandate/mandate-job-workflow-data.xml") String dataSet)  {
        MandateWorkflowDOM mandateWorkflowDOM = new MandateWorkflowDOM(getContext()).fromResource(dataSet);
        MandateDashboardPOM dashboard = mandateWorkflowDOM.login();
        dashboard.createMandateForManager();
        MandateFormPOM mandateForm = mandateWorkflowDOM.getMandateFormPOM();
        mandateForm.validateFormInitialValues();
        mandateForm.createManagersMandate();
        mandateWorkflowDOM.navigateToDashboard();
        mandateForm.deleteJobMandate();
    }
}
