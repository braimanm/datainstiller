package com.rbccm.taf.rlm.domainobjects;

import com.rbccm.taf.rlm.pageobjects.RLMAuditTrailPOM;
import com.rbccm.taf.rlm.pageobjects.RLMLoginPOM;
import com.rbccm.taf.rlm.pageobjects.RLMRequestFormPOM;
import com.rbccm.taf.ui.support.DomainObjectModel;
import com.rbccm.taf.ui.support.TestContext;
import com.thoughtworks.xstream.annotations.XStreamAlias;

import java.util.List;


@XStreamAlias("create-request-full-cycle-dom")
public class RLMCreateRequestFullCycleDOM extends DomainObjectModel {
    private List<RLMLoginPOM> loginCredentials;
    private RLMRequestFormPOM requestFormPOM;
    private RLMAuditTrailPOM auditTrailPom;

    public RLMCreateRequestFullCycleDOM(){}
    public RLMCreateRequestFullCycleDOM(TestContext context) {
        initPage(context);
    }

    public RLMLoginPOM getLoginPOM(int index) {
        loginCredentials.get(index).initPage(getContext());
        return loginCredentials.get(index);
    }

    public RLMRequestFormPOM getRequestFormPOM() {
        requestFormPOM.initPage(getContext());
        return requestFormPOM;
    }

    public RLMAuditTrailPOM getAuditTrailPom() {
        auditTrailPom.initPage(getContext());
        return auditTrailPom;
    }

}
