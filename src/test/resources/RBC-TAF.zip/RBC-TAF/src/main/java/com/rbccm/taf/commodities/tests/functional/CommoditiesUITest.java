package com.rbccm.taf.commodities.tests.functional;

import com.rbccm.taf.commodities.components.CommoditiesBasket;
import com.rbccm.taf.commodities.components.CommoditiesTaskEntry;
import com.rbccm.taf.commodities.domainobjects.CommoditiesDOM;
import com.rbccm.taf.commodities.domainobjects.CommoditiesStep;
import com.rbccm.taf.commodities.pageobjects.CommoditiesActiFlowPOM;
import com.rbccm.taf.ui.testng.TestNGBase;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import java.io.IOException;


public class CommoditiesUITest extends TestNGBase {

    @Parameters({"data-set"})
    @Test

    public void functionalSteps(@Optional("data/commodities/functional/MultipleReview/TC003_Verify_maker_checker_functionality_after_trade_undergone_review_by_trader.xml") String dataSet) throws IOException,InterruptedException{

   
       CommoditiesDOM comm = new CommoditiesDOM(dataSet);

        String adviceId = comm.uploadGeneratedFeedFiles();

        for (CommoditiesStep step : comm.getfunctionalSteps()) {
            step.login(getContext());
            CommoditiesActiFlowPOM actiFlow = step.getActiFlow(getContext());
            actiFlow.selectBasket();
            CommoditiesTaskEntry task = actiFlow.getTaskByAdviceId(adviceId);
            task.validateActions();
            task.doAction();
            CommoditiesBasket sourceBasket = actiFlow.getSourceBasket();
            CommoditiesBasket destBasket = actiFlow.getDestinationBasket();
            if (destBasket != null && destBasket.equals(CommoditiesBasket.OutstandingConfirmations) && sourceBasket.equals(CommoditiesBasket.ReleaseDelay)) {
                step.waitForTaskInBasket(adviceId, actiFlow.getDestinationBasket());
            }
            actiFlow.validateTaskMigration(adviceId);
        }
    }

}
