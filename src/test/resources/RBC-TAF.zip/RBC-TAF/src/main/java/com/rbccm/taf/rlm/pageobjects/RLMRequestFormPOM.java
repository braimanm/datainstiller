package com.rbccm.taf.rlm.pageobjects;

import com.rbccm.taf.mail.EWSMail;
import com.rbccm.taf.rlm.components.RLMCheckBox;
import com.rbccm.taf.ui.support.*;
import com.rbccm.taf.ui.utils.Helper;
import datainstiller.data.Data;
import microsoft.exchange.webservices.data.core.service.item.Item;
import org.openqa.selenium.support.FindBy;
import ru.yandex.qatools.allure.annotations.Step;
import ui.auto.core.components.WebComponent;
import ui.auto.core.context.PageComponentContext;
import ui.auto.core.pagecomponent.PageComponent;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

@SuppressWarnings("unused")
public class RLMRequestFormPOM extends RLMMainPOM {
    @Data(skip = true)
    @FindBy(css = "a#title-tab1")
    private WebComponent generalInfoTab;
    @Data(skip = true)
    @FindBy(css = "a#title-tab2")
    private WebComponent fidessaTab;
    @Data(skip = true)
    @FindBy(css = "a#title-tab4")
    private WebComponent nextgenTab;
    @Data(skip = true)
    @FindBy(css = "a#title-tab5")
    private WebComponent thorTab;
    @Data(skip = true)
    @FindBy(css = "a#title-tab7")
    private WebComponent cadEtfTab;
    @Data(skip = true)
    @FindBy(css = "a#title-tab8")
    private WebComponent titanTab;
    @Data(skip = true)
    @FindBy(css = "a#title-tab6")
    private WebComponent portwareTab;
    @Data(skip = true)
    @FindBy(xpath = "//button[contains(.,'Complete')]")
    private WebComponent completeButton;
    @Data(skip = true)
    @FindBy(css = ".label-status")
    private WebComponent requestStatus;
    @Data(skip = true)
    @FindBy(css = ".alert-success")
    private WebComponent pendingRequestsLoadStatus;

    @Data(skip = true)
    @FindBy(css = "input#requeststatus")
    private WebComponent requeststatus;

    @Data(skip = true)
    @FindBy(xpath = "//i[.=\"refresh\"]/..")
    private WebComponent refresh;

    private GeneralIfoPOM generalInfo;
    private RLMFidessaFormPOM fidessaForm;
    private RLMNextGenFormPOM nextGenForm;
    private RLMThorFormPOM thorForm;
    private RLMCadEtfFormPOM cadEtfForm;
    private RLMTitanFormPOM titanForm;
    private RLMPortwareFormPOM portwareForm;
    private ApproverPOM approverForm;
    private ImplementorPOM implementorForm;

    @Override
    public <T extends PageComponentContext> void initPage(T context) {
        super.initPage(context);
        generalInfo.initPage(context);
    }

    @Step("Select required Trading Systems")
    public void selectTradingSystems() {
        generalInfo.selectTradingSystems();
        Helper.waitForXHR();
    }

    @Step("Validate that \"{1}\" TAB is present")
    private void validateGivenTradingSystemTabIsDispalyed(PageComponent component, String tradingSystemName) {
        assertThat(Helper.isDispalyed(component)).describedAs(tradingSystemName + " TAB should be visible").isTrue();
    }

    @Step("Validate that all the selected Trading System Tabs are displayed")
    public void valiadteSelectedTradingSystemsTabs() {
        if (generalInfo.fidessa.getData() != null && generalInfo.fidessa.getData().toLowerCase().equals("true")) {
            validateGivenTradingSystemTabIsDispalyed(fidessaTab, "FIDESSA");
        }
        if (generalInfo.next_gen.getData() != null && generalInfo.next_gen.getData().toLowerCase().equals("true")) {
            validateGivenTradingSystemTabIsDispalyed(nextgenTab, "NEXT GEN");
        }
        if (generalInfo.thor.getData() != null && generalInfo.thor.getData().toLowerCase().equals("true")) {
            validateGivenTradingSystemTabIsDispalyed(thorTab, "THOR");
        }
        if (generalInfo.cad_etf.getData() != null && generalInfo.cad_etf.getData().toLowerCase().equals("true")) {
            validateGivenTradingSystemTabIsDispalyed(cadEtfTab, "CAD ETF");
        }
        if (generalInfo.titan.getData() != null && generalInfo.titan.getData().toLowerCase().equals("true")) {
            validateGivenTradingSystemTabIsDispalyed(titanTab, "TITAN");
        }
        if (generalInfo.portware.getData() != null && generalInfo.portware.getData().toLowerCase().equals("true")) {
            validateGivenTradingSystemTabIsDispalyed(portwareTab, "PORTWARE");
        }
        Helper.sleep(500);
    }

    private boolean isFidessaIncluded() {
        return fidessaForm != null && generalInfo.fidessa.getData().toLowerCase().equals("true");
    }

    private boolean isNextGenIncluded() {
        return nextGenForm != null && generalInfo.next_gen.getData().toLowerCase().equals("true");
    }

    private boolean isThorIncluded() {
        return thorForm != null && generalInfo.thor.getData().toLowerCase().equals("true");
    }

    private boolean isCadEtfIncluded() {
        return cadEtfForm != null && generalInfo.cad_etf.getData().toLowerCase().equals("true");
    }

    private boolean isTitanIncluded() {
        return titanForm != null && generalInfo.titan.getData().toLowerCase().equals("true");
    }

    private boolean isPortwareIncluded() {
        return portwareForm != null && generalInfo.portware.getData().toLowerCase().equals("true");
    }

    public void populateTradingSystemsRequestForms() {
        if (isFidessaIncluded()) {
            fidessaTab.click();
            fidessaForm.initPage(getContext());
            fidessaForm.validateInitialValues();
            fidessaForm.fill();
        }
        if (isNextGenIncluded()) {
            nextgenTab.click();
            nextGenForm.initPage(getContext());
            nextGenForm.fill();
        }
        if (isThorIncluded()) {
            thorTab.click();
            thorForm.initPage(getContext());
            thorForm.fill();
        }
        if (isCadEtfIncluded()) {
            cadEtfTab.click();
            cadEtfForm.initPage(getContext());
            cadEtfForm.fill();
        }
        if (isTitanIncluded()) {
            titanTab.click();
            titanForm.initPage(getContext());
            titanForm.fill();
        }
        if (isPortwareIncluded()) {
            portwareTab.click();
            portwareForm.initPage(getContext());
            portwareForm.fill();
        }
    }

    public void validateTradingSystemsRequestForms() {
        if (isFidessaIncluded()) {
            fidessaForm.initPage(getContext());
            fidessaForm.validate();
        }
        if (isNextGenIncluded()) {
            nextGenForm.initPage(getContext());
            nextGenForm.validate();
        }
        if (isThorIncluded()) {
            thorForm.initPage(getContext());
            thorForm.validate();
        }
        if (isCadEtfIncluded()) {
            cadEtfForm.initPage(getContext());
            cadEtfForm.validate();
        }
        if (isTitanIncluded()) {
            titanForm.initPage(getContext());
            titanForm.validate();
        }
        if (isPortwareIncluded()) {
            portwareForm.initPage(getContext());
            portwareForm.validate();
        }
        generalInfo.validate();
    }

    @Step("Submit and validate request is being processed")
    public void completeAndValidateResponse() {
        completeButton.click();
        validateRequestSubmition("Request is completed successfully");
        waitForUrl("/rlm-dashboard");
        String[] currentDateAndTime = new SimpleDateFormat("yyyy-MM-dd/h:mm a").format(new Date()).split("/");
        TestContext.getGlobalAliases().put("requestor-submit-date",currentDateAndTime[0]);
        TestContext.getGlobalAliases().put("requestor-submit-time",currentDateAndTime[1]);
    }

    public String approveOrReject() {
        approverForm.initPage(getContext());
        String action = approverForm.action.getData().toLowerCase().trim();
        if (action.equals("reject")) {
            approverForm.rejectAndValidateResponse();
        } else {
            approverForm.approveAndValidateResponse();
        }
        Helper.waitForXHR();
        String[] currentDateAndTime = new SimpleDateFormat("yyyy-MM-dd/h:mm a").format(new Date()).split("/");
        TestContext.getGlobalAliases().put("approver-submit-date",currentDateAndTime[0]);
        TestContext.getGlobalAliases().put("approver-submit-time",currentDateAndTime[1]);
        return action;
    }

    public String approveOrRejectUsingEmail(String role) {
        EnvironmentsSetup.User user = TestContext.getTestProperties().getTestEnvironment().getUser(role);
        EWSMail ewsMail = new EWSMail();
        ewsMail.setCredentials(user.getUserName(), user.getPassword());
        String action = approverForm.action.getData().toLowerCase();
        sendActionByEmail(action, ewsMail);
        String[] currentDateAndTime = new SimpleDateFormat("yyyy-MM-dd/h:mm a").format(new Date()).split("/");
        TestContext.getGlobalAliases().put("approver-submit-date",currentDateAndTime[0]);
        TestContext.getGlobalAliases().put("approver-submit-time",currentDateAndTime[1]);
        return action;
    }

    @Step("Validate Auto-Approved Email in {0} email-box")
    public void valiadateAutoApprovedEmail(String role) {
        EnvironmentsSetup.User user = TestContext.getTestProperties().getTestEnvironment().getUser(role);
        EWSMail ewsMail = new EWSMail();
        ewsMail.setCredentials(user.getUserName(), user.getPassword());
        String action = "approve";
        String[] currentDateAndTime = new SimpleDateFormat("yyyy-MM-dd/h:mm a").format(new Date()).split("/");
        TestContext.getGlobalAliases().put("approver-submit-date",currentDateAndTime[0]);
        TestContext.getGlobalAliases().put("approver-submit-time",currentDateAndTime[1]);
        String requestId = TestContext.getGlobalAliases().get("request-id");
        List<Item> items = ewsMail.waitForEmailWithSubject("Request ID# " + requestId).getItems();
        assertThat(items).isNotEmpty().withFailMessage("No email was received for request id " + requestId);
        Item item = items.get(0);
        try {
            String subjectPhrase = null;
            String bodyPhrase = null;
            if (role.equals("requestor") || role.equals("trade support")) {
                subjectPhrase = "Notification";
                bodyPhrase = "The following request has been received. " +
                        "If the request requires approval, it is awaiting approval/rejection " +
                        "upon which the implementation process will begin. " +
                        "For all other requests, the request is pending implementation.";
            }
            if (role.equals("approver")) {
                subjectPhrase = "Auto-Approved";
                bodyPhrase = "The following request has been received and is awaiting implementation.";
            }
            if (items.size()>1) {
                for (Item it : items) {
                    if (it.getSubject().contains(subjectPhrase)) {
                        item = it;
                        break;
                    }
                }
            }
            assertThat(item.getSubject()).contains(subjectPhrase);
            assertThat(item.getBody().toString()).contains(bodyPhrase);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Step("{0} request using email ")
    private void sendActionByEmail(String action,  EWSMail ewsMail ) {
        String comments = approverForm.comments.getData();
        String requestId = TestContext.getGlobalAliases().get("request-id");
        if (action.equals("reject")) {
            ewsMail.waitforEmailAndReject(requestId, comments);
        } else {
            ewsMail.waitforEmailAndApprove(requestId, comments);
        }
    }

    public String implement() {
        implementorForm.initPage(getContext());
        String action = implementorForm.action.getData();
        if (action != null) {
            action =  action.trim().toLowerCase();
        } else {
            action = "";
        }
        if ( action.equals("cancel")) {
            implementorForm.cancellAndValidateResponse();
        } else {
            implementorForm.implementAndValidateResponse();
        }
        String[] currentDateAndTime = new SimpleDateFormat("yyyy-MM-dd/h:mm a").format(new Date()).split("/");
        TestContext.getGlobalAliases().put("implementor-submit-date",currentDateAndTime[0]);
        TestContext.getGlobalAliases().put("implementor-submit-time",currentDateAndTime[1]);
        return action;
    }

    public void waitForStatusToChange() {
        String status = "approved";
        long timeOut = TestContext.getTestProperties().getEmailTimeout();
        if (approverForm.action.getData().toLowerCase().equals("reject")) {
            status = "rejected";
        }
        long t_o = System.currentTimeMillis() + timeOut * 1000;
        do {
            refresh.click();
            Helper.waitForXHR();
            if (requeststatus.getValue().toLowerCase().equals(status)) {
                return;
            }
        } while (System.currentTimeMillis()<t_o);
        throw new RuntimeException("Request does not have a status of " + status + " after " + timeOut + " seconds");
    }


    private static class GeneralIfoPOM extends PageObjectModel {
        @FindBy(css = "checkbox-widget>label[for=fidessa]")
        private RLMCheckBox fidessa;
        @FindBy(css = "checkbox-widget>label[for=nextgen]")
        private RLMCheckBox next_gen;
        @FindBy(css = "checkbox-widget>label[for=thor]")
        private RLMCheckBox thor;
        @FindBy(css = "checkbox-widget>label[for=cadetf]")
        private RLMCheckBox cad_etf;
        @FindBy(css = "checkbox-widget>label[for=titan]")
        private RLMCheckBox titan;
        @FindBy(css = "checkbox-widget>label[for=portware]")
        private RLMCheckBox portware;
        @FindBy(css = "input#effectivedate")
        private WebComponent effectiveDate;
        @FindBy(css = "textarea#requestercomments")
        private WebComponent comments;

        //Fields For form Validation
        @Data(skip = true)
        @FindBy(xpath = "//span[.='Requester Comments:']/../../../../../../div[2]//span")
        private  WebComponent valComments;

        public void validate() {
            validateComponentValue(valComments, comments.getData(), "Requester Comments:");
            validateComponentValue(effectiveDate, effectiveDate.getData(), "Effective Date");
        }

        @Step("Validating field \"{2}\" has a value of \"{1}\"")
        private void validateComponentValue(PageComponent component, String data, String field) {
            if (data != null && !data.isEmpty()) {
                assertThat(component.getValue()).isEqualToIgnoringCase(data);
            }
        }

        void selectTradingSystems() {
            autoFillPage();
        }


    }

    private static class ApproverPOM extends RLMMainPOM {
        @FindBy(id = "approvercomments")
        private WebComponent comments;
        @Data(skip = true)
        @FindBy(xpath = "//button[contains(.,'Approve')]")
        private WebComponent approveButton;
        @Data(skip = true)
        @FindBy(xpath = "//button[contains(.,'Reject')]")
        private WebComponent rejectButton;
        AliasedString action;

        @Step("Reject Request and Validate Response")
        private void rejectAndValidateResponse() {
            setElementValue(comments);
            rejectButton.click();
            validateRequestSubmition("Request is rejected successfully");
            waitForUrl("/rlm-dashboard");
        }

        @Step("Approve Request and Validate Response")
        private void approveAndValidateResponse() {
            setElementValue(comments);
            approveButton.click();
            validateRequestSubmition("Request is approved successfully");
            waitForUrl("/rlm-dashboard");
        }
    }

    private static class ImplementorPOM extends RLMMainPOM {
        AliasedString action;
        @FindBy(css = "checkbox-widget>label[for='fidessaimplemented']")
        RLMCheckBox fidessaImplemented;
        @FindBy(css = "checkbox-widget>label[for='nextgenimplemented']")
        RLMCheckBox nextgenimplemented;
        @FindBy(css = "checkbox-widget>label[for='thorimplemented']")
        RLMCheckBox thorImplemented;
        @FindBy(css = "checkbox-widget>label[for='cadetfimplemented']")
        RLMCheckBox cadEtfImplemented;
        @FindBy(css = "checkbox-widget>label[for='titanimplemented']")
        RLMCheckBox titanImplemented;
        @FindBy(css = "checkbox-widget>label[for='portwareimplemented']")
        RLMCheckBox portwareImplemented;
        @FindBy(id = "implementorcomments")
        private WebComponent comments;
        @Data(skip = true)
        @FindBy(xpath = "//button[contains(.,'Implemented')]")
        private WebComponent implementedButton;
        @Data(skip = true)
        @FindBy(id = "Cancel")
        private WebComponent cancelButton;


        @Step("Implement Request and Validate Response")
        private void implementAndValidateResponse() {
            setToImplemented(fidessaImplemented);
            setToImplemented(nextgenimplemented);
            setToImplemented(thorImplemented);
            setToImplemented(cadEtfImplemented);
            setToImplemented(titanImplemented);
            setToImplemented(portwareImplemented);
            setElementValue(comments);
            implementedButton.click();
            validateRequestSubmition("Request is implemented successfully");
            waitForUrl("/rlm-dashboard");
        }

        @Step("Cancel Request and Validate Response")
        private void cancellAndValidateResponse() {
            cancelButton.click();
            validateRequestSubmition("Request is cancelled successfully");
            waitForUrl("/rlm-dashboard");
        }

        private void setToImplemented(RLMCheckBox checkbox) {
            if (checkbox.getData() != null && checkbox.getData().toLowerCase().equals("true")) {
                checkbox.setValue();
            }
        }

    }

}