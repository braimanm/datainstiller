package com.rbccm.taf.commodities.tests.functional;

import com.rbccm.taf.commodities.components.CommoditiesDocumentEntry;
import com.rbccm.taf.commodities.components.CommoditiesDocumentProperty;
import com.rbccm.taf.commodities.components.CommoditiesTaskEntry;
import com.rbccm.taf.commodities.domainobjects.CommoditiesNoStepsDOM;
import com.rbccm.taf.commodities.pageobjects.CommoditiesActiFlowPOM;
import com.rbccm.taf.commodities.pageobjects.CommoditiesFileCabinetPOM;
import com.rbccm.taf.commodities.pageobjects.CommoditiesLoginPOM;
import com.rbccm.taf.rates.components.RatesDocumentEntry;
import com.rbccm.taf.rates.components.RatesDocumentProperty;
import com.rbccm.taf.rates.components.RatesTaskEntry;
import com.rbccm.taf.rates.domainobjects.RatesNoStepsDOM;
import com.rbccm.taf.rates.pageobjects.RatesActiFlowPOM;
import com.rbccm.taf.rates.pageobjects.RatesFileCabinetPOM;
import com.rbccm.taf.rates.pageobjects.RatesLoginPOM;
import com.rbccm.taf.ui.testng.TestNGBase;
import org.assertj.core.api.Assertions;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.Description;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

import java.io.IOException;

@Features("ReveiwII Amendment watch flow")
@Stories("Amendment watch flow when old trade ReviewII basket and New trade inserted in ReviewI basket")
@Description("Trade1 inserted in ReviewI -->Trade1 forwarded to ReviewII-->Trade2 inserted in ReviewI-->StatusCode verify in FileCabinet")
public class CommoditiesAmendmentReviewIIUITest extends TestNGBase {
    private String adviceId;

    @Parameters({"data-set1"})
    @Test
    public void tc001_01(@Optional("data/commodities/functional/Amendment/TC003_Amendment_Watch_Verify_amendment_watch_when_original_trade_in_ReviewII_basket_Vanilla/TC001_01.xml") String dataSet) throws IOException, InterruptedException {
        CommoditiesNoStepsDOM comm = new CommoditiesNoStepsDOM(dataSet);
        adviceId = comm.uploadGeneratedFeedFiles();

        CommoditiesLoginPOM login = comm.getLoginPOM(getContext());
        login.login();

        CommoditiesActiFlowPOM actiFlow = comm.getActiFlowPOM();

        actiFlow.selectBasket();

        CommoditiesTaskEntry task = actiFlow.getTaskByAdviceId(adviceId);
        task.validateActions();
        task.doAction();
        actiFlow.validateTaskRemoval(adviceId);
        actiFlow.validateTaskMigration(adviceId);
        CommoditiesFileCabinetPOM fileCabinetPOM = actiFlow.getFileCabinetPOM();
        fileCabinetPOM.searchForDocument("Advice ID :" + adviceId);
        CommoditiesDocumentEntry documentEntry = fileCabinetPOM.getDocument(0);
        Assertions.assertThat(documentEntry.getProperty(CommoditiesDocumentProperty.StatusCode)).isEqualTo("NEW");
    }

    @Parameters({"data-set2"})
    @Test(dependsOnMethods = "tc001_01")
    public void tc001_02(@Optional("data/commodities/functional/Amendment/TC003_Amendment_Watch_Verify_amendment_watch_when_original_trade_in_ReviewII_basket_Vanilla/TC001_02.xml") String dataSet) throws IOException, InterruptedException {
        CommoditiesNoStepsDOM comm = new CommoditiesNoStepsDOM(dataSet);
        adviceId = comm.uploadGeneratedFeedFiles();

        CommoditiesLoginPOM login = comm.getLoginPOM(getContext());
        login.login();

        CommoditiesActiFlowPOM actiFlow = comm.getActiFlowPOM();

        actiFlow.selectBasket();

        CommoditiesTaskEntry task = actiFlow.getTaskByAdviceId(adviceId);
        task.validateActions();
    }
}
