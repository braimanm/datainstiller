package com.rbc.winauto;


import mmarquee.automation.AutomationException;
import mmarquee.automation.AutomationTreeWalker;
import mmarquee.automation.ControlType;
import mmarquee.automation.UIAutomation;
import mmarquee.automation.controls.AutomationBase;
import mmarquee.automation.pattern.PatternNotFoundException;
import mmarquee.automation.uiautomation.IUIAutomationElement;
import org.testng.annotations.Test;
import org.xml.sax.InputSource;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathFactory;
import java.io.StringReader;
import java.util.List;


public class TestWinAuto {


    StringBuilder xml = new StringBuilder();
    int currentNode = 0;

    private String getIndent() {
        String ind="";
        for (int i=0; i<currentNode; i++) {
            ind += "   ";
        }
        return ind;
    }


    private String getNodeProperty(AutomationBase node) throws AutomationException {
        return getNodeProperty(node, false);
    }
    private String getNodeProperty(AutomationBase node, boolean close) throws AutomationException {
        String ret = ControlType.fromValue(node.getElement().getControlType()).toString();
        if (!close) {
            ret += " name=\"" + node.getName() + "\"";
        }
        return ret;
    }

    private void startNode(AutomationBase node) throws AutomationException {
        currentNode ++;
        xml.append(getIndent() + "<" + getNodeProperty(node) + ">\n");
    }

    private void endNode (AutomationBase node) throws AutomationException {
        xml.append(getIndent() + "</" + getNodeProperty(node, true) + ">\n");
        currentNode --;
    }

    private void listChildren(AutomationBase control) throws PatternNotFoundException, AutomationException {
        startNode(control);
        List<AutomationBase> children = control.getChildren(false);
        if (!children.isEmpty()) {
            for (AutomationBase child: children) {
                startNode(child);
                listChildren(child);
                endNode(child);
            }
        }
        endNode(control);
    }


    @Test
    public void sss() throws Exception {
        long time = System.currentTimeMillis();
        UIAutomation auto = UIAutomation.getInstance();
        listChildren(auto.getDesktop());
        System.out.println("TIME: " + (System.currentTimeMillis() - time));
        System.out.println(xml.toString());

        String xml2 = "<car><manufacturer name=\"popo\">toyota</manufacturer></car>";
        String xpath = "//manufacturer[@name='popo']";
        XPath xPath = XPathFactory.newInstance().newXPath();
        System.out.println(xPath.evaluate(xpath, new InputSource(new StringReader(xml2))));

    }

    @Test
    public void ttt() throws AutomationException {
        long time = System.currentTimeMillis();
        UIAutomation auto = UIAutomation.getInstance();
        AutomationTreeWalker tree = auto.getControlViewWalker();
        System.out.println("TIME: " + (System.currentTimeMillis() - time));
    }


}
