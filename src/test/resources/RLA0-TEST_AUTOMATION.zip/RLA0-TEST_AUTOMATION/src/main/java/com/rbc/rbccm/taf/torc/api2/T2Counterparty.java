package com.rbc.rbccm.taf.torc.api2;

import com.rbc.rbccm.taf.torc.api.TORCGenericRequest;
import com.rbc.rbccm.taf.torc.api.TORCSession;
import ru.yandex.qatools.allure.annotations.Step;

import java.io.IOException;

public class T2Counterparty extends T2Entity {

    private static final String payloadForCreate = "{ " +
            "  \"sourceSystem\": \"TORC\", " +
            "  \"clientPermissionContactFlag\": true, " +
            "  \"isda871m\": { " +
            "    \"adherenceProtocolStatus\": \"No_Adherence\", " +
            "    \"adherenceType\": \"Not_Applicable\", " +
            "    \"effectiveAdherenceDate\": null, " +
            "    \"effectiveRevokeDate\": null " +
            "  }, " +
            "  \"isdaFatca\": { " +
            "    \"adherenceProtocolStatus\": \"No_Adherence\", " +
            "    \"adherenceType\": \"Not_Applicable\" " +
            "  }, " +
            "  \"clientContact\": { " +
            "    \"contacts\": [ " +
            "      { " +
            "        \"verifiedContact\": false, " +
            "        \"contactInformation\": { " +
            "          \"email\": \"${EMAIL}\", " +
            "          \"contactInfoType\": \"CLIENT\" " +
            "        }, " +
            "        \"verified\": false, " +
            "        \"modified\": true " +
            "      } " +
            "    ] " +
            "  }, " +
            "  \"sensitiveClientFlag\": false, " +
            "  \"clientRelationshipType\": \"ENTITY\", " +
            "  \"legalName\": \"${LEGAL-NAME}\", " +
            "  \"clientContPermFlag\": 0 " +
            "}";

    private T2Counterparty(String json) {
        super(json);
    }

    @Step("Create Counterparty for Legal Name: \"{1}\"")
    public static T2Counterparty create(TORCSession session, String legalName, String email) throws IOException {
        String payload = payloadForCreate.replace("${LEGAL-NAME}", legalName).replace("${EMAIL}", email);
        TORCGenericRequest request = TORCGenericRequest.genericPost(session,"/api/clients/", payload);
        return new T2Counterparty(request.getJson());
    }

    public String getId() {
        return getProperty("$.id");
    }



}
