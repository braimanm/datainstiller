package com.rbc.rbccm.taf.torc.tests;

import com.rbc.rbccm.taf.torc.api.TORCSession;
import com.rbccm.taf.ui.support.EnvironmentsSetup;

@SuppressWarnings("ALL")
public class TORCTestUsers  {

    public static void main(String[] args) {
        int err = validateEnv("any");
        err =+ validateEnv("perf");
        System.exit(err);
    }

    private static int validateEnv(String envName) {
        String urlBase = "http://mrkdlvaiaas926.devfg.rbc.com:8080";
        EnvironmentsSetup setup = new EnvironmentsSetup().fromResource("data/torc/environments.xml");
        EnvironmentsSetup.Environment env = setup.getEnvironment(envName);
        int errors = 0;
        for (EnvironmentsSetup.User user : env.getUsers()) {
            System.out.println("VALIDATING USER " + user.getUserName());
            try {
                new TORCSession(urlBase, user.getUserName(), user.getPassword());
            } catch (Exception e) {
                errors ++;
                System.out.println("\u001b[41m\u001b[97;1m" + user.getUserName() + " " + e.getMessage() + "\u001b[0m");
            }
        }
        return errors;
    }

}
