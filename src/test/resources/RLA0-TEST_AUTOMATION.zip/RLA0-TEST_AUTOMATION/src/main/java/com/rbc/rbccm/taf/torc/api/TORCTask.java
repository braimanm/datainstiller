package com.rbc.rbccm.taf.torc.api;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.jsoup.Connection;

import java.io.IOException;

public class TORCTask  {
    public String id;
    public String taskType;
    public String title;
    public String description;
    public String clientId;
    public String agreementId;
    public String taskStatus;
    public String managedFundId;


    private static TORCTask[] getEntity(Connection con) throws IOException {
        Connection.Response res = con.execute();
        String bodyText = res.parse().body().text();
        if (bodyText.contains("Login with Username and Password User: Password:")) {
            throw new RuntimeException("Invalid token. Please login again!");
        }
        ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        TORCDataWrapper<TORCTask> clients = mapper.readValue(bodyText, new TypeReference<TORCDataWrapper<TORCTask>>(){});
        return clients.data;
    }


    public static TORCTask[] search(TORCSession session, String clientId, String agreementId) throws IOException {
        Connection con = session.getConnection("/api/tasksearch");
        con.method(Connection.Method.POST);
        con.data("take","25");
        con.data("skip","0");
        con.data("page","1");
        con.data("pageSize","25");
        con.data("sort[0][field]","taskId");
        con.data("sort[0][dir]", "asc");
        con.data("filter[logic]", "and");
        con.data("filter[filters][0][field]", "completeWithException");
        con.data("filter[filters][0][operator]", "eq");
        con.data("filter[filters][0][value]", "NO");
        con.data("filter[filters][1][field]", "clientId");
        con.data("filter[filters][1][operator]", "eq");
        con.data("filter[filters][1][value]", clientId);
        con.data("filter[filters][2][field]", "agreementId");
        con.data("filter[filters][2][operator]", "eq");
        con.data("filter[filters][2][value]" , agreementId);
        con.data("filter[filters][3][field]", "taskStatus");
        con.data("filter[filters][3][operator]", "eq");
        con.data("filter[filters][3][value]", "NEW");
        return getEntity(con);
    }

}
