package com.rbc.rbccm.taf.torc.tests.api;

import com.jayway.jsonpath.JsonPath;
import com.rbc.rbccm.taf.torc.api.TORCSession;
import com.rbc.rbccm.taf.torc.api2.*;
import com.rbccm.taf.ui.support.EnvironmentsSetup;
import com.rbccm.taf.ui.support.TestContext;
import com.rbccm.taf.ui.support.UserProvider;
import com.rbccm.taf.ui.testng.TestNGBase;
import datainstiller.generators.WordGenerator;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.assertj.core.api.Assertions;
import org.assertj.core.api.SoftAssertions;
import org.testng.annotations.Factory;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.Allure;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.Step;
import ru.yandex.qatools.allure.events.TestCaseEvent;
import ru.yandex.qatools.allure.model.Label;
import ru.yandex.qatools.allure.model.LabelName;
import ru.yandex.qatools.allure.model.SeverityLevel;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

public class TORC_ADP_FACT_Code_DM_Test extends TestNGBase {
    private DataFACT data;
    private String random;

    private TORC_ADP_FACT_Code_DM_Test(){}
    private TORC_ADP_FACT_Code_DM_Test(DataFACT data, String random) {
        this.data = data;
        this.random = random;
    }

    @Factory
    public Object[] test() throws IOException, InvalidFormatException {
        String random = new WordGenerator().generate("{A}{B}");
        String doc = "data/torc/api/FACT TESTING ADP Section Solution V0.10.xlsx";
        Workbook workbook = WorkbookFactory.create(this.getClass().getClassLoader().getResourceAsStream(doc));
        Sheet sheet = workbook.getSheet("FACT Code DM");
        AtomicBoolean isFirstRow = new AtomicBoolean(true);
        List<TORC_ADP_FACT_Code_DM_Test> table = new ArrayList<>();
        List<String> keys = new ArrayList<>();
        sheet.forEach(row -> {
            AtomicInteger i = new AtomicInteger();
            Map<String,String> tableRow = new HashMap<>();
            row.forEach(cell -> {
                cell.setCellType(CellType.STRING);
                String value = cell.getStringCellValue();
                if (isFirstRow.get()) {
                    value = "_" + value.replace(" ","").replace("-","_").replace("(","_").replace(")","_").toLowerCase();
                    keys.add(i.getAndIncrement(), value);
                } else {
                    tableRow.put(keys.get(i.getAndIncrement()), value);
                }
            });
            if (isFirstRow.get()) {
                isFirstRow.set(false);
            } else {
                if(tableRow.keySet().size() == keys.size()) {
                    DataFACT dataFACT = new DataFACT(tableRow);//DataFACT.create(tableRow);
                    table.add(new TORC_ADP_FACT_Code_DM_Test(dataFACT, random));
                    //////For data generation
                    //////String filePath = System.getProperty("user.dir") + "/src/main/resources/data/torc/api/adp_fact/data_" + dataFACT.get_sn0() + ".xml";
                    //////dataFACT.toFile(filePath);
                }
            }
        });
        return table.toArray();
    }

    @Features("ADP Section Solution")
    @Severity(SeverityLevel.CRITICAL)
    @Test
    public void testFACT_Code_DM() throws IOException {
        ////data = new DataFACT().fromResource("data/torc/api/adp_fact/data_1.xml");

        String currDate = DateTimeFormatter.ofPattern("dd/MM/yyyy").format(LocalDateTime.now());
        String timestamp = DateTimeFormatter.ofPattern("yyMMddkkmmss").format(LocalDateTime.now()) + Thread.currentThread().getId();

        String srNum = String.format("%03d", Integer.parseInt(data.get_sn0()));
        Allure.LIFECYCLE.fire((TestCaseEvent) context -> {
            context.getLabels().add(new Label().withName(LabelName.STORY.value())
                    .withValue("Validate ADP Section Solution for " + "FACT Code DM"));
            context.setName("FACT" + "-" + srNum);
        });

        EnvironmentsSetup.Environment env = TestContext.getTestProperties().getTestEnvironment();
        String urlBase = (System.getenv().containsKey("TORC_URL")) ? System.getenv("TORC_URL") : env.getUrl();
        EnvironmentsSetup.User user = UserProvider.getInstance().getUser("user");
        TORCSession session = new TORCSession(urlBase, user.getUserName(), user.getPassword());
        T2Counterparty counterparty = T2Counterparty.create(session, "FACT_" + random + "_" + srNum  + "_" + timestamp, "autotest@yahoo.com");

        T2_ADP_Agreement agreements = T2_ADP_Agreement.create(session, counterparty.getId(), agreement -> {
            agreement.set("$[0].clientBookingPoint.identifier", counterparty.getId() +"_CA");
            agreement.set("$[0].createDate", currDate);
            agreement.set("$[0].dateOpened", currDate);
            agreement.set("$[0].identifiedDate", currDate);
            agreement.set("$[0].shortCode", timestamp);
            return agreement;
        });

        T2Task task = T2Task.get(session, agreements.getTaskId());
        task = task.assignToCurrentUser(session);

        T2_Tax_Form form = T2_Tax_Form.get(session, data.get_taxform(), data.get_taxformversion());

        final T2_CH4_FATCA_Status ch4_status = T2_CH4_FATCA_Status.getFATCAStatus(session, form.getFormName(), data.get_fatcastatus());
        final T2_CH4_FATCA_Status ch4_disregardedStatus = T2_CH4_FATCA_Status.getDisregardedStatus(session, form.getFormName(), data.get_disregardedentityorbranchreceivingpayment());
        final T2_ExemptFromFatcaReporting excemptFromFatca;
        final T2_FedTaxClass fedTaxClass;

        if (!form.getFormName().equals("W9")) {
            excemptFromFatca = null;
            fedTaxClass = null;
        } else {
            excemptFromFatca = T2_ExemptFromFatcaReporting.get(session, data.get_exemptionfromfatcareportingcode());
            fedTaxClass = T2_FedTaxClass.get(session, data.get_federaltaxclassification());
        }

        T2CRV crv = T2CRV.get(session, task);
        crv = crv.execute(session, newCrv -> {
            newCrv.set("$.obligationDocumentation.W_FORM.@class", form.getFormClass());
            newCrv.set("$.obligationDocumentation.W_FORM.formType", form.getFormName());
            newCrv.put("$.obligationDocumentation.W_FORM", "formVersion", form.getId());
            newCrv.put("$.obligationDocumentation.W_FORM", "taxFormName", form.getFormName());

            newCrv.set("$.obligationDocumentation.W_FORM.ch3Complete", data.get_documentationstatusch3().contains("Complete"));
            newCrv.set("$.obligationDocumentation.W_FORM.ch4Complete", data.get_documentationstatusch4().contains("Complete"));

            Object address = JsonPath.parse("{'addressType':'PERMANENT','isMailingDifferent':false}").read("$");
            newCrv.add("$.obligationDocumentation.W_FORM.addresses", address);

            if (form.getFormName().equals("W9")) {
                String ownerType = data.get_beneficialownertype().trim().toUpperCase();
                newCrv.put("$.obligationDocumentation.W_FORM", "beneficialOwnerType", ownerType);
                newCrv.put("$.obligationDocumentation.W_FORM", "authorizedPersonFlag", false);
                newCrv.put("$.obligationDocumentation.W_FORM", "ch3Other", false);
                if (excemptFromFatca != null) {
                    newCrv.put("$.obligationDocumentation.W_FORM", "exemptFromFatcaReporting", excemptFromFatca.id);
                }
                newCrv.put("$.obligationDocumentation.W_FORM","federalTaxClassification", fedTaxClass.id);
                newCrv.put("$.obligationDocumentation.W_FORM","sin","123456789");

                return newCrv;
            }

            if (data.get_ch3standardsofknowledge().contains("Non-US Indicia")) {
                newCrv.put("$.obligationDocumentation.W_FORM.addresses[0]", "country", "AF");
                newCrv.set("$.obligationDocumentation.W_FORM.addresses[0].isMailingDifferent", true);
                Object mailing = JsonPath.parse("{'addressType':'MAILING','country':'AL'}").read("$");
                newCrv.add("$.obligationDocumentation.W_FORM.addresses", mailing);
            }

            if (ch4_status != null) {

                if (form.getFormName().equals("W8EXP")) {
                    newCrv.put("$.obligationDocumentation.W_FORM","fatcaStatus", ch4_status.id);
                } else {
                    newCrv.put("$.obligationDocumentation.W_FORM","ch4Status", ch4_status.id);
                }

            }

            if (ch4_disregardedStatus != null) {
                if (form.getFormName().equals("W8IMY")) {
                    newCrv.put("$.obligationDocumentation.W_FORM", "ch4FatcaStatus", ch4_disregardedStatus.id);
                } else {
                    newCrv.put("$.obligationDocumentation.W_FORM", "ch4StatusDisregardEntity", ch4_disregardedStatus.id);
                }
                newCrv.put("$.obligationDocumentation.W_FORM", "disregardEntityGlobalIntermediaryId", "000111.00000.AA.999");
            }

            if (!form.getFormName().equals("W8BEN")) {
                if (form.getFormName().equals("W8EXP")) {
                    newCrv.put("$.obligationDocumentation.W_FORM", "giin", "000111.00000.AA.999");
                } else {
                    newCrv.put("$.obligationDocumentation.W_FORM", "globalIntermediaryId", "000111.00000.AA.999");
                }
            }

            if (data.get_40a().contains("Yes")) {
                boolean hasnousowner = data.get_40b().contains("Yes");
                boolean usownerinfo = data.get_40c().contains("Yes");
                newCrv.put("$.obligationDocumentation.W_FORM", "isPassiveNFFECertified", true);
                newCrv.put("$.obligationDocumentation.W_FORM", "passiveNffeCerts", new HashMap<>());
                newCrv.put("$.obligationDocumentation.W_FORM.passiveNffeCerts", "HAS_NO_US_OWNER_V2", hasnousowner);
                newCrv.put("$.obligationDocumentation.W_FORM.passiveNffeCerts", "US_OWNER_INFO", usownerinfo);
            }

            boolean _37a = data.get_ben_e_37a().contains("Yes");
            boolean _37b = data.get_ben_e_37b().contains("Yes");
            if ( _37a || _37b) {
                newCrv.put("$.obligationDocumentation.W_FORM", "publicTradeFFIcerts", new HashMap<>());
                newCrv.put("$.obligationDocumentation.W_FORM.publicTradeFFIcerts", "ESTAB_SECURITY", _37a);
                newCrv.put("$.obligationDocumentation.W_FORM.publicTradeFFIcerts", "EXPANDED_AFFILIATE", _37b);
            }

            if (data.get_20a().contains("Yes")) {
                newCrv.put("$.obligationDocumentation.W_FORM", "isSec20aCheckBox", true );
            }

            if (data.get_20b().contains("Yes")) {
                newCrv.put("$.obligationDocumentation.W_FORM", "isSec20bCheckBox", true );
            }

            if (data.get_20c().contains("Yes")) {
                newCrv.put("$.obligationDocumentation.W_FORM", "isSec20cCheckBox", true );
            }

            boolean imy37a = data.get_imy_37a().contains("Yes");
            boolean imy37b = data.get_imy_37b().contains("Yes");
            if ( imy37a || imy37b) {
                newCrv.put("$.obligationDocumentation.W_FORM", "publiclyTradedNFFEAffiliatePubliclyTradedCorp", new HashMap<>());
                newCrv.put("$.obligationDocumentation.W_FORM.publiclyTradedNFFEAffiliatePubliclyTradedCorp", "PTNFFE_STOCKOF_CORPORATION", imy37a);
                newCrv.put("$.obligationDocumentation.W_FORM.publiclyTradedNFFEAffiliatePubliclyTradedCorp", "PTNFFE_MEMBER_OF_AFFILIATED_GROUP", imy37b);
            }

            boolean _35a = data.get_35a().contains("Yes");
            boolean _35b = data.get_35b().contains("Yes");
            if( _35a || _35b) {
                newCrv.put("$.obligationDocumentation.W_FORM", "publiclyTradedNFFEAffiliatePubliclyTradedCorp", new HashMap<>());
                newCrv.put("$.obligationDocumentation.W_FORM.publiclyTradedNFFEAffiliatePubliclyTradedCorp", "PTNFFE_STOCKOF_CORPORATION", _35a);
                newCrv.put("$.obligationDocumentation.W_FORM.publiclyTradedNFFEAffiliatePubliclyTradedCorp", "PTNFFE_MEMBER_OF_AFFILIATED_GROUP", _35b);
            }

            boolean _16a = data.get_16a().contains("Yes");
            boolean _16b = data.get_16b().contains("Yes");
            boolean _16c = data.get_16c().contains("Yes");
            if (_16a) {
                newCrv.put("$.obligationDocumentation.W_FORM", "territoryFinancialInstitutions", new HashMap<>());
                newCrv.put("$.obligationDocumentation.W_FORM.territoryFinancialInstitutions", "TFI_CERTIFY", true);
                newCrv.put("$.obligationDocumentation.W_FORM.territoryFinancialInstitutions", "TFI_CERTIFY_A_US_PERSON", _16b);
                newCrv.put("$.obligationDocumentation.W_FORM.territoryFinancialInstitutions", "TFI_TRANSMIT_WITHHOLDING_CERTIFICATES", _16c);
            }

            boolean _18a = data.get_18a().contains("Yes");
            boolean _18b = data.get_18b().contains("Yes");
            boolean _18c = data.get_18c().contains("Yes");
            if (_18a) {
                newCrv.put("$.obligationDocumentation.W_FORM", "territoryFinancialInstitutions", new HashMap<>());
                newCrv.put("$.obligationDocumentation.W_FORM.territoryFinancialInstitutions", "TFI_CERTIFY_V2", true);
                newCrv.put("$.obligationDocumentation.W_FORM.territoryFinancialInstitutions", "TFI_CERTIFY_A_US_PERSON", _18b);
                newCrv.put("$.obligationDocumentation.W_FORM.territoryFinancialInstitutions", "TFI_TRANSMIT_WITHHOLDING_CERTIFICATES", _18c);
            }

            newCrv.put("$.obligationDocumentation.W_FORM", "permanentAddress", new ArrayList<>());
            newCrv.put("$.obligationDocumentation.W_FORM", "mailingAddress", new ArrayList<>());
            newCrv.put("$.obligationDocumentation.W_FORM", "specialRates", new ArrayList<>());

            newCrv.delete("$.obligationDocumentation.W_FORM.sokCh3Exists");
            newCrv.delete("$.obligationDocumentation.W_FORM.sokCh4Exists");

            if (form.getFormName().equals("W8IMY")) {
                newCrv.put("$.obligationDocumentation.W_FORM", "benAddresses", new ArrayList<>());
                newCrv.put("$.obligationDocumentation.W_FORM", "uboRecords", new ArrayList<>());
                newCrv.put("$.obligationDocumentation.W_FORM", "tinTypes", new HashMap<>());
                newCrv.put("$.obligationDocumentation.W_FORM", "usIdentificationNumber", "");
                newCrv.put("$.obligationDocumentation.W_FORM", "formCompleteDisabledForGiin", false);
                newCrv.put("$.obligationDocumentation.W_FORM", "validationFlagForGiin", false);
                newCrv.delete("$.obligationDocumentation.W_FORM.specialRates");
            }


            return newCrv;
        });

        T2_ADP_FACT_CODE adpFactCode = T2_ADP_FACT_CODE.get(session, data.get_fatcaholdertypedescription());
        T2Summary summary = T2Summary.get(session, crv);
        validate(summary, adpFactCode);
        session.end();
    }


    @Step( "Validating Summary Results")
    private void validate(T2Summary summary, T2_ADP_FACT_CODE adpFactCode) {
        summary.attachToReport();
        Assertions.assertThat(summary.getProperty("$.adpSummary")).withFailMessage("The Result is Blank for " + data.get_sn0()).contains("fatcaCode");
        SoftAssertions.assertSoftly(soft -> {
            soft.assertThat(summary.getAdpFatcaCode()).as("FATCA Holder Type Description Code").isEqualTo(adpFactCode.fatcaHolderTypeDescription);
            soft.assertThat(summary.getAdpHolderType()).as("FATCA Holder Type").isEqualTo(adpFactCode.fatcaHolderType);
            soft.assertThat(summary.getAdpHolderSubType().replace("ST_", "")).as("FATCA Holder Sub Type").isEqualTo(adpFactCode.fatcaHolderSubType);
        });
    }


}
