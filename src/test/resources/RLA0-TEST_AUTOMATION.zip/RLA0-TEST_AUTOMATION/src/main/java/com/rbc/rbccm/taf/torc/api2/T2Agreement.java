package com.rbc.rbccm.taf.torc.api2;

import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.rbc.rbccm.taf.torc.api.TORCGenericRequest;
import com.rbc.rbccm.taf.torc.api.TORCSession;
import ru.yandex.qatools.allure.annotations.Step;

import java.io.IOException;
import java.io.InputStream;
import java.util.function.Function;

public class T2Agreement extends T2Entity {

    T2Agreement(String json) {
        super(json);
    }

    public T2Agreement(InputStream jsonIS) throws IOException {
        super(jsonIS);
    }

    @Step("Create Agreement for Counterparty Id: {1}")
    public T2Agreement create(TORCSession session, String clientId, Function<DocumentContext, DocumentContext> modifyPayload) throws IOException {
        String endPoint = "/api/clients/" + clientId + "/agreementsandaccounts";
        DocumentContext currData = modifyPayload.apply(JsonPath.parse(this.json));
        TORCGenericRequest request = TORCGenericRequest.genericPut(session, endPoint, currData.jsonString());
        return new T2Agreement(request.getJson());
    }

    public T2Agreement get(TORCSession session, String clientId) throws IOException {
        String endPoint = "/api/clients/" + clientId + "/agreementsandaccounts";
        TORCGenericRequest request = TORCGenericRequest.genericGet(session, endPoint);
        return new T2Agreement(request.getJson());
    }

    public String getTaskId(){
        return getProperty("$[0].tasks[0]");
    }

    public Integer getId() {
        return Integer.parseInt(getProperty("$[0].id"));
    }
}
