package com.rbc.rbccm.taf.torc.api2;

import com.jayway.jsonpath.JsonPath;
import com.rbc.rbccm.taf.torc.api.TORCGenericRequest;
import com.rbc.rbccm.taf.torc.api.TORCSession;

import java.io.IOException;
import java.util.List;

public class T2_Tax_Form extends T2Entity {
    private String id;
    private String label;
    private String formClass;
    private String formName;

    private T2_Tax_Form(String json) {
        super(json);
    }

    public static T2_Tax_Form get(TORCSession session, String formName, String formYear) throws IOException {
        if (formName.equals("BENE")) {
            formName = "BEN-E";
        } else if (formName.equals("W9")) {
            formName = "W-9";
        }
        if (formYear.contains("*")) {
            formYear = "2017";
        }

        if (formName.trim().toLowerCase().equals("none")) {
            T2_Tax_Form form = new T2_Tax_Form("{}");
            form.formName = "NoForm";
            form.label = "NoForm";
            form.id = "NoForm";
            form.formClass = "com.rbccm.torc.model.form.NoForm";
            return form;
        }

        TORCGenericRequest req = TORCGenericRequest.genericGet(session, "/api/wtaxformtype");
        List forms = JsonPath.parse(req.getJson()).read ("$[?(@.label =~ /.*" + formName + " .*" + formYear + ".*/i)]");
        T2_Tax_Form taxForm = new T2_Tax_Form(JsonPath.parse(forms.get(forms.size()-1)).jsonString());
        taxForm.id = taxForm.getProperty("$.id");
        taxForm.label = taxForm.getProperty("$.label");
        taxForm.formClass = taxForm.getProperty("$.additionalProperties.taxFormClass");
        taxForm.formName = taxForm.getProperty("$.additionalProperties.taxFormName");
        return taxForm;
    }

    public String getId() {
        return id;
    }

    public String getLabel() {
        return label;
    }

    public String getFormClass() {
        return formClass;
    }

    public String getFormName() {
        return formName;
    }
}
