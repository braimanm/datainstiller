package com.rbc.rbccm.taf.torc.domainobjects;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rbc.rbccm.taf.torc.api.*;
import com.rbccm.taf.ui.support.AliasedString;
import com.rbccm.taf.ui.support.DomainObjectModel;
import com.rbccm.taf.ui.support.TestContext;
import com.rbccm.taf.ui.utils.ArtificialStep;
import com.rbccm.torc.model.ManagedFundFlatRecord;
import com.rbccm.torc.model.client.Agreement;
import com.rbccm.torc.model.client.AgreementStatus;
import com.rbccm.torc.model.client.ClientRelationshipType;
import com.rbccm.torc.model.client.ManagedFund;
import com.thoughtworks.xstream.annotations.XStreamAlias;
import datainstiller.data.Data;
import org.assertj.core.api.SoftAssertions;
import ru.yandex.qatools.allure.Allure;
import ru.yandex.qatools.allure.events.MakeAttachmentEvent;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;

@SuppressWarnings({"unused", "MismatchedQueryAndUpdateOfCollection", "unchecked"})
@XStreamAlias("performance-test-data")
public class PerfDOM extends DomainObjectModel {
    private AliasedString baseUrl;
    private AliasedString userName;
    private AliasedString password;
    private List<String> counterparties;
    private long timeOut;
    @Data(skip = true)
    private TORCSession session;
    private AliasedString jsonAgreementIA;
    private AliasedString jsonAgreementEntity;
    private AliasedString jsonManagedFundsTemplate;
    private AliasedString jsonAccount;

    private String getBaseUrl() {
        return baseUrl.getData();
    }

    public String getUserName() {
        return userName.getData();
    }

    public String getPassword() {
        return password.getData();
    }

    private String getJsonAgreementIA() {
        return jsonAgreementIA.getData();
    }

    private String getJsonAgreementEntity() {
        return jsonAgreementEntity.getData();
    }

    private String getJsonManagedFundsTemplate() {
        return jsonManagedFundsTemplate.getData();
    }


    private TORCSession getSession() throws IOException {
        if (session == null) {
            if (baseUrl != null) {
                session = new TORCSession(getBaseUrl(), getUserName(), getPassword());
            }
        }
        return session;
    }

    private void loadTest(Function<String, Throwable> function, List<String> counterparties) {
        SoftAssertions soft = new SoftAssertions();
        for (String counterparty : counterparties){
            Throwable throwable = function.apply(counterparty);
            if (throwable != null) {
                soft.fail(throwable.getMessage(), throwable );
            }
        }
        soft.assertAll();
    }

    private MakeAttachmentEvent createAttachment(TORCGenericRequest request, String description) {
        String descr = description + " (" + request.getExecutionTime() / 1000f  + "s)";
        return new MakeAttachmentEvent(request.getJson().getBytes(), descr, "application/json");
    }

    private long stepManagedFunds(String counterparty, List<MakeAttachmentEvent> attachments) throws IOException {
            long execTime = 0;
            TORCCounterpartyEntity party = TORCCounterpartyEntity.searchOne(PerfDOM.this.getSession(), counterparty);
            TORCClient client = TORCClient.get(PerfDOM.this.getSession(), party.id);
            boolean isEntity = client.getEntity().getClientRelationshipType().equals(ClientRelationshipType.ENTITY);
            //Start counting
            TORCAgreement agreement = TORCAgreement.get(PerfDOM.this.getSession(), party.id, isEntity);
            execTime += agreement.getExecutionTime();
            attachments.add(PerfDOM.this.createAttachment(agreement, "[GET] Agreements Response"));
            client = TORCClient.get(PerfDOM.this.getSession(), party.id);
            execTime += client.getExecutionTime();
            attachments.add(PerfDOM.this.createAttachment(client, "[GET] Client Response"));
            TORCClientManagedFunds funds = TORCClientManagedFunds.post(PerfDOM.this.getSession(), party.id);
            attachments.add(PerfDOM.this.createAttachment(funds, "[POST] Managed Funds Response"));
            execTime += funds.getExecutionTime();
            return execTime;
    }

    public void testManagedFunds() {
        loadTest(counterparty -> {
            String stepName = "testManagedFunds " + counterparty.substring(0,20).trim() + "...";
            ArtificialStep step = (attachments -> stepManagedFunds(counterparty, attachments));
            return step.executeStep(stepName, timeOut);
        }, counterparties.subList(0 ,3));

    }

    private long stepAgreements(String counterparty, List<MakeAttachmentEvent> attachments) throws IOException {
        TORCCounterpartyEntity party = TORCCounterpartyEntity.searchOne(getSession(), counterparty);
        TORCClient client = TORCClient.get(getSession(), party.id);
        boolean isEntity = client.getEntity().getClientRelationshipType().equals(ClientRelationshipType.ENTITY);
        //Start counting
        TORCAgreement agreement = TORCAgreement.get(getSession(), party.id, isEntity);
        attachments.add(createAttachment(agreement, "[GET] Agreements Response"));
        return agreement.getExecutionTime();
    }

    public void testAgreements()  {
        loadTest(counterparty -> {
            String stepName = "testAgreements " + counterparty.substring(0,20).trim() + "...";
            ArtificialStep step = (attchments -> stepAgreements(counterparty, attchments));
            return step.executeStep(stepName, timeOut);
        }, counterparties.subList(0 ,3));
    }

    private long stepManagedFundsWithFilter(String counterparty, List<MakeAttachmentEvent> attachments) throws IOException {
        TORCCounterpartyEntity party = TORCCounterpartyEntity.searchOne(getSession(), counterparty);
        //Start counting
        TORCClientManagedFunds funds = TORCClientManagedFunds.getWithFilterLegalName(getSession(), party.id, counterparty.substring(0, 20).trim());
        attachments.add(createAttachment(funds, "[GET] Managed Funds With Filter Response"));
        return funds.getExecutionTime();
    }

    public void testManagedFundsWithFilter() {
        loadTest(counterparty -> {
            String stepName = "testManagedFundsWithFilter " + counterparty.substring(0,20).trim() + "...";
            ArtificialStep step = (attchments -> stepManagedFundsWithFilter(counterparty, attchments));
            return step.executeStep(stepName, timeOut);
        }, counterparties.subList(0 ,3));
    }

    private long stepOtherIA(String counterparty, List<MakeAttachmentEvent> attachments) throws IOException {
        long execTime = 0;
        TORCCounterpartyEntity party = TORCCounterpartyEntity.searchOne(getSession(), counterparty);
        //Start counting
        TORCClient client = TORCClient.get(getSession(), party.id);
        execTime += client.getExecutionTime();
        attachments.add(createAttachment(client, "[GET] Client 1st Response"));
        TORCBeneficiaryBookingPoints points = TORCBeneficiaryBookingPoints.get(getSession());
        execTime += points.getExecutionTime();
        attachments.add(createAttachment(points, "[GET] Beneficiary Booking Points Response"));
        TORCGenericRequest pphost = TORCGenericRequest.genericGet(getSession(), "/api/torcpphost");
        execTime += pphost.getExecutionTime();
        attachments.add(createAttachment(pphost, "[GET] /api/torcpphost Response"));
        client = TORCClient.get(getSession(), party.id);
        execTime += client.getExecutionTime();
        attachments.add(createAttachment(client, "[GET] Client 2nd Response"));
        return execTime;
    }

    public void testOtherIA() {
        loadTest(counterparty -> {
            String stepname = "testOtherIA " + counterparty.substring(0,20).trim() + "...";
            ArtificialStep step = (attchments -> stepOtherIA(counterparty, attchments));
            return step.executeStep(stepname, timeOut);
        }, counterparties.subList(3, 5));
    }

    private long stepCreateAgreement(String counterparty, List<MakeAttachmentEvent> attachments) throws IOException {
        long execTime = 0;
        TORCCounterpartyEntity party = TORCCounterpartyEntity.searchOne(getSession(), counterparty);
        TORCClient client = TORCClient.get(getSession(), party.id);
        boolean isEntity = client.getEntity().getClientRelationshipType().equals(ClientRelationshipType.ENTITY);
        TORCAgreement agreement = TORCAgreement.get(getSession(), party.id, isEntity);
        StringBuilder payload = new StringBuilder(agreement.getJson());
        payload.deleteCharAt(payload.lastIndexOf("]"));
        if (isEntity) {
            payload.append(",").append(getJsonAgreementEntity()).append("]");
        } else {
            payload.append(",").append(getJsonAgreementIA()).append("]");
        }

        //Start counting
        agreement = TORCAgreement.put(getSession(), party.id, payload.toString(), isEntity);
        execTime += agreement.getExecutionTime();
        attachments.add(createAttachment(agreement, "[PUT] Agreements Response"));
        client = TORCClient.get(getSession(), party.id);
        execTime += client.getExecutionTime();
        attachments.add(createAttachment(client, "[GET] Client Response"));
        agreement = TORCAgreement.get(getSession(), party.id, isEntity);
        execTime += agreement.getExecutionTime();
        attachments.add(createAttachment(agreement, "[GET] Agreements Response"));
        return execTime;
    }

    public void testCreateAgreement()  {
        loadTest(counterparty -> {
            String stepName = "testCreateAgreement " + counterparty.substring(0,20).trim() + "...";
            ArtificialStep step = (attchments -> stepCreateAgreement(counterparty, attchments));
            return step.executeStep(stepName, timeOut);
        }, counterparties.subList(0 ,4));
    }

    private long stepCreateManagedFund(String counterparty, List<MakeAttachmentEvent> attachments) throws IOException {
        long execTime = 0;
        TORCCounterpartyEntity party = TORCCounterpartyEntity.searchOne(getSession(), counterparty);
        TORCClient client = TORCClient.get(getSession(), party.id);
        boolean isEntity = client.getEntity().getClientRelationshipType().equals(ClientRelationshipType.ENTITY);
        TORCAgreement agreement = TORCAgreement.get(getSession(), party.id, isEntity);
        String payload = getJsonManagedFundsTemplate().replace("[**AGREEMENTS**]", agreement.getLinkedAgreementEntitiesAsJson());
        //Start counting
        TORCClientManagedFunds funds = TORCClientManagedFunds.put(getSession(), party.id, payload);
        execTime += funds.getExecutionTime();
        attachments.add(createAttachment(funds, "[PUT] Managed Funds Response"));
        funds = TORCClientManagedFunds.post(getSession(), party.id);
        execTime += funds.getExecutionTime();
        attachments.add(createAttachment(funds, "[POST] Agreements Response"));
        return execTime;
    }

    public void testCreateManagedFund() {
        loadTest(counterparty -> {
            String stepName = "testCreateManagedfund " + counterparty.substring(0,20).trim() + "...";
            ArtificialStep step = attchments -> stepCreateManagedFund(counterparty, attchments);
            return step.executeStep(stepName, timeOut);
        }, counterparties.subList(0 ,3));
    }

    private long stepUpdateManagedFund(String counterparty, List<MakeAttachmentEvent> attachments, boolean createAccount) throws IOException {
        long execTime = 0;
        TORCCounterpartyEntity party = TORCCounterpartyEntity.searchOne(getSession(), counterparty);
        TORCClientManagedFunds fundSearch = TORCClientManagedFunds.post(getSession(), party.id);
        ManagedFundFlatRecord fundFlat = fundSearch.getEntities()[0];
        String fundId = "" + fundFlat.getId();
        ObjectMapper mapper = new ObjectMapper();
        TypeReference<HashMap<String,Object>> mapType = new TypeReference<HashMap<String,Object>>() {};
        HashMap<String,Object> map = mapper.readValue(mapper.writeValueAsString(fundFlat), mapType);
        TORCManagedFund mfund = TORCManagedFund.get(getSession(), party.id, fundId);
        map.putAll(mapper.readValue(mfund.getJson(), mapType));
        map.put("$promise", new HashMap<>());
        map.put("$resolved", true);
        map.put("codedName", TestContext.getGlobalAliases().get("time-stamp"));
        if (createAccount) {
            HashMap<String,Object> accountMap = mapper.readValue(jsonAccount.getData(), mapType);
            accountMap.put("shortCode", party.id + accountMap.get("shortCode"));
            ((ArrayList)map.get("accounts")).add(accountMap);
        }
        String payload = mapper.writeValueAsString(map);
        mfund = TORCManagedFund.put(getSession(), party.id, payload);
        execTime += mfund.getExecutionTime();
        attachments.add(createAttachment(mfund, "[PUT] Managed Funds Response"));
        TORCClient client = TORCClient.get(getSession(), party.id);
        if (client.getExecutionTime() >= fundSearch.getExecutionTime()) {
            execTime += client.getExecutionTime();
            attachments.add(createAttachment(client, "[GET] Client Response"));
        } else  {
            execTime += fundSearch.getExecutionTime();
            attachments.add(createAttachment(fundSearch, "[POST] Managed Funds Response"));
        }
        return execTime;
    }

    public void testUpdateManagedFund() {
        loadTest(counterparty -> {
            String stepName = "testUpdateManagedFund " + counterparty.substring(0,20).trim() + "...";
            ArtificialStep step = attchments -> stepUpdateManagedFund(counterparty, attchments, false);
            return step.executeStep(stepName, timeOut);
        }, counterparties.subList(0, 3));
    }

    public void testCreateAccount() {
        loadTest(counterparty -> {
            String stepName = "testCreateAccount " + counterparty.substring(0,20).trim() + "...";
            ArtificialStep step = attchments -> stepUpdateManagedFund(counterparty, attchments, true);
            return step.executeStep(stepName, timeOut);
        }, counterparties.subList(0, 3));
    }

    private long stepUpdateAgreement(String counterparty, List<MakeAttachmentEvent> attachments) throws IOException {
        long execTime = 0;
        TORCCounterpartyEntity party = TORCCounterpartyEntity.searchOne(getSession(), counterparty);
        TORCClient client = TORCClient.get(getSession(), party.id);
        boolean isEntity = client.getEntity().getClientRelationshipType().equals(ClientRelationshipType.ENTITY);
        TORCAgreement agreement = TORCAgreement.get(getSession(), party.id, isEntity);
        ObjectMapper mapper = new ObjectMapper();
        TypeReference<List<HashMap<String,Object>>> mapType = new TypeReference<List<HashMap<String,Object>>>() {};
        List<HashMap<String, Object>> listMap = mapper.readValue(agreement.getJson(), mapType);
        int rand = ThreadLocalRandom.current().nextInt(30);
        int i = 0;
        for (HashMap<String, Object> map : listMap) {
            if(map.containsKey("status") && map.get("status").equals("PENDING")) {
                if  (i == rand) {
                    String comment = "comment";
                    if (map.containsKey("comments")) {
                        comment = "comments";
                    }
                    map.put(comment, TestContext.getGlobalAliases().get("time-stamp"));
                    map.put("dirty", true);
                    break;
                } else {
                    i++;
                }
            }
        }

        String payload = mapper.writeValueAsString(listMap);

        //Start counting
        agreement = TORCAgreement.put(getSession(), party.id, payload, isEntity);
        execTime += agreement.getExecutionTime();
        attachments.add(createAttachment(agreement, "[PUT] Agreements Response"));
        client = TORCClient.get(getSession(), party.id);
        execTime += client.getExecutionTime();
        attachments.add(createAttachment(client, "[GET] Client Response"));
        agreement = TORCAgreement.get(getSession(), party.id, isEntity);
        execTime += agreement.getExecutionTime();
        attachments.add(createAttachment(agreement, "[GET] Agreements Response"));
        return execTime;
    }

    public void testUpdateAgreement() {
        loadTest(counterparty -> {
            String stepName = "testUpdateAgreement " + counterparty.substring(0,20).trim() + "...";
            ArtificialStep step = attchments -> stepUpdateAgreement(counterparty, attchments);
            return step.executeStep(stepName, timeOut);
        }, counterparties.subList(0 ,4));
    }

    private String[] get_CounterpartyId_FundId_AgreementId(String counterparty) throws IOException {
        if (getBaseUrl().equals("http://mrkdlvaiaas926.devfg.rbc.com:8080") && counterparty.startsWith("Pacific Investment")) {
            return new String[]{"223268","10618","64"};
        }
        TORCCounterpartyEntity party = TORCCounterpartyEntity.searchOne(getSession(), counterparty);
        TORCClientManagedFunds fundSearch = TORCClientManagedFunds.post(getSession(), party.id);

        ManagedFundFlatRecord[] fundFlat = fundSearch.getEntities();
        int fundIndex =  ThreadLocalRandom.current().nextInt(fundFlat.length);

        String fundId = "" + fundFlat[fundIndex].getId();
        TORCManagedFund fund = TORCManagedFund.get(getSession(), party.id, fundId);
        ManagedFund mfund = fund.getEntity();
        String agreementId ="";
        int rand = ThreadLocalRandom.current().nextInt(mfund.getAgreements().size());
        int i = 0;
        for (Agreement agreement: mfund.getAgreements()){
            AgreementStatus status = agreement.getStatus();
            if(agreement.getManagedFundLinkFlag() && !status.equals(AgreementStatus.CANCELLED) && !status.equals(AgreementStatus.TERMINATED)) {
                agreementId = agreement.getId().toString();
                if (i == rand) {
                    break;
                } else {
                    i++;
                }
            }
        }
        return new String[]{party.id, fundId, agreementId};
    }

    private TORCTask getRandomTask(String counterparty) throws IOException {
        String[] params = get_CounterpartyId_FundId_AgreementId(counterparty);
        TORCTask[] tasks = TORCTask.search(getSession(),params[0], params[2]);
        int randTask = ThreadLocalRandom.current().nextInt(tasks.length);
        return tasks[randTask];
    }

    private long stepLoadCRVs(String counterparty, List<MakeAttachmentEvent> attachments) throws IOException {
        long execTime = 0;
        String[] params = get_CounterpartyId_FundId_AgreementId(counterparty);
        String endPoint = "/api/clients/" + params[0] + "/agreements/" + params[2] +"/managedfunds/" + params[1] + "/crv";
        //Start counting
        TORCGenericRequest crv = TORCGenericRequest.genericGet(getSession(), endPoint );
        execTime += crv.getExecutionTime();
        attachments.add(createAttachment(crv, "[GET] CRV Response"));
        String taskId = (String) new ObjectMapper().readValue(crv.getJson(),HashMap.class).get("taskId");
        TORCGenericRequest task = TORCGenericRequest.genericGet(getSession(), "/api/tasks/" + taskId);
        execTime += task.getExecutionTime();
        attachments.add(createAttachment(task, "[GET] Task Response"));
        return execTime;
    }

    public void testLoadCRVs() {
        loadTest(counterparty -> {
            String stepName = "testLoadCRVs " + counterparty.substring(0,20).trim() + "...";
            ArtificialStep step = attchments -> stepLoadCRVs(counterparty, attchments);
            return step.executeStep(stepName, timeOut);
        }, counterparties.subList(0, 3));
    }

    private String getMultipartBoundaryPayload(String multipartBoundary, String payload) {
        String crlf ="\r\n";
        return  "--" + multipartBoundary + crlf +
                "Content-Disposition: form-data; name=\"parentSysTaskId\"" + crlf + crlf +
                "undefined" + crlf +
                "--" + multipartBoundary + crlf +
                "Content-Disposition: form-data; name=\"model\"" + crlf + crlf +
                payload + crlf +
                "--" + multipartBoundary + "--";
    }

    private long stepExecuteBusinessRules(String counterparty, List<MakeAttachmentEvent> attachments) throws IOException {
        long execTime;
        TORCTask torcTask = getRandomTask(counterparty);
        String endPoint = "/api/clients/" + torcTask.clientId + "/agreements/" + torcTask.agreementId +"/managedfunds/" + torcTask.managedFundId + "/crv";
        TORCGenericRequest crv = TORCGenericRequest.genericGet(getSession(), endPoint );
        TORCGenericRequest task = TORCGenericRequest.genericGet(getSession(), "/api/tasks/" + torcTask.id);
        HashMap<String, Object> taskEntity = task.getEntity(HashMap.class);
        taskEntity.put("assignee",TestContext.getGlobalAliases().get("user-name"));
        taskEntity.put("$promise",new HashMap<>());
        taskEntity.put("$resolved", true);
        String multipartBoundary = "00AA11BB22CC33DD";
        String payload = getMultipartBoundaryPayload(multipartBoundary, new ObjectMapper().writeValueAsString(taskEntity));
        Map<String, String> headers = new HashMap<>();
        headers.put("Content-Type","multipart/form-data; boundary=" + multipartBoundary + "; charset=UTF-8");
        TORCGenericRequest.genericPost(getSession(), "/api/tasks/" + torcTask.id, headers, null, payload);
        //Start counting
        TORCGenericRequest executeCRV = TORCGenericRequest.genericPut(getSession(),endPoint + "/execute", crv.getJson());
        crv = TORCGenericRequest.genericGet(getSession(), endPoint );
        task = TORCGenericRequest.genericGet(getSession(), "/api/tasks/" + torcTask.id);
        execTime = executeCRV.getExecutionTime() + crv.getExecutionTime() + task.getExecutionTime();
        attachments.add(createAttachment(executeCRV, "[PUT] CRV Execute Response"));
        attachments.add(createAttachment(crv, "[GET] CRV Response"));
        attachments.add(createAttachment(task, "[GET] Task Response"));
        return execTime;
    }

    public void testExecuteBusinessRules() {
        loadTest(counterparty -> {
            String stepName = "testExecuteBusinessesRules " + counterparty.substring(0,20).trim() + "...";
            ArtificialStep step = attchments ->  stepExecuteBusinessRules(counterparty, attchments);
            return step.executeStep(stepName, timeOut);
        }, counterparties.subList(0, 3));
    }

    private long stepUpdateTask(String counterparty, List<MakeAttachmentEvent> attachments) throws IOException {
        long execTime = 0;
        TORCTask torcTask = getRandomTask(counterparty);
        String endPoint = "/api/clients/" + torcTask.clientId + "/agreements/" + torcTask.agreementId +"/managedfunds/" + torcTask.managedFundId + "/crv";
        TORCGenericRequest task = TORCGenericRequest.genericGet(getSession(), "/api/tasks/" + torcTask.id);
        HashMap<String, Object> taskEntity = task.getEntity(HashMap.class);
        taskEntity.put("newComment", "Comment For Performance test");
        taskEntity.put("$promise",new HashMap<>());
        taskEntity.put("$resolved", true);
        String multipartBoundary = "00AA11BB22CC33DD";
        String payload = getMultipartBoundaryPayload(multipartBoundary, new ObjectMapper().writeValueAsString(taskEntity));
        Map<String, String> headers = new HashMap<>();
        headers.put("Content-Type","multipart/form-data; boundary=" + multipartBoundary + "; charset=UTF-8");
        //Start counting
        task = TORCGenericRequest.genericPost(getSession(), "/api/tasks/" + torcTask.id, headers, null, payload);
        execTime += task.getExecutionTime();
        attachments.add(createAttachment(task, "[POST] Task Response"));
        task = TORCGenericRequest.genericGet(getSession(), "/api/tasks/" + torcTask.id);
        execTime += task.getExecutionTime();
        attachments.add(createAttachment(task, "[GET] Task Response"));
        return execTime;
    }

    public void testUpdateTask() {
        loadTest(counterparty -> {
            String stepName = "testUpdateTask " + counterparty.substring(0,20).trim() + "...";
            ArtificialStep step = attchments -> stepUpdateTask(counterparty, attchments);
            return step.executeStep(stepName, timeOut);
        }, counterparties.subList(0, 3));
    }

    public void executeRandomTest() throws IOException {
        int test = ThreadLocalRandom.current().nextInt(5);
        int thinkTime = ThreadLocalRandom.current().nextInt(10) + 1;
        int party = ThreadLocalRandom.current().nextInt(3);
        List<MakeAttachmentEvent> attachmentEvents = new ArrayList<>();
        String task = null;
        switch (test) {
            case 0:
                task = "stepManagedFunds " + stepManagedFunds(counterparties.get(party), attachmentEvents) +"ms";
                break;
            case 1:
                task = "stepAgreements " + stepAgreements(counterparties.get(party), attachmentEvents) +"ms";
                break;
            case 2:
                task = "stepManagedFundsWithFilter " + stepManagedFundsWithFilter(counterparties.get(party), attachmentEvents) +"ms";
                break;
            case 3:
                task = "stepOtherIA " + stepOtherIA(counterparties.get(party), attachmentEvents) +"ms";
                break;
            case 4:
                task = "stepLoadCRVs " + stepLoadCRVs(counterparties.get(party), attachmentEvents) +"ms";
                break;
//            case 5:
//                task = "stepExecuteBusinessRules " + stepExecuteBusinessRules(counterparties.get(party), attachmentEvents) +"ms";
//                break;
//            case 6:
//
//                for (int i = 0; i < 5; i++) {
//                    try {
//                        long ms = stepCreateAgreement(counterparties.get(party), attachmentEvents);
//                        task = "stepCreateAgreement " + ms + "ms";
//                        break;
//                    } catch (Exception e) {
//                        try {
//                            TimeUnit.SECONDS.sleep(5);
//                        } catch (InterruptedException e1) {
//                            e1.printStackTrace();
//                        }
//                    }
//                }
//                break;
//            case 7:
//                for (int i = 0; i < 5; i++) {
//                    try {
//                        long ms = stepUpdateAgreement(counterparties.get(party), attachmentEvents);
//                        task = "stepUpdateAgreement " + ms + "ms";
//                        break;
//                    } catch (Exception e) {
//                        try {
//                            TimeUnit.SECONDS.sleep(5);
//                        } catch (InterruptedException e1) {
//                            e1.printStackTrace();
//                        }
//                    }
//                }
//                break;

        }
        System.out.println(test + "  " + task);
        for (MakeAttachmentEvent att : attachmentEvents) {
            Allure.LIFECYCLE.fire(att);
        }
        try {
            TimeUnit.SECONDS.sleep(thinkTime);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }


}