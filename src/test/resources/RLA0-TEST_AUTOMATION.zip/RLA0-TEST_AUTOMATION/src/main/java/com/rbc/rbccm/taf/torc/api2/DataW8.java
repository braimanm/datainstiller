package com.rbc.rbccm.taf.torc.api2;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import datainstiller.data.DataPersistence;


@XStreamAlias("w8-data")
public class DataW8 extends DataPersistence {
    private String srNo;
    private Condition condition;
    private Conclusion conclusion;

    public DataW8() {}
    public DataW8(String[] values, String formName) {
        srNo = values[0];
        condition = new Condition();
        conclusion = new Conclusion();
        switch (formName) {
            case "W8IMY" :
                condition.jurisdiction = values[2];
                condition.igaStatus = values[4];
                condition.qiStatus = values[6];
                condition.docType = values[8];
                condition.obligationDocumentStatusCh4 = values[10];
                condition.obligationDocumentStatusCh3 = values[12];
                condition.knowledgeCH4 = values[14];
                condition.knowledgeCH3 = values[16];
                condition.isAssumingUnderCh3Ch4 = values[18];
                conclusion.withholdingStatusCh4 = values[20];
                conclusion.withholdingRateCh4 = values[21];
                conclusion.withholdingStatusCh3 = values[23];
                conclusion.withholdingRateCh3 = values[24];
                break;
            case "W8EXP" :
                condition.jurisdiction = values[2];
                condition.igaStatus = values[4];
                condition.qiStatus = values[6];
                condition.docType = values[8];
                condition.obligationDocumentStatusCh4 = values[10];
                condition.obligationDocumentStatusCh3 = values[12];
                condition.knowledgeCH4 = values[14];
                condition.knowledgeCH3 = values[16];
                conclusion.withholdingStatusCh4 = values[20];
                conclusion.withholdingRateCh4 = values[21];
                conclusion.withholdingStatusCh3 = values[23];
                conclusion.withholdingRateCh3 = values[24];
                break;
            case "W8ECI" :
                condition.jurisdiction = values[2];
                condition.igaStatus = values[4];
                condition.qiStatus = values[6];
                condition.beneficialOwnerType = values[8];
                condition.docType = values[10];
                condition.obligationDocumentStatusCh3 = values[12];
                condition.obligationDocumentStatusCh4 = values[14];
                condition.knowledgeCH4 = values[16];
                condition.knowledgeCH3 = values[18];
                conclusion.withholdingStatusCh4 = values[22];
                conclusion.withholdingRateCh4 = values[23];
                conclusion.withholdingStatusCh3 = values[25];
                conclusion.withholdingRateCh3 = values[26];
                break;
            case "W8BENE" :
                condition.jurisdiction = values[2];
                condition.igaStatus = values[4];
                condition.qiStatus = values[6];
                condition.docType = values[8];
                condition.obligationDocumentStatusCh4 = values[10];
                condition.obligationDocumentStatusCh3 = values[12];
                condition.knowledgeCH4 = values[14];
                condition.knowledgeCH3 = values[16];
                conclusion.withholdingStatusCh4 = values[18];
                conclusion.withholdingRateCh4 = values[19];
                conclusion.withholdingStatusCh3 = values[21];
                conclusion.withholdingRateCh3 = values[22];
                break;
            case "W8BEN" :
                condition.jurisdiction = values[2];
                condition.igaStatus = values[4];
                condition.qiStatus = values[6];
                condition.docType = values[8];
                condition.obligationDocumentStatusCh3 = values[10];
                condition.obligationDocumentStatusCh4 = values[12];
                condition.knowledgeCH4 = values[14];
                condition.knowledgeCH3 = values[16];
                conclusion.withholdingStatusCh4 = values[18];
                conclusion.withholdingRateCh4 = values[19];
                conclusion.withholdingStatusCh3 = values[21];
                conclusion.withholdingRateCh3 = values[22];
                break;
        }

    }

    public String getSrNo() {
        return srNo;
    }

    public Condition getCondition() {
        return condition;
    }

    public Conclusion getConclusion() {
        return conclusion;
    }

    public static class Condition {
        String jurisdiction;
        String igaStatus;
        String qiStatus;
        String beneficialOwnerType;
        String docType;
        String obligationDocumentStatusCh4;
        String obligationDocumentStatusCh3;
        String knowledgeCH4;
        String knowledgeCH3;
        String isAssumingUnderCh3Ch4;

        public String getJurisdiction() {
            return jurisdiction;
        }

        public String getIgaStatus() {
            return igaStatus.replace("-","_");
        }

        public String getQiStatus() {
            if (qiStatus.equals("*")) {
                return "Non_QI";
            }
            return qiStatus.replace("-","_").replace("/","").trim();
        }

        public String getDocType() {
            if (docType.contains("W-8CI")) return "W8ECI";
            return docType.replace("Form","").replace(" ", "").replace("-","");
        }

        public boolean getObligationDocumentStatusCh4() {
            return obligationDocumentStatusCh4.trim().equals("Complete");
        }

        public boolean getObligationDocumentStatusCh3() {
            return obligationDocumentStatusCh3.trim().equals("Complete");
        }


        private String getKnowledge(String value) {
            if (value.contains("Other")) return "OTHER";
            if (value.contains("Non-US")) return "NONUS";
            if (value.contains("US")) return "US";
            if (value.trim().equals("None")) return "NONE";
            if (value.trim().equals("*")) return "NONE";
            return knowledgeCH3;
        }

        public String getKnowledgeCH3() {
            return getKnowledge(knowledgeCH3);
        }

        public String getKnowledgeCH4() {
            return getKnowledge(knowledgeCH4);
        }

        public boolean getIsAssumingUnderCh3Ch4() {
            if (isAssumingUnderCh3Ch4 == null) return false;
            return isAssumingUnderCh3Ch4.trim().toLowerCase().contains("yes");
        }


        public String getBeneficialOwnerType() {
            return beneficialOwnerType.toUpperCase();
        }
    }

    public static class Conclusion {
        String withholdingStatusCh4;
        String withholdingRateCh4;
        String withholdingStatusCh3;
        String withholdingRateCh3;

        public String getWithholdingStatusCh4() {
            if (withholdingStatusCh4.contains("UBO")) {
                return "WITHHOLDABLE";
            }
            return withholdingStatusCh4.trim().replace(" ","_").toUpperCase();
        }

        public String getWithholdingRateCh4() {
            if (withholdingRateCh4.contains("UBO")) {
                return "-1%";
            }
            return (int)(Float.parseFloat(withholdingRateCh4) * 100) + "%" ;
        }

        public String getWithholdingStatusCh3() {
            if (withholdingStatusCh3.contains("UBO")) {
                return "WITHHOLDABLE";
            }
            return withholdingStatusCh3.trim().replace(" ","_").toUpperCase();
        }

        public String getWithholdingRateCh3() {
            if (isUbo() || isTreaty()) {
                return "-1%";
            }
            return (int)(Float.parseFloat(withholdingRateCh3) * 100) + "%";
        }

        public boolean isUbo() {
            return  withholdingRateCh3.contains("UBO");
        }

        public boolean isTreaty() {
            return  withholdingRateCh3.contains("Treaty");
        }

    }

}
