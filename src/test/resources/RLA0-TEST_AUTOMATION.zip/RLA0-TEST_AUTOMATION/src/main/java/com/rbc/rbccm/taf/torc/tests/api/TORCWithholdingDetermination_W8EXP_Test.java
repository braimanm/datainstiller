package com.rbc.rbccm.taf.torc.tests.api;

import com.jayway.jsonpath.JsonPath;
import com.rbc.rbccm.taf.torc.api.TORCSession;
import com.rbc.rbccm.taf.torc.api2.*;
import com.rbccm.taf.ui.support.EnvironmentsSetup;
import com.rbccm.taf.ui.support.TestContext;
import com.rbccm.taf.ui.support.UserProvider;
import com.rbccm.taf.ui.testng.TestNGBase;
import datainstiller.generators.WordGenerator;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.assertj.core.api.SoftAssertions;
import org.testng.annotations.Factory;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.Allure;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.Step;
import ru.yandex.qatools.allure.events.TestCaseEvent;
import ru.yandex.qatools.allure.model.Label;
import ru.yandex.qatools.allure.model.LabelName;
import ru.yandex.qatools.allure.model.SeverityLevel;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class TORCWithholdingDetermination_W8EXP_Test extends TestNGBase {
    private DataW8 dataW8;
    private String random;

    TORCWithholdingDetermination_W8EXP_Test() {}
    private TORCWithholdingDetermination_W8EXP_Test(DataW8 dataW8, String random) {
        this.dataW8 = dataW8;
        this.random = random;
    }

    private boolean isRowHasContinuousData(String[] data) {
        int i = 0;
        for (String val : data) {
            if (val.trim().isEmpty()) {
                i = 0;
            } else {
                if (++i > 10) return true;
            }
        }
        return false;
    }

    @Factory
    public Object[] factory() throws IOException, InvalidFormatException {
        String random = new WordGenerator().generate("{A}{B}");
        List<TORCWithholdingDetermination_W8EXP_Test> results = new ArrayList<>();
        Workbook workbook = WorkbookFactory.create(this.getClass().getClassLoader().getResourceAsStream("data/torc/api/Sep 29_All Forms_Truth Tables_GB Changes V1.1.xlsx"));
        Sheet sheet = workbook.getSheet("W8 EXP");
        sheet.forEach(row -> {
            StringBuilder rowB = new StringBuilder();
            row.forEach(cell -> {
                cell.setCellType(CellType.STRING);
                String cellValue = cell.getStringCellValue();
                rowB.append(cellValue).append("\t");
            });
            String[] data = rowB.toString().trim().split("\t");
            if (data.length > 5 && isRowHasContinuousData(data)) {
                if (!data[4].contains("Non-IGA")) { //Skip all Non-IGA rows
                    DataW8 dataW8 = new DataW8(data, "W8EXP");
                    //////For data generation
                    //////String path = System.getProperty("user.dir") + "/src/main/resources/data/torc/api/w8exp/";
                    //////dataW8.toFile(path + "data_" + data[0] + ".xml");
                    results.add(new TORCWithholdingDetermination_W8EXP_Test(dataW8, random));
                }
            }
        });
        return results.toArray();
    }

    @Features("Withholding Determination")
    @Severity(SeverityLevel.CRITICAL)
    @Test
    public void w8exp() throws IOException {
        //////dataW8 = new DataW8().fromResource("data/torc/api/w8exp/data_1.xml");   //For debugging

        String formTypeName = "W8EXP";
        String formClass = "com.rbccm.torc.model.form.W8ExpForm";
        String formVersion = "W8EXPJuly2017";

        String srNum = String.format("%03d", Integer.parseInt(dataW8.getSrNo()));
        Allure.LIFECYCLE.fire((TestCaseEvent) context -> {
            context.getLabels().add(new Label().withName(LabelName.STORY.value()).withValue("Validate Decision Model for " + formTypeName + " Form"));
            context.setName(formTypeName + "-" + srNum);
        });

        attachDataSet(dataW8, formTypeName + "_Data_" + dataW8.getSrNo());
        DataW8.Condition condition = dataW8.getCondition();
        DataW8.Conclusion conclusion = dataW8.getConclusion();

        EnvironmentsSetup.Environment env = TestContext.getTestProperties().getTestEnvironment();
        String urlBase = (System.getenv().containsKey("TORC_URL")) ? System.getenv("TORC_URL") : env.getUrl();

        EnvironmentsSetup.User user = UserProvider.getInstance().getUser("user");

        TORCSession session = new TORCSession(urlBase, user.getUserName(), user.getPassword());

        String emailDate = DateTimeFormatter.ofPattern("dd/MM/yyyy").format(LocalDateTime.now());
        String timestamp = DateTimeFormatter.ofPattern("yyMMddkkmmss").format(LocalDateTime.now()) + Thread.currentThread().getId();

        T2Counterparty counterparty = T2Counterparty.create(session, formTypeName + "_" + random + "_" + srNum + "_" + timestamp, "autotest@yahoo.com");
        String id = counterparty.getId();

        T2RBCBookingPoints rbcBP = T2RBCBookingPoints.get(session);
        String rbcLegalEntity = rbcBP.getRbcLegalEntity(condition.getJurisdiction());
        String rbcBookingPoint = rbcBP.getRbcBookingPoint(condition.getJurisdiction());
        String igaStatus = rbcBP.getIGAStatus(condition.getJurisdiction());

        T2_TDG_Agreement agreements = T2_TDG_Agreement.create(session, id, agreement -> {
            agreement.put("$[0]", "comments", timestamp);
            agreement.set("$[0].emailDate", emailDate);
            agreement.set("$[0].rbcLegalEntity", rbcLegalEntity);
            agreement.set("$[0].rbcBookingPoints[0].name", rbcBookingPoint);
            agreement.set("$[0].rbcBookingPoints[0].qiStatus", condition.getQiStatus());
            agreement.set("$[0].rbcBookingPoints[0].igaStatus", igaStatus);
            return agreement;
        });

        T2Task task = T2Task.get(session, agreements.getTaskId());
        task = task.assignToCurrentUser(session);

        T2CRV crv = T2CRV.get(session, task);

        String formType = condition.getDocType();
        boolean ch3Complete = condition.getObligationDocumentStatusCh3();
        boolean ch4Complete = condition.getObligationDocumentStatusCh4();
        String ch3Knowledge = condition.getKnowledgeCH3();
        String ch4Knowledge = condition.getKnowledgeCH4();

        crv = crv.execute(session, newCrv -> {
            if (formType.equals(formTypeName)) {
                newCrv.delete("$.obligationDocumentation.W_FORM.sokCh3Exists");
                newCrv.delete("$.obligationDocumentation.W_FORM.sokCh4Exists");

                Object address = JsonPath.parse("{'addressType':'PERMANENT','isMailingDifferent':false}").read("$");
                newCrv.add("$.obligationDocumentation.W_FORM.addresses", address);
                newCrv.put("$.obligationDocumentation.W_FORM", "permanentAddress", new ArrayList<>());
                newCrv.put("$.obligationDocumentation.W_FORM", "mailingAddress", new ArrayList<>());
                newCrv.put("$.obligationDocumentation.W_FORM", "benAdressess", new ArrayList<>());
                newCrv.put("$.obligationDocumentation.W_FORM", "uboRecords", new ArrayList<>());
                newCrv.put("$.obligationDocumentation.W_FORM", "tinTypes", new HashMap<>());
                newCrv.put("$.obligationDocumentation.W_FORM", "formCompleteDisabledForGiin", false);
                newCrv.put("$.obligationDocumentation.W_FORM", "validationFlagForGiin", false);
                newCrv.put("$.obligationDocumentation.W_FORM", "usIdentificationNumber", "");

                newCrv.set("$.obligationDocumentation.W_FORM.@class", formClass);
                newCrv.set("$.obligationDocumentation.W_FORM.formType", formType);
                newCrv.put("$.obligationDocumentation.W_FORM", "formVersion", formVersion);
                newCrv.put("$.obligationDocumentation.W_FORM", "taxFormName", formType);
                newCrv.set("$.obligationDocumentation.W_FORM.ch3Complete", ch3Complete);
                newCrv.set("$.obligationDocumentation.W_FORM.ch4Complete", ch4Complete);


                switch (ch3Knowledge) {
                    case "OTHER" :
                        newCrv.put("$.obligationDocumentation.W_FORM", "sokCh3Exists", true);
                        newCrv.put("$.obligationDocumentation.W_FORM", "ch3Other", true);
                        break;
                    case "NONUS" :
                        newCrv.put("$.obligationDocumentation.W_FORM.addresses[0]", "country", "KY");
                        newCrv.put("$.obligationDocumentation.W_FORM", "countryOfIncorporation", "CA");
                        break;
                    case "NONE"  :
                        break;
                }

                switch (ch4Knowledge) {
                    case "OTHER" :
                        newCrv.put("$.obligationDocumentation.W_FORM", "sokCh4Exists", true);
                        newCrv.put("$.obligationDocumentation.W_FORM", "ch4Other", true);
                        break;
                    case "US" :
                        newCrv.put("$.obligationDocumentation.W_FORM.addresses[0]", "country", "US");
                        newCrv.put("$.obligationDocumentation.W_FORM", "countryOfIncorporation", "US");
                        break;
                    case "NONE"  :
                        break;
                }

                return newCrv;
            }
            return newCrv;
        });

        T2Summary summary = T2Summary.get(session, crv);
        validate(summary, conclusion);
        session.end();
    }

    @Step( "Validating Conclusion")
    private void validate(T2Summary summary, DataW8.Conclusion conclusion) {
        summary.attachToReport();
        SoftAssertions.assertSoftly(soft -> {
            soft.assertThat(summary.getWithholdabilityStatusCh4()).as("Withholdability Status Ch4").isEqualTo(conclusion.getWithholdingStatusCh4());
            soft.assertThat(summary.getWithholdingRateCh4()).as("Withholding Rate Ch4").isEqualTo(conclusion.getWithholdingRateCh4());
            soft.assertThat(summary.getWithholdabilityStatusCh3()).as("Withholdability Status Ch3").isEqualTo(conclusion.getWithholdingStatusCh3());
            soft.assertThat(summary.getWithholdingRateCh3()).as("Withholding Rate Ch3").isEqualTo(conclusion.getWithholdingRateCh3());
        });
    }

}
