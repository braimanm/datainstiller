package com.rbc.rbccm.taf.torc.tests.api;

import com.jayway.jsonpath.JsonPath;
import com.rbc.rbccm.taf.torc.api.TORCSession;
import com.rbc.rbccm.taf.torc.api2.*;
import com.rbccm.taf.ui.support.EnvironmentsSetup;
import com.rbccm.taf.ui.support.TestContext;
import com.rbccm.taf.ui.support.UserProvider;
import com.rbccm.taf.ui.testng.TestNGBase;
import datainstiller.generators.WordGenerator;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.assertj.core.api.Assertions;
import org.testng.annotations.Factory;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.Allure;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.Step;
import ru.yandex.qatools.allure.events.TestCaseEvent;
import ru.yandex.qatools.allure.model.Label;
import ru.yandex.qatools.allure.model.LabelName;
import ru.yandex.qatools.allure.model.SeverityLevel;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

public class TORC_ADP_TEX_Code_DM_Test extends TestNGBase {
    private DataTEX data;
    private String random;

    private TORC_ADP_TEX_Code_DM_Test(){}
    private TORC_ADP_TEX_Code_DM_Test(DataTEX data, String random) {
        this.data = data;
        this.random = random;
    }

    @Factory
    public Object[] test() throws IOException, InvalidFormatException {
        String random = new WordGenerator().generate("{A}{B}");
        String doc = "data/torc/api/FACT TESTING ADP Section Solution V0.10.xlsx";
        Workbook workbook = WorkbookFactory.create(this.getClass().getClassLoader().getResourceAsStream(doc));
        Sheet sheet = workbook.getSheet("TEX Code DM");
        AtomicBoolean isFirstRow = new AtomicBoolean(true);
        List<TORC_ADP_TEX_Code_DM_Test> table = new ArrayList<>();
        List<String> keys = new ArrayList<>();
        sheet.forEach(row -> {
            AtomicInteger i = new AtomicInteger();
            Map<String,String> tableRow = new HashMap<>();
            row.forEach(cell -> {
                cell.setCellType(CellType.STRING);
                String value = cell.getStringCellValue();
                if (isFirstRow.get()) {
                    value = "_" + value.replace(" ","").replace("-","_").replace("(","_").replace(")","_").toLowerCase();
                    keys.add(i.getAndIncrement(), value);
                } else {
                    tableRow.put(keys.get(i.getAndIncrement()), value);
                }
            });
            if (isFirstRow.get()) {
                isFirstRow.set(false);
            } else {
                if (tableRow.keySet().size() == keys.size()) {
                    DataTEX dataTEX = new DataTEX(tableRow);
                    table.add(new TORC_ADP_TEX_Code_DM_Test(dataTEX, random));
                    //////For data generation
                    //////String filePath = System.getProperty("user.dir") + "/src/main/resources/data/torc/api/adp_tex/data_" + dataTEX.get_srno() + ".xml";
                    //////dataTEX.toFile(filePath);
                }
            }
        });
        return table.toArray();
    }

    @Features("ADP Section Solution")
    @Severity(SeverityLevel.CRITICAL)
    @Test
    public void testTEX_Code_DM() throws IOException {
        //data = new DataTEX().fromResource("data/torc/api/adp_tex/data_54.xml");

        String currDate = DateTimeFormatter.ofPattern("dd/MM/yyyy").format(LocalDateTime.now());
        String timestamp = DateTimeFormatter.ofPattern("yyMMddkkmmss").format(LocalDateTime.now()) + Thread.currentThread().getId();

        String srNum = String.format("%03d", Integer.parseInt(data.get_srno()));
        Allure.LIFECYCLE.fire((TestCaseEvent) context -> {
            context.getLabels().add(new Label().withName(LabelName.STORY.value())
                    .withValue("Validate ADP Section Solution for " + "TEX Code DM"));
            context.setName("TEX" + "-" + srNum);
        });

        EnvironmentsSetup.Environment env = TestContext.getTestProperties().getTestEnvironment();
        String urlBase = (System.getenv().containsKey("TORC_URL")) ? System.getenv("TORC_URL") : env.getUrl();
        EnvironmentsSetup.User user = UserProvider.getInstance().getUser("user");
        TORCSession session = new TORCSession(urlBase, user.getUserName(), user.getPassword());
        T2Counterparty counterparty = T2Counterparty.create(session, "TEX_" + random + "_" + srNum  + "_" + timestamp, "autotest@yahoo.com");

        T2_ADP_Agreement agreements = T2_ADP_Agreement.create(session, counterparty.getId(), agreement -> {
            agreement.set("$[0].clientBookingPoint.identifier", counterparty.getId() +"_CA");
            agreement.set("$[0].shortCode", timestamp);
            agreement.set("$[0].createDate", currDate);
            agreement.set("$[0].dateOpened", currDate);
            agreement.set("$[0].identifiedDate", currDate);
            return agreement;
        });

        T2Task task = T2Task.get(session, agreements.getTaskId()).assignToCurrentUser(session);

        T2_Tax_Form form = T2_Tax_Form.get(session, data.get_taxformtype(), data.get_version());

        final T2_FedTaxClass fedTaxClass;

        if (form.getFormName().equals("W9")) {
            fedTaxClass = T2_FedTaxClass.get(session, data.get_federaltaxclassification());
        } else {
            fedTaxClass = null;
        }

        T2CRV crv = T2CRV.get(session, task);
        crv = crv.execute(session, newCrv -> {

            newCrv.set("$.obligationDocumentation.W_FORM.@class", form.getFormClass());
            newCrv.set("$.obligationDocumentation.W_FORM.formType", form.getFormName());
            newCrv.put("$.obligationDocumentation.W_FORM", "formVersion", form.getId());
            newCrv.put("$.obligationDocumentation.W_FORM", "taxFormName", form.getFormName());

            //No form is selected
            if (form.getFormName().equals("NoForm")) {
                boolean selectIndicia = false;
                if (data.get_ch3standardsofknowledge().contains("(Non-US Indicia)")) {
                    newCrv.put("$.obligationDocumentation.CRS", "countryOfIncorporation", "CA");
                    selectIndicia = true;
                }
                if (data.get_ch3standardsofknowledge().contains("(US Indicia)") || data.get_ch4standardsofknowledge().contains("US Indicia")) {
                    newCrv.put("$.obligationDocumentation.CRS", "countryOfIncorporation", "US");
                    selectIndicia = true;
                }
                if (selectIndicia) {
                    newCrv.put("$.obligationDocumentation.CRS", "active", true);
                    Object address = JsonPath.parse("{'addressType':'PERMANENT','isMailingDifferent':false,'country':'AF'}").read("$");
                    newCrv.add("$.obligationDocumentation.CRS.addresses", address);
                }

                return newCrv;
            }

            newCrv.set("$.obligationDocumentation.W_FORM.ch3Complete", data.get_documentationstatusch3().contains("Complete"));
            newCrv.set("$.obligationDocumentation.W_FORM.ch4Complete", data.get_documentationstatusch4().contains("Complete"));

            if (form.getFormName().equals("W9")) {
                newCrv.put("$.obligationDocumentation.W_FORM","federalTaxClassification", fedTaxClass.id);
                newCrv.put("$.obligationDocumentation.W_FORM","sin","123456789");
                return newCrv;
            }

            if (form.getFormName().equals("W8EXP")) {
                if (data.get_chapter3status().contains("Foreign government")) {
                    newCrv.put("$.obligationDocumentation.W_FORM", "entityType", "Foreign_Government");
                }

                if (data.get_10a().contains("Yes")) {
                    newCrv.put("$.obligationDocumentation.W_FORM", "isSec10aCheckBox" , true);
                }

                if (data.get_10b().contains("Yes")) {
                    newCrv.put("$.obligationDocumentation.W_FORM", "isSec10bCheckBox" , true);
                    newCrv.put("$.obligationDocumentation.W_FORM", "isSec10bTextBox" , "AF");
                }

                if (data.get_10c().contains("Yes")) {
                    newCrv.put("$.obligationDocumentation.W_FORM", "isSec10cCheckBox" , true);
                    newCrv.put("$.obligationDocumentation.W_FORM", "isSec10cTextBox" , "AF");
                }
            }

            if (form.getFormName().equals("W8IMY")) {
                switch (data.get_chapter3status()) {
                    case "Nonqualified intermediary" :
                        newCrv.put("$.obligationDocumentation.W_FORM","ch3Status","Ch3Status_2");
                        break;
                    case "Nonwithholding foreign grantor trust" :
                        newCrv.put("$.obligationDocumentation.W_FORM","ch3Status","Ch3Status_9");
                        break;
                    case "Nonwithholding foreign partnership" :
                        newCrv.put("$.obligationDocumentation.W_FORM","ch3Status","Ch3Status_7");
                        break;
                    case "Nonwithholding foreign simple trust" :
                        newCrv.put("$.obligationDocumentation.W_FORM","ch3Status","Ch3Status_8");
                        break;
                }

                boolean _19_21a = data.get_19a().toLowerCase().contains("yes") || data.get_21a().toLowerCase().contains("yes") ;
                boolean _19_21b = data.get_19b().toLowerCase().contains("yes") || data.get_21b().toLowerCase().contains("yes") ;
                if ( _19_21a || _19_21b ) {
                    Map<String,Boolean> values = new HashMap<>();
                    values.put("ENTITY_PAYMENT_NOT_FROM_WS", _19_21a);
                    values.put("ENTITY_IS_FOREIGN_PARTNERSHIP_IN_LOWER_TIER", _19_21b);
                    newCrv.put("$.obligationDocumentation.W_FORM", "nonWithholdingForeignPartnerships" , values);
                }

                boolean _15a = data.get_15a().toLowerCase().contains("yes");
                boolean _17a = data.get_17a().toLowerCase().contains("yes");
                boolean _15_17b = data.get_15b().toLowerCase().contains("yes") || data.get_17b().toLowerCase().contains("yes");
                if ( _15a || _17a || _15_17b ) {
                    Map<String,Boolean> values = new HashMap<>();
                    if (_15a) values.put("NQI_NOT_ACTING_CAPACITY", _15a);
                    if (_17a) values.put("NQI_NOT_ACTING_CAPACITY_V2", _17a);
                    values.put("NQI_PROVIDE_WS", _15_17b);
                    newCrv.put("$.obligationDocumentation.W_FORM", "nonQualifiedIntermediaries" , values);
                }

                newCrv.put("$.obligationDocumentation.W_FORM", "benAddresses", new ArrayList<>());
                newCrv.put("$.obligationDocumentation.W_FORM", "uboRecords", new ArrayList<>());
                newCrv.put("$.obligationDocumentation.W_FORM", "tinTypes", new HashMap<>());
                newCrv.put("$.obligationDocumentation.W_FORM", "usIdentificationNumber", "");
                newCrv.put("$.obligationDocumentation.W_FORM", "formCompleteDisabledForGiin", false);
                newCrv.put("$.obligationDocumentation.W_FORM", "validationFlagForGiin", false);
                newCrv.delete("$.obligationDocumentation.W_FORM.specialRates");
            }

            Object address = JsonPath.parse("{'addressType':'PERMANENT','isMailingDifferent':false}").read("$");
            newCrv.add("$.obligationDocumentation.W_FORM.addresses", address);

            String ch3sok = data.get_ch3standardsofknowledge();
            String ch4sok = data.get_ch4standardsofknowledge();
            boolean usIndicia = ch3sok.contains("(US Indicia)") || ch4sok.contains("(US Indicia)");
            boolean nonUsIndicia = ch3sok.contains("(Non-US Indicia)") || ch4sok.contains("(Non-US Indicia)");
            if (usIndicia || nonUsIndicia) {
                if (usIndicia) {
                    newCrv.put("$.obligationDocumentation.W_FORM.addresses[0]", "country", "US");
                } else {
                    newCrv.put("$.obligationDocumentation.W_FORM.addresses[0]", "country", "AF");
                }
                newCrv.set("$.obligationDocumentation.W_FORM.addresses[0].isMailingDifferent", true);
                Object mailing = JsonPath.parse("{'addressType':'MAILING','country':'AL'}").read("$");
                newCrv.add("$.obligationDocumentation.W_FORM.addresses", mailing);
            }



            newCrv.put("$.obligationDocumentation.W_FORM", "permanentAddress", new ArrayList<>());
            newCrv.put("$.obligationDocumentation.W_FORM", "mailingAddress", new ArrayList<>());
            newCrv.put("$.obligationDocumentation.W_FORM", "specialRates", new ArrayList<>());



            if (data.get_treatyselected().equals("Yes")) {
                Object treatyRates = JsonPath.parse("[{'incomeType':'Dividends','rate':15}," +
                        "{'incomeType':'Interest','rate':0},{'incomeType':'Dividend Equivalent Payments(871m)'," +
                        "'rate':15},{'incomeType':'Other'}]").read("$");
                newCrv.put("$.obligationDocumentation.W_FORM", "treatyRates", treatyRates);
                newCrv.put("$.obligationDocumentation.W_FORM", "treatyCountryOfResidence", "CA");
            }

            return newCrv;
        });

        T2Summary summary = T2Summary.get(session, crv);
        validate(summary, data.get_texcode());
        session.end();
    }


    @Step( "Validating Summary Report for TEX Code is {1}")
    private void validate(T2Summary summary, String adpTexCode) {
        summary.attachToReport();
        Assertions.assertThat(summary.getProperty("$.adpSummary")).withFailMessage("The Result is Blank for " + data.get_srno()).contains("texCode");
        Assertions.assertThat(summary.getTEXCode()).as("TEX Code for " + data.get_srno()).isEqualTo(adpTexCode);
    }


}
