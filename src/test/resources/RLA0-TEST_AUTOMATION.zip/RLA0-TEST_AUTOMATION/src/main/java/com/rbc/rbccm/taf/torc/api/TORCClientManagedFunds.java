package com.rbc.rbccm.taf.torc.api;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.rbccm.torc.model.ManagedFundFlatRecord;
import com.rbccm.torc.model.client.ManagedFundStatus;
import org.jsoup.Connection;
import java.io.IOException;

@SuppressWarnings({"unused","WeakerAccess"})
public class TORCClientManagedFunds extends TORCGenericRequest {

    private TORCClientManagedFunds(String json, long executionTime) {
        super(json, executionTime);
    }

    private static Connection getConnection(TORCSession session, String clientId) throws IOException {
        Connection con = session.getConnection("/api/clients/" + clientId + "/managedfundssearch");
        con.method(Connection.Method.POST);
        con.data("take","15");
        con.data("skip","0");
        con.data("page","1");
        con.data("pageSize","15");
        return con;
    }

    public static TORCClientManagedFunds post(TORCSession session, String clientId) throws IOException {
        Connection con = getConnection(session, clientId);
        return execute(con, TORCClientManagedFunds.class);
    }

    public static TORCClientManagedFunds put(TORCSession session, String clientId, String payload) throws IOException {
        Connection con = session.getConnection("/api/clients/" + clientId + "/managedfunds");
        con.method(Connection.Method.PUT);
        con.header("Content-Type","application/json;charset=UTF-8");
        con.requestBody(payload);
        return execute(con, TORCClientManagedFunds.class);
    }

    public static TORCClientManagedFunds getWithFilterLegalName(TORCSession session, String clientId, String legalname) throws IOException {
        Connection con = getConnection(session, clientId);
        con.data("filter[logic]", "and");
        con.data("filter[filters][0][field]", "legalName");
        con.data("filter[filters][0][operator]", "startswith");
        con.data("filter[filters][0][value]", legalname);
        return execute(con, TORCClientManagedFunds.class);
    }

    public ManagedFundFlatRecord[] getEntities() throws IOException {
        ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        mapper.registerModule(new SimpleModule().addDeserializer(ManagedFundStatus.class,  new ManagedFundStatusDeserializer()));
        TORCDataWrapper<ManagedFundFlatRecord> funds = mapper.readValue(getJson(), new TypeReference<TORCDataWrapper<ManagedFundFlatRecord>>(){});
        return funds.data;
    }

    private class ManagedFundStatusDeserializer extends StdDeserializer<ManagedFundStatus> {

        public ManagedFundStatusDeserializer() {
            this(null);
        }

        public ManagedFundStatusDeserializer(Class<?> clss) {
            super(clss);
        }

        @Override
        public ManagedFundStatus deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
            JsonNode node = p.getCodec().readTree(p);
            for (ManagedFundStatus status : ManagedFundStatus.values()) {
                if (status.getLabel().equals(node.asText())) {
                    return status;
                }
            }
            return null;
        }
    }

}
