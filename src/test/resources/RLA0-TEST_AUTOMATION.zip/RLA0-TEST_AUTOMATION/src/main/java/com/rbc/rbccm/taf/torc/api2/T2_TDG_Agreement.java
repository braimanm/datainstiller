package com.rbc.rbccm.taf.torc.api2;

import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.rbc.rbccm.taf.torc.api.TORCGenericRequest;
import com.rbc.rbccm.taf.torc.api.TORCSession;
import ru.yandex.qatools.allure.annotations.Step;

import java.io.IOException;
import java.util.List;
import java.util.function.Function;

public class T2_TDG_Agreement extends T2Entity {

    private static final String payloadForCreate = "[  " +
            "  {  " +
            "    \"rbcBookingPoints\": [  " +
            "      {  " +
            "        \"name\": \"RBC USA Holdco Corporation\",  " +
            "        \"igaStatus\": \"NA\",  " +
            "        \"qiStatus\": \"Non_QI\",  " +
            "        \"qddStatus\": \"Non_QDD\",  " +
            "        \"identifier\": \"undefined_undefined\"  " +
            "      }  " +
            "    ],  " +
            "    \"clientBookingPoints\": [  " +
            "      {  " +
            "        \"cdrId\": \"\",  " +
            "        \"gid\": \"\",  " +
            "        \"city\": \"Winnipeg\",  " +
            "        \"jurisdiction\": \"CA\",  " +
            "      }  " +
            "    ],  " +
            "    \"beneficiaryBookingPoints\": [],  " +
            "    \"payeeUSSourceFlag\": false,  " +
            "    \"csaApplicabilityFlag\": false,  " +
            "    \"requestType\": \"TDG\",  " +
            "    \"productType\": \"\",  " +
            "    \"dirty\": true,  " +
            "    \"type\": \"FEOMA\",  " +
            "    \"agreementClass\": \"DERIV\",  " +
            "    \"triPartyFlag\": \"NO\",  " +
            "    \"status\": \"PENDING\",  " +
            "    \"requestPriority\": \"STANDARD\",  " +
            "    \"contactInformation\": {  " +
            "      \"name\": \"Test Automation\",  " +
            "      \"contactInfoType\": \"AGREEMENT\"  " +
            "    },  " +
            "    \"emailDate\": \"24/04/2018\",  " +
            "    \"rbcLegalEntity\": \"RBC USA Holdco Corporation \",  " +
            "    \"isda871mLanguageFlag\": false,  " +
            "    \"isdaFatcaLanguageFlag\": false,  " +
            "    \"linkedAgreementIds\": []  " +
            "  }  " +
            "]";


    private T2_TDG_Agreement(String json) {
        super(json);
    }


    private static void setUniqueJurisdictionCity(TORCSession session, String clientId, DocumentContext context) throws IOException {
        String jurisdiction = context.read("$[0].clientBookingPoints[0].jurisdiction", String.class).trim();
        String city = context.read("$[0].clientBookingPoints[0].city", String.class).trim();
        String finalCity = city;
        boolean exists;
        do {
            String endPoint = "/api/client/clientCityJurisdictionDuplicateCheck/client/" + clientId + "/city/" + finalCity + "/jurisdiction/" + jurisdiction;
            TORCGenericRequest request = TORCGenericRequest.genericGet(session, endPoint);
            exists = request.getJson().contains("true");
            if (exists) {
                String numeric = finalCity.replaceAll("\\D+", "");
                finalCity = city + (numeric.isEmpty() ? 1 : Integer.parseInt(numeric) + 1);
            }
        } while (exists);
        context.set("$[0].clientBookingPoints[0].city", finalCity);
    }

    private static DocumentContext getAgreementsAndAccounts(TORCSession session, String clientId) throws IOException {
        DocumentContext doc = JsonPath.parse(get(session, clientId).getJson());
        List list = doc.read("$");
        for (int i =0 ; i < list.size(); i++ ) {
            List<String> taskIds = doc.read("$[" + i + "].tasks");
            doc.put("$[" + i + "]", "taskIds", taskIds);
            doc.put("$[" + i + "]", "cancelled", 0);
        }
        return doc;
    }

    public static T2_TDG_Agreement get(TORCSession session, String clientId) throws IOException {
        String endPoint = "/api/clients/" + clientId + "/agreementsandaccounts";
        TORCGenericRequest request = TORCGenericRequest.genericGet(session, endPoint);
        return new T2_TDG_Agreement(request.getJson());
    }

    @Step("Create Agreement for Counterparty Id: {1}")
    public static T2_TDG_Agreement create(TORCSession session, String clientId, Function<DocumentContext, DocumentContext> modifyPayload) throws IOException {
        DocumentContext agreements = getAgreementsAndAccounts(session, clientId);
        String endPoint = "/api/clients/" + clientId + "/agreementsandaccounts";
        DocumentContext currData = modifyPayload.apply(JsonPath.parse(payloadForCreate));
        setUniqueJurisdictionCity(session, clientId, currData);
        agreements.add("$", currData.read("$[0]"));
        TORCGenericRequest request = TORCGenericRequest.genericPut(session, endPoint, agreements.jsonString());
        return new T2_TDG_Agreement(request.getJson());
    }

    public String getTaskId(){
        return getProperty("$[0].tasks[0]");
    }

    public String getAgreementId() {
        return getProperty("$[0].id");
    }
}
