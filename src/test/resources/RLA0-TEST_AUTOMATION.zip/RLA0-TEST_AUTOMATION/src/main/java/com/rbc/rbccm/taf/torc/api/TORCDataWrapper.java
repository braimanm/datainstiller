package com.rbc.rbccm.taf.torc.api;

@SuppressWarnings("unused")
public class TORCDataWrapper<T> {
    public T[] data;
    public long total;
}
