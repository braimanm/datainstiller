package com.rbc.rbccm.taf.torc.api;

import org.jsoup.Connection;

import java.io.IOException;

public class TORCBeneficiaryBookingPoints extends TORCGenericRequest{

    private TORCBeneficiaryBookingPoints(String json, long executionTime) {
        super(json, executionTime);
    }

    public static TORCBeneficiaryBookingPoints get(TORCSession session) throws IOException {
        Connection con = session.getConnection("/api/beneficiarybookingpoints");
        con.method(Connection.Method.GET);
        return execute(con, TORCBeneficiaryBookingPoints.class);
    }

}
