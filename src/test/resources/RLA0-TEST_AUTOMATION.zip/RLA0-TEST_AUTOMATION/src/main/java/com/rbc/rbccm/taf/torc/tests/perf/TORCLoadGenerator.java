package com.rbc.rbccm.taf.torc.tests.perf;


import com.rbc.rbccm.taf.torc.domainobjects.PerfDOM;
import com.rbccm.taf.ui.support.EnvironmentsSetup;
import com.rbccm.taf.ui.support.TestContext;
import com.rbccm.taf.ui.testng.TestNGBase;
import org.assertj.core.api.Assertions;
import org.testng.ITestContext;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.Step;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

public class TORCLoadGenerator extends TestNGBase {

    private void setUser(String role) {
        EnvironmentsSetup.User user = TestContext.getTestProperties().getTestEnvironment().getUser(role);
        TestContext.getGlobalAliases().put("user-name", user.getUserName());
        TestContext.getGlobalAliases().put("user-password", user.getPassword());
    }

    @Step("Execute task with user {0}")
    private String createTask(String user, AtomicInteger countExceptions) {
        setUser(user);
        PerfDOM perf = new PerfDOM().fromResource("data/torc/perf/perf_data1.xml");
        try {
            perf.executeRandomTest();
        } catch (Exception e) {
            e.printStackTrace();
            countExceptions.incrementAndGet();
        }
        return user;
    }

    @Parameters({"perf-data-set","load-threads"})
    @Test
    public void generateLoad(@Optional("data/torc/perf/perf_data1.xml") String dataSet,
                             @Optional("40") int threadsCount, ITestContext contex) throws InterruptedException, ExecutionException {
        if (System.getenv().containsKey("LOAD_USERS")) {
            threadsCount = Integer.parseInt(System.getenv("LOAD_USERS"));
        }
        if (threadsCount == 0) return;
        ThreadPoolExecutor pool = (ThreadPoolExecutor) Executors.newFixedThreadPool(threadsCount);
        List<Future<String>> taskList = new ArrayList<>();
        AtomicInteger countExceptions = new AtomicInteger();
        for (int i = 0; i < threadsCount; i++) {
            String user = "load" + i;
            taskList.add(pool.submit(() -> createTask(user, countExceptions)));
        }

        while (true){
            if (contex.getAttributeNames().contains("test-done")) {
                pool.shutdown();
                if (!pool.awaitTermination(60, TimeUnit.SECONDS)) {
                    pool.shutdownNow();
                    Thread.currentThread().interrupt();
                }
                break;
            }
            for (int i =0; i < taskList.size(); i++) {
                Future<String> future = taskList.get(i);
                if (future.isDone()) {
                    String user = future.get();
                    Future<String> anotherTask = pool.submit(() -> createTask(user, countExceptions));
                    taskList.remove(i);
                    taskList.add(anotherTask);
                }
            }
            System.out.println("Active users :" + pool.getActiveCount());
            TimeUnit.SECONDS.sleep(1);
        }

        //Allure.LIFECYCLE.fire(new RemoveAttachmentsEvent(".+xml"));
        Assertions.assertThat(countExceptions).hasValue(0);
    }

}
