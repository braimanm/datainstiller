package com.rbc.rbccm.taf.torc.api2;

import com.fasterxml.jackson.core.type.TypeReference;
import com.rbc.rbccm.taf.torc.api.TORCGenericRequest;
import com.rbc.rbccm.taf.torc.api.TORCSession;

import java.io.IOException;
import java.util.List;

public class T2_CH4_FATCA_Status {
    public final String id = null;
    public final String label = null;
    public final MoreProperties additionalProperties = null;

    public static class MoreProperties{
        public List<String> versions;
    }

    private static T2_CH4_FATCA_Status getStstus(TORCSession session, String endPoint, String description) throws IOException {
        TORCGenericRequest req = TORCGenericRequest.genericGet(session, endPoint);
        TypeReference ref = new TypeReference<List<T2_CH4_FATCA_Status>>() {};
        for (T2_CH4_FATCA_Status status : (List<T2_CH4_FATCA_Status>) req.getEntity(ref)) {
            if (status.label.replaceAll("\\W","").startsWith(description.replaceAll("\\W",""))) {
                return status;
            }
        }
        return null;
    }

    public static T2_CH4_FATCA_Status getFATCAStatus(TORCSession session, String formName, String description) throws IOException {
        if (formName.equals("W8BEN") || formName.equals("W9")) return null;
        return getStstus(session, "/api/" + formName.toLowerCase() + "ch4statuses", description );
    }

    public static T2_CH4_FATCA_Status getDisregardedStatus(TORCSession session, String formName, String description) throws IOException {
        if (formName.equals("W8EXP") || formName.equals("W8BEN") || formName.equals("W9")) return null;
        if (formName.equals("W8IMY")) {
            return getStstus(session, "/api/w8imych4fatcastatuses", description);
        }
        return getStstus(session, "/api/" + formName.toLowerCase() + "ch4disregardentitystatuses", description );
    }


}
