package com.rbc.rbccm.taf.torc.api2;

import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.rbc.rbccm.taf.torc.api.TORCGenericRequest;
import com.rbc.rbccm.taf.torc.api.TORCSession;
import ru.yandex.qatools.allure.annotations.Step;

import java.io.IOException;
import java.util.function.Function;

public class T2_ADP_Agreement extends T2Entity {

    private static final String payload ="[\n" +
            "  {\n" +
            "    \"rbcBookingPoints\": [],\n" +
            "    \"clientBookingPoints\": [],\n" +
            "    \"beneficiaryBookingPoints\": [],\n" +
            "    \"payeeUSSourceFlag\": false,\n" +
            "    \"csaApplicabilityFlag\": false,\n" +
            "    \"requestType\": \"ADP_BFS\",\n" +
            "    \"productType\": \"Custody\",\n" +
            "    \"dirty\": true,\n" +
            "    \"rbcBookingPoint\": {\n" +
            "      \"qiStatus\": \"Non_QI\",\n" +
            "      \"qddStatus\": \"Non_QDD\",\n" +
            "      \"name\": \"ROYAL BANK OF CANADA (Toronto - Branch)\",\n" +
            "      \"igaStatus\": \"IGA\",\n" +
            "      \"identifier\": \"undefined_undefined\"\n" +
            "    },\n" +
            "    \"clientBookingPoint\": {\n" +
            "      \"cdrId\": \"\",\n" +
            "      \"gid\": \"\",\n" +
            "      \"city\": \"Toronto\",\n" +
            "      \"jurisdiction\": \"CA\",\n" +
            "      \"identifier\": \"${ID}_CA\"\n" +
            "    },\n" +
            "    \"createDate\": \"${DATE}\",\n" +
            "    \"financialAccount\": true,\n" +
            "    \"rbcBookingSystem\": \"ADP\",\n" +
            "    \"rbcBookingSystemInstance\": \"CAN\",\n" +
            "    \"adpAccountNumberRange\": \"Not in Above Range\",\n" +
            "    \"adpAccountRangeName\": \"Not Available\",\n" +
            "    \"rbcCmRange\": \"NO\",\n" +
            "    \"scope\": \"No\",\n" +
            "    \"accountType\": \"N/A\",\n" +
            "    \"shortCode\": \"${SHORT_CODE}\",\n" +
            "    \"salesPersonContact\": {\n" +
            "      \"name\": \"Michael\",\n" +
            "      \"contactInfoType\": \"ACCOUNT\"\n" +
            "    },\n" +
            "    \"accountStatus\": \"OPEN\",\n" +
            "    \"dateOpened\": \"${DATE)\",\n" +
            "    \"identifiedDate\": \"${DATE}\",\n" +
            "    \"rbcLegalEntity\": \"ROYAL BANK OF CANADA\",\n" +
            "    \"type\": \"Non-Agreement\",\n" +
            "    \"crvType\": \"ACCOUNT\"\n" +
            "  }\n" +
            "]";

    private T2_ADP_Agreement(String json) {
        super(json);
    }

    @Step("Create Agreement for Counterparty Id: {1}")
    public static T2_ADP_Agreement create(TORCSession session, String clientId, Function<DocumentContext, DocumentContext> modifyPayload) throws IOException {
        String endPoint = "/api/clients/" + clientId + "/agreementsandaccounts";
        DocumentContext currData = modifyPayload.apply(JsonPath.parse(payload));
        TORCGenericRequest request = TORCGenericRequest.genericPut(session, endPoint, currData.jsonString());
        return new T2_ADP_Agreement(request.getJson());
    }

    public String getTaskId(){
        return getProperty("$[0].tasks[0]");
    }

}
