package com.rbc.rbccm.taf.torc.api2;

import com.rbc.rbccm.taf.torc.api.TORCGenericRequest;
import com.rbc.rbccm.taf.torc.api.TORCSession;

import java.io.IOException;

public class T2Summary extends T2Entity {

    private T2Summary(String json) {
        super(json);
    }

    public static T2Summary get(TORCSession session, T2CRV crv) throws IOException {
        StringBuilder endPoint = new StringBuilder("/api/clients/" + crv.getClientId());
        if (!crv.getAgreementId().equals("null")) {
            endPoint.append("/agreements/").append(crv.getAgreementId());
        } else {
            endPoint.append("/accounts/").append(crv.getAccountId());
        }
        endPoint.append("/clientbookingpoints/").append(crv.getClientBookingPointJurisdictionCode()).append("/summary");
        TORCGenericRequest request = TORCGenericRequest.genericGet(session, endPoint.toString());
        return new T2Summary(request.getJson());
    }

    public String getObligationDocumentationStatus() {
        return getProperty("$.obligations[0].obligationDocumentation.W_FORM.documentationStatus");
    }

    public String getObligationDocumentationStatusCh4() {
        return getProperty("$.obligations[0].obligationDocumentation.W_FORM.documentationStatusCh4");
    }

    public String getWithholdabilityStatusCh3() {
        return getProperty("$.obligations[0].obligationDocumentation.W_FORM.witholdabilityStatus");
    }

    public String getWithholdabilityStatusCh4() {
        return getProperty("$.obligations[0].obligationDocumentation.W_FORM.witholdabilityStatusCh4");
    }

    public String getWithholdingRateCh3() {
        return getProperty("$.obligations[0].obligationDocumentation.W_FORM.withholdingRateCh3") + "%";
    }

    public String getWithholdingRateCh4() {
        return getProperty("$.obligations[0].obligationDocumentation.W_FORM.withholdingRateCh4") + "%";
    }

    public String getAdpFatcaCode() {
        return getProperty("$.adpSummary.fatcaCode");
    }

    public String getAdpHolderType() {
        return getProperty("$.adpSummary.fatcaHolderType");
    }

    public String getAdpHolderSubType() {
        return getProperty("$.adpSummary.fatcaHolderSubType");
    }

    public void attachToReport() {
        attach(getJson(),"Summary Response");
    }

    public String getTEXCode() {
        return getProperty("$.adpSummary.texCode");
    }
}
