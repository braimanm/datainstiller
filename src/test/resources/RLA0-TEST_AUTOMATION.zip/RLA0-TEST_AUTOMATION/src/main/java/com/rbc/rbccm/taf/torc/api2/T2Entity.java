package com.rbc.rbccm.taf.torc.api2;

import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.JsonPath;
import org.apache.commons.io.IOUtils;
import ru.yandex.qatools.allure.annotations.Attachment;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

@SuppressWarnings("WeakerAccess")
public class T2Entity {
    protected Object document;
    protected String json;

    public T2Entity(String json) {
        this.json = json;
        document = Configuration.defaultConfiguration().jsonProvider().parse(json);
    }

    public T2Entity(InputStream jsonIS) throws IOException {
        this(IOUtils.toString(jsonIS, StandardCharsets.UTF_8));
    }

    @Attachment(value = "{1}", type = "application/json")
    byte[] attach(String json, String name) {
        return json.getBytes();
    }

    public String getProperty(String path) {
        return JsonPath.read(document, path) + "";
    }

    public String getJson() {
        return JsonUtils.prettify(json);
    }

}
