package com.rbc.rbccm.taf.torc.api2;


import com.rbccm.taf.ui.support.AliasedString;
import com.rbccm.taf.ui.support.DomainObjectModel;
import com.thoughtworks.xstream.annotations.XStreamAlias;

import java.util.Map;

@XStreamAlias("FACT-data")
public class DataFACT extends DomainObjectModel {
    private AliasedString _sn0;
    private AliasedString _ch3standardsofknowledge;
    private AliasedString _ch4standardsofknowledge;
    private AliasedString _taxformversion;
    private AliasedString _taxform;
    private AliasedString _documentationstatusch3;
    private AliasedString _documentationstatusch4;
    private AliasedString _beneficialownertype_w9only_;
    private AliasedString _federaltaxclassification_w9only_;
    private AliasedString _exemptionfromfatcareportingcode_w9only_;
    private AliasedString _disregardedentityorbranchreceivingpayment;
    private AliasedString _fatcastatus;
    private AliasedString _16a;
    private AliasedString _16b;
    private AliasedString _16c;
    private AliasedString _18a;
    private AliasedString _18b;
    private AliasedString _18c;
    private AliasedString _20a;
    private AliasedString _20b;
    private AliasedString _20c;
    private AliasedString _35a;
    private AliasedString _35b;
    private AliasedString _40a;
    private AliasedString _40b;
    private AliasedString _40c;
    private AliasedString _ben_e_37a;
    private AliasedString _ben_e_37b;
    private AliasedString _imy_37a;
    private AliasedString _imy_37b;
    private AliasedString _fatcaholdertypedescription;
    private AliasedString _fatcaholdertype;
    private AliasedString _fatcaholdersub_type;

    public DataFACT(){}
    public DataFACT(Map<String,String> tableRow){
        enumerateFields((data, field) -> {
            try {
                AliasedString value = new AliasedString();
                value.initializeData(tableRow.get(field.getName()), null, null);
                field.set(this, value);
            } catch (IllegalAccessException ignore) {}
        });
    }

    public String get_sn0() {
        return _sn0.getData();
    }

    public String get_ch3standardsofknowledge() {
        return _ch3standardsofknowledge.getData();
    }

    public String get_ch4standardsofknowledge() {
        return _ch4standardsofknowledge.getData();
    }

    public String get_taxformversion() {
        return _taxformversion.getData();
    }

    public String get_taxform() {
        return _taxform.getData();
    }

    public String get_documentationstatusch3() {
        return _documentationstatusch3.getData();
    }

    public String get_documentationstatusch4() {
        return _documentationstatusch4.getData();
    }

    public String get_beneficialownertype() {
        return _beneficialownertype_w9only_.getData();
    }

    public String get_federaltaxclassification() {
        return _federaltaxclassification_w9only_.getData();
    }

    public String get_exemptionfromfatcareportingcode() {
        return _exemptionfromfatcareportingcode_w9only_.getData();
    }

    public String get_disregardedentityorbranchreceivingpayment() {
        return _disregardedentityorbranchreceivingpayment.getData();
    }

    public String get_fatcastatus() {
        return _fatcastatus.getData();
    }

    public String get_16a() {
        return _16a.getData();
    }

    public String get_16b() {
        return _16b.getData();
    }

    public String get_16c() {
        return _16c.getData();
    }

    public String get_18a() {
        return _18a.getData();
    }

    public String get_18b() {
        return _18b.getData();
    }

    public String get_18c() {
        return _18c.getData();
    }

    public String get_20a() {
        return _20a.getData();
    }

    public String get_20b() {
        return _20b.getData();
    }

    public String get_20c() {
        return _20c.getData();
    }

    public String get_35a() {
        return _35a.getData();
    }

    public String get_35b() {
        return _35b.getData();
    }

    public String get_40a() {
        return _40a.getData();
    }

    public String get_40b() {
        return _40b.getData();
    }

    public String get_40c() {
        return _40c.getData();
    }

    public String get_ben_e_37a() {
        return _ben_e_37a.getData();
    }

    public String get_ben_e_37b() {
        return _ben_e_37b.getData();
    }

    public String get_imy_37a() {
        return _imy_37a.getData();
    }

    public String get_imy_37b() {
        return _imy_37b.getData();
    }

    public String get_fatcaholdertypedescription() {
        return _fatcaholdertypedescription.getData();
    }

    public String get_fatcaholdertype() {
        return _fatcaholdertype.getData();
    }

    public String get_fatcaholdersub_type() {
        return _fatcaholdersub_type.getData();
    }
}
