package com.rbc.rbccm.taf.torc.tests.api;

import com.rbc.rbccm.taf.torc.api.TORCSession;
import com.rbc.rbccm.taf.torc.api2.*;
import com.rbccm.taf.ui.support.EnvironmentsSetup;
import com.rbccm.taf.ui.support.TestContext;
import com.rbccm.taf.ui.support.UserProvider;
import com.rbccm.taf.ui.testng.TestNGBase;
import datainstiller.generators.WordGenerator;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.sshd.common.util.threads.ThreadUtils;
import org.assertj.core.api.SoftAssertions;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Factory;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.Allure;
import ru.yandex.qatools.allure.annotations.*;
import ru.yandex.qatools.allure.events.TestCaseEvent;
import ru.yandex.qatools.allure.model.SeverityLevel;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class TORCWithholdingDetermination_W9_Test extends TestNGBase {
    private DataW9 dataW9;
    private String random;


    TORCWithholdingDetermination_W9_Test() {}
    private TORCWithholdingDetermination_W9_Test(DataW9 dataW9, String random) {
        this.dataW9 = dataW9;
        this.random = random;
    }

    @Factory
    public Object[] factory() throws IOException, InvalidFormatException {
        String random = new WordGenerator().generate("{A}{B}");
        List<TORCWithholdingDetermination_W9_Test> results = new ArrayList<>();
        Workbook workbook = WorkbookFactory.create(this.getClass().getClassLoader().getResourceAsStream("data/torc/api/Sep 29_All Forms_Truth Tables_GB Changes V1.1.xlsx"));
        Sheet sheet = workbook.getSheet("W9");
        final int[] skip = {2};
        sheet.forEach(row -> {
            StringBuilder rowB = new StringBuilder();
            row.forEach(cell -> {
                cell.setCellType(CellType.STRING);
                String cellValue = cell.getStringCellValue();
                rowB.append(cellValue).append("\t");
            });
            String[] data = rowB.toString().trim().split("\t");
            if (data.length > 5) {
                if (skip[0] == 0 ) {
                    if (!data[2].contains("Non-IGA")) { //Skip all Non-IGA rows
                        DataW9 dataW9 = new DataW9(data);
                        //////For data generation
                        //////String path = System.getProperty("user.dir") + "/src/main/resources/data/torc/api/w9/";
                        //////dataW9.toFile(path + "data_" + data[0] + ".xml");
                        results.add(new TORCWithholdingDetermination_W9_Test(dataW9, random));
                    }
                } else {
                    skip[0]--;
                }
            }
        });
        return results.toArray();
    }

    @Description("Withholding Determination (Form W-9)")
    @Features("Withholding Determination")
    @Stories("Validate Decision Model for W-9 Form")
    @Severity(SeverityLevel.CRITICAL)
    @Test
    public void w9() throws IOException {
        ///////dataW9 = new DataW9().fromResource("data/torc/api/w9/data_178.xml"); //For debugging

        String srNum = String.format("%03d", Integer.parseInt(dataW9.getSrNo()));
        Allure.LIFECYCLE.fire((TestCaseEvent) context -> context.setName("W-9-" + srNum));

        attachDataSet(dataW9, "W9_Data_" + srNum);
        DataW9.Condition condition = dataW9.getCondition();
        DataW9.Conclusion conclusion = dataW9.getConclusion();

        EnvironmentsSetup.Environment env = TestContext.getTestProperties().getTestEnvironment();
        String urlBase = (System.getenv().containsKey("TORC_URL")) ? System.getenv("TORC_URL") : env.getUrl();

        EnvironmentsSetup.User user = UserProvider.getInstance().getUser("user");

        TORCSession session = new TORCSession(urlBase, user.getUserName(), user.getPassword());

        String emailDate = DateTimeFormatter.ofPattern("dd/MM/yyyy").format(LocalDateTime.now());
        String timestamp = DateTimeFormatter.ofPattern("yyMMddkkmmss").format(LocalDateTime.now()) + Thread.currentThread().getId();

        T2Counterparty counterparty = T2Counterparty.create(session, "W9_" + random + "_" + srNum + "_" + timestamp, "autotest@yahoo.com");
        String id = counterparty.getId();

        T2RBCBookingPoints rbcBP = T2RBCBookingPoints.get(session);
        String rbcLegalEntity = rbcBP.getRbcLegalEntity(condition.getJurisdiction());
        String rbcBookingPoint = rbcBP.getRbcBookingPoint(condition.getJurisdiction());
        String igaStatus = rbcBP.getIGAStatus(condition.getJurisdiction());

        T2_TDG_Agreement agreements = T2_TDG_Agreement.create(session, id, agreement -> {
            agreement.set("$[0].emailDate", emailDate);
            agreement.put("$[0]", "comments", timestamp);
            agreement.set("$[0].rbcLegalEntity", rbcLegalEntity);
            agreement.set("$[0].rbcBookingPoints[0].name", rbcBookingPoint);
            agreement.set("$[0].rbcBookingPoints[0].qiStatus", condition.getQiStatus());
            agreement.set("$[0].rbcBookingPoints[0].igaStatus", igaStatus);
            return agreement;
        });

        T2Task task = T2Task.get(session, agreements.getTaskId());
        task = task.assignToCurrentUser(session);

        T2CRV crv = T2CRV.get(session, task);


        String formType = condition.getDocType();
        String beneficialOwnerType = condition.getAccountHolderType();
        boolean ch3Other = condition.getKnowledgeCH3();
        boolean ch4Other = condition.getKnowledgeCH4();
        boolean ch3Complete = condition.getObligationDocumentStatus();

        crv = crv.execute(session, newCrv -> {
            if (formType.equals("W9")) {
                newCrv.set("$.obligationDocumentation.W_FORM.@class", "com.rbccm.torc.model.form.W9Form");
                newCrv.set("$.obligationDocumentation.W_FORM.formType", formType);
                newCrv.put("$.obligationDocumentation.W_FORM", "formVersion", "W9Nov2017");
                newCrv.put("$.obligationDocumentation.W_FORM", "taxFormName", formType);
                newCrv.put("$.obligationDocumentation.W_FORM", "beneficialOwnerType", beneficialOwnerType);
                newCrv.put("$.obligationDocumentation.W_FORM", "sin", "12345679");
                newCrv.put("$.obligationDocumentation.W_FORM", "ch3Other", ch3Other);
                newCrv.put("$.obligationDocumentation.W_FORM", "ch4Other", ch4Other);
                newCrv.set("$.obligationDocumentation.W_FORM.ch3Complete", ch3Complete);
            }
            return newCrv;
        });

        T2Summary summary = T2Summary.get(session, crv);
        validate(summary, conclusion);
        session.end();

    }

    @Step( "Validating Conclusion")
    private void validate(T2Summary summary, DataW9.Conclusion conclusion) {
        summary.attachToReport();
        SoftAssertions.assertSoftly(softly -> {
            softly.assertThat(summary.getWithholdabilityStatusCh4()).as("Withholdability Status Ch4").isEqualTo(conclusion.getWithholdingStatusCh4());
            softly.assertThat(summary.getWithholdingRateCh4()).as("Withholding Rate Ch4").isEqualTo(conclusion.getWithholdingRateCh4());
            softly.assertThat(summary.getWithholdabilityStatusCh3()).as("Withholdability Status Ch3").isEqualTo(conclusion.getWithholdingStatusCh3());
            softly.assertThat(summary.getWithholdingRateCh3()).as("Withholding Rate Ch3").isEqualTo(conclusion.getWithholdingRateCh3());
        });
    }

}
