package com.rbc.rbccm.taf.torc.tests.api;

import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.rbc.rbccm.taf.torc.api.TORCSession;
import com.rbc.rbccm.taf.torc.api2.*;
import com.rbccm.taf.ui.testng.TestNGBase;
import org.apache.commons.io.IOUtils;

import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

public class GenericTest extends TestNGBase {

    protected void unzip(String outDir, String zipPath) throws IOException {
        try (ZipFile zipFile = new ZipFile(zipPath)) {
            Enumeration<? extends ZipEntry> entries = zipFile.entries();
            while (entries.hasMoreElements()) {
                ZipEntry entry = entries.nextElement();
                File entryDestination = new File(outDir,  entry.getName());
                if (entry.isDirectory()) {
                    entryDestination.mkdirs();
                } else {
                    entryDestination.getParentFile().mkdirs();
                    InputStream in = zipFile.getInputStream(entry);
                    OutputStream out = new FileOutputStream(entryDestination);
                    IOUtils.copy(in, out);
                    IOUtils.closeQuietly(in);
                    out.close();
                }
            }
        }
    }

    public T2CRV execute(TORCSession session, String legalName, String agreementFile, String crvFile ) throws IOException {

        String currDate = DateTimeFormatter.ofPattern("dd/MM/yyyy").format(LocalDateTime.now());

        InputStream agrIs = getClass().getClassLoader().getResourceAsStream(agreementFile);
        InputStream crvIs = getClass().getClassLoader().getResourceAsStream(crvFile);

        T2Counterparty counterparty = T2Counterparty.create(session, legalName, "autotest@yahoo.com");
        String clientId = counterparty.getId();
        System.out.println("Client ID: " + clientId);

        T2Agreement agreements = new T2Agreement(agrIs);
        agreements = agreements.create(session, clientId, agreement -> {
            String identifier = agreement.read("$[0].clientBookingPoints[0].identifier").toString().replace("${ID}",clientId);
            agreement.set("$[0].clientBookingPoints[0].identifier", identifier);
            agreement.set("$[0].emailDate", currDate);
            return agreement;
        });

        Integer agreementId = agreements.getId();
        System.out.println("Agreement ID: " + agreementId);

        T2Task task = T2Task.get(session, agreements.getTaskId());
        task = task.assignToCurrentUser(session);

        T2CRV crv = T2CRV.get(session, task);

        T2Entity entity = new T2Entity(crvIs);
        DocumentContext obl = JsonPath.parse((Object)JsonPath.read(entity.getJson(),"$.obligationDocumentation"));
        obl.set("$.FATCA.agreementId", agreementId);
        obl.set("$.CRS.agreementId", agreementId);
        obl.set("$.W_FORM.agreementId", agreementId);
        String json = obl.jsonString().replaceAll("\"id\":\\d*,","");
        json = json.replaceAll("\"createDate\":\"\\d{2}/\\d{2}/\\d{4}\",","");
        json = json.replaceAll("\"updateDate\":\"\\d{2}/\\d{2}/\\d{4}\",","");
        json = json.replaceAll("\"version\":\\d+,","");
        json = json.replaceAll("\"createdBy\":\"\\w+\",","");
        json = json.replaceAll("\"updatedBy\":\"\\w+\",","");
        final Object o = JsonPath.read(json,"$");

        crv = crv.execute(session, newCrv -> {
            newCrv.set("$.obligationDocumentation", o);
            return newCrv;
        });

        return crv;
    }

}
