package com.rbc.rbccm.taf.torc.api;
import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import ru.yandex.qatools.allure.annotations.Step;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

@SuppressWarnings("WeakerAccess")
public class TORCSession {
    private Map<String, String> cookies;
    private String urlBase;
    private String userName;
    private String password;

    private Connection initConnection(String url) {
        Connection con = Jsoup.connect(urlBase + url);
        con.timeout(180000);
        con.validateTLSCertificates(false);
        con.ignoreContentType(true);
        con.followRedirects(true);
        con.header("Accept", "application/json, text/plain, */*");
        con.header("Accept-Encoding", "gzip, deflate");
        con.header("Accept-Language", "en-US,en;q=0.8");
        con.header("Connection", "keep-alive");
        return con;
    }

    public TORCSession(String urlBase, String userName, String password) throws IOException {
        this.urlBase = urlBase;
        this.userName = userName;
        this.password = password;
        login(userName);
    }

    public TORCSession(String urlBase, String sessionId) {
        this.urlBase = urlBase;
        cookies = new HashMap<>();
        cookies.put("JSESSIONID", sessionId);
    }

    @Step("Login as {0}")
    private void login(String user) throws IOException {
        login();
    }

    private void login() throws IOException {
        Connection con = initConnection("/login");
        con.method(Connection.Method.POST);
        con.data("username", userName);
        con.data("password", password);
        con.data("submit", "Login");
        Connection.Response res = con.execute();
        cookies = res.cookies();
        System.out.println("JSESSIONID: " + cookies.get("JSESSIONID") + " USER: " + userName);
        Document doc = res.parse();
        String body = doc.body().text();
        if (!body.contains("TORC Loading")) {
            throw new RuntimeException("Login failed with message: " + body);
        }
    }

    public Connection getConnection(String endPoint) throws IOException {
        if (cookies == null) {
            login();
        }
        Connection con = initConnection(endPoint);
        con.cookies(cookies);
        return con;
    }

    public void end() throws IOException {
        if (cookies == null) return;
        Connection con = initConnection("/logout");
        con.cookies(cookies);
        con.followRedirects(true);
        con.method(Connection.Method.GET);
        con.execute();
        cookies = null;
    }

}
