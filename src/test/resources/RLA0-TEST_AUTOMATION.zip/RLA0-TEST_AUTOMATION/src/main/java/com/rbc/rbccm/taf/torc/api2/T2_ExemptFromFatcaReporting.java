package com.rbc.rbccm.taf.torc.api2;

import com.fasterxml.jackson.core.type.TypeReference;
import com.rbc.rbccm.taf.torc.api.TORCGenericRequest;
import com.rbc.rbccm.taf.torc.api.TORCSession;

import java.io.IOException;
import java.util.List;

@SuppressWarnings("unchecked")
public class T2_ExemptFromFatcaReporting {
    public final String id = null;
    public final String label = null;

    public static T2_ExemptFromFatcaReporting get(TORCSession session, String label) throws IOException {
        String endPoint = "/api/exemptfromfatcareportings";
        TORCGenericRequest req = TORCGenericRequest.genericGet(session, endPoint);
        TypeReference ref = new TypeReference<List<T2_ExemptFromFatcaReporting>>() {};
        for (T2_ExemptFromFatcaReporting item : (List<T2_ExemptFromFatcaReporting>) req.getEntity(ref)) {
            if (item.label.replaceAll("\\W","").equals(label.replaceAll("\\W",""))) return item;
        }
        return null;
    }
}
