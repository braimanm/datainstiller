package com.rbc.rbccm.taf.torc.api;


import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rbccm.torc.model.client.ManagedFund;
import org.jsoup.Connection;

import java.io.IOException;

public class TORCManagedFund extends TORCGenericRequest {

    private TORCManagedFund(String json, long executionTime) {
        super(json, executionTime);
    }

    public static TORCManagedFund get(TORCSession session, String clientId, String managedFundId) throws IOException {
        Connection con = session.getConnection("/api/clients/" + clientId + "/managedfunds/" + managedFundId);
        con.method(Connection.Method.GET);
        return execute(con, TORCManagedFund.class);
    }

    public static TORCManagedFund put(TORCSession session, String clientId, String payload) throws IOException {
        Connection con = session.getConnection("/api/clients/" + clientId + "/managedfunds");
        con.method(Connection.Method.PUT);
        con.header("Content-Type","application/json;charset=UTF-8");
        con.requestBody(payload);
        return execute(con, TORCManagedFund.class);
    }

    public ManagedFund getEntity() throws IOException {
        ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        return mapper.readValue(getJson(), ManagedFund.class);
    }


}
