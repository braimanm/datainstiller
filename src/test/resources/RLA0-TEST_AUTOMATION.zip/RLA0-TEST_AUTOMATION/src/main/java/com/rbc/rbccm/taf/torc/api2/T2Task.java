package com.rbc.rbccm.taf.torc.api2;

import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.rbc.rbccm.taf.torc.api.TORCGenericRequest;
import com.rbc.rbccm.taf.torc.api.TORCSession;
import ru.yandex.qatools.allure.annotations.Step;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@SuppressWarnings("WeakerAccess")
public class T2Task extends T2Entity {

    private T2Task(String json) {
        super(json);
    }

    private String getLoggedUser(TORCSession session) throws IOException {
        TORCGenericRequest request = TORCGenericRequest.genericGet(session, "/api/loggeduser");
        DocumentContext doc = JsonPath.parse(request.getJson());
        return doc.read("$.userName");
    }

    private String getMultipartBoundaryPayload(String payload, Map<String,String> headers) {
        String multipartBoundary = UUID.randomUUID().toString().replace("-","");
        String crlf ="\r\n";
        headers.put("Content-Type","multipart/form-data; boundary=" + multipartBoundary + "; charset=UTF-8");
        return  "--" + multipartBoundary + crlf +
                "Content-Disposition: form-data; name=\"parentSysTaskId\"" + crlf + crlf +
                "undefined" + crlf +
                "--" + multipartBoundary + crlf +
                "Content-Disposition: form-data; name=\"model\"" + crlf + crlf +
                payload + crlf +
                "--" + multipartBoundary + "--";
    }

    public static T2Task get(TORCSession session, String taskId) throws IOException {
        String endPoint = "/api/tasks/" + taskId;
        TORCGenericRequest request = TORCGenericRequest.genericGet(session, endPoint);
        return new T2Task(request.getJson());
    }

    @Step("Assign Task to Current user")
    public T2Task assignToCurrentUser(TORCSession session) throws IOException {
        String currentUser = getLoggedUser(session);
        DocumentContext doc = JsonPath.parse(document);
        doc.set("$.assignee", currentUser);
        doc.put("$", "$promise", true);
        doc.put("$", "$resolved", true);
        Map<String,String> headers = new HashMap<>();
        String payload = getMultipartBoundaryPayload(doc.jsonString(), headers);
        String taskId = doc.read("$.id");
        String endPoint = "/api/tasks/" + taskId;
        TORCGenericRequest request = TORCGenericRequest.genericPost(session, endPoint, headers, null, payload);
        return new T2Task(request.getJson());
    }

    public String getClientId() {
        return getProperty("$.clientId");
    }

    public String getAgreementId() {
        return getProperty("$.agreementId");
    }

    public String getAccountId() {
        return getProperty("$.accountId");
    }

    public String getClientBookingPoint() {
        return getProperty("$.clientBookingPoint");
    }
}
