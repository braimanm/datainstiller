package com.rbc.rbccm.taf.torc.tests.api;

import com.rbc.rbccm.taf.torc.api.TORCSession;
import com.rbc.rbccm.taf.torc.api2.*;
import com.rbccm.taf.ui.support.EnvironmentsSetup;
import com.rbccm.taf.ui.support.TestContext;
import com.rbccm.taf.ui.support.UserProvider;
import datainstiller.generators.WordGenerator;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.assertj.core.api.Assertions;
import org.testng.annotations.Factory;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.Allure;
import ru.yandex.qatools.allure.annotations.Step;
import ru.yandex.qatools.allure.events.TestCaseEvent;
import ru.yandex.qatools.allure.model.Label;
import ru.yandex.qatools.allure.model.LabelName;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

public class CRS_Rep_Status_Test extends GenericTest {
    private DataGeneric data;
    private String random;

    public CRS_Rep_Status_Test(){}
    public CRS_Rep_Status_Test(DataGeneric data, String random) {
        this.data = data;
        this.random = random;
    }

    @Factory
    public Object[] test() throws IOException, InvalidFormatException {
        String random = new WordGenerator().generate("{A}{B}");
        String doc = "data/torc/api/CRS_REP_Status/Reportability_Test.xlsx";
        Workbook workbook = WorkbookFactory.create(this.getClass().getClassLoader().getResourceAsStream(doc));
        Sheet sheet = workbook.getSheet("CRS");
        AtomicBoolean isFirstRow = new AtomicBoolean(true);
        List<CRS_Rep_Status_Test> table = new ArrayList<>();
        List<String> keys = new ArrayList<>();
        sheet.forEach(row -> {
            AtomicInteger i = new AtomicInteger();
            Map<String,String> tableRow = new HashMap<>();
            row.forEach(cell -> {
                cell.setCellType(CellType.STRING);
                String value = cell.getStringCellValue();
                if (isFirstRow.get()) {
                    value = "_" + value.replace(" ","").replace("-","_").replace("(","_").replace(")","_").toLowerCase();
                    keys.add(i.getAndIncrement(), value);
                } else {
                    tableRow.put(keys.get(i.getAndIncrement()), value);
                }
            });
            if (isFirstRow.get()) {
                isFirstRow.set(false);
            } else {
                if (tableRow.keySet().size() == keys.size()) {
                    DataGeneric dataGen = new DataGeneric(tableRow);
                    table.add(new CRS_Rep_Status_Test(dataGen, random));
                    //////For data generation
                    //////String filePath = System.getProperty("user.dir") + "/src/main/resources/data/torc/api/CRS_REP_Status/gen/data_" + dataGen.getSerNum() + ".xml";
                    //////dataGen.toFile(filePath);
                }
            }
        });
        return table.toArray();
    }

    @Test
    public void crs_test() throws IOException {
        //data = new DataTEX().fromResource("data/torc/api/CRS_REP_Status/gen/data_5.xml");

        String timestamp = DateTimeFormatter.ofPattern("yyMMddkkmmss").format(LocalDateTime.now()) + Thread.currentThread().getId();

        String srNum = String.format("%03d", Integer.parseInt(data.getSerNum()));
        Allure.LIFECYCLE.fire((TestCaseEvent) context -> {
            context.getLabels().add(new Label().withName(LabelName.STORY.value())
                    .withValue("Validate Reportability for CRS"));
            context.setName("CRS" + "-" + srNum);
        });
        attachDataSet(data,"Data");

        EnvironmentsSetup.Environment env = TestContext.getTestProperties().getTestEnvironment();
        String urlBase = (System.getenv().containsKey("TORC_URL")) ? System.getenv("TORC_URL") : env.getUrl();
        EnvironmentsSetup.User user = UserProvider.getInstance().getUser("user");
        TORCSession session = new TORCSession(urlBase, user.getUserName(), user.getPassword());

        String legalName = "CRS_" + random + "_" + srNum  + "_" + timestamp;
        String agreementFile = "data/torc/api/CRS_REP_Status/" + data.getAgreementFile();
        String crvFile = "data/torc/api/CRS_REP_Status/" + data.getCrvFile();
        T2CRV crv = execute(session, legalName, agreementFile, crvFile);

        T2Summary summary = T2Summary.get(session, crv);
        validate(summary, data.getExpectedResult());
        session.end();
    }

    @Step( "Validating Summary Report for CRS Reportability is {1}")
    private void validate(T2Summary summary, String crsRep) {
        summary.attachToReport();
        String status = summary.getProperty("$.obligations[0].obligationDocumentation.CRS.reportabilityStatus");
        String expected = data.getExpectedResult().toUpperCase().replace(" ","_");
        Assertions.assertThat(status).as("CRS Reportability for " + data.getSerNum()).isEqualTo(expected);
    }

}
