package com.rbc.rbccm.taf.torc.api2;

import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;

@SuppressWarnings("WeakerAccess")
public class JsonUtils {

    public static String prettify(String json) {
        if (json != null) {
            ObjectMapper mapper = new ObjectMapper();
            try {
                return mapper.writerWithDefaultPrettyPrinter().writeValueAsString(mapper.readValue(json, Object.class));
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
        return "";
    }
}
