package com.rbc.rbccm.taf.torc.api2;

import com.jayway.jsonpath.JsonPath;
import com.rbc.rbccm.taf.torc.api.TORCGenericRequest;
import com.rbc.rbccm.taf.torc.api.TORCSession;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class T2RBCBookingPoints extends T2Entity {
    private Map<String,Integer> jurisdictionDirectory;

    private void map() {
        jurisdictionDirectory = new HashMap<>();
        jurisdictionDirectory.put("*", 50);
        jurisdictionDirectory.put("US", 50);
        jurisdictionDirectory.put("Australia", 49);
        jurisdictionDirectory.put("Bahamas", 4);
        jurisdictionDirectory.put("Barbados", 5);
        jurisdictionDirectory.put("Canada", 8);
        jurisdictionDirectory.put("Cayman Islands", 38);
        jurisdictionDirectory.put("China", 12);
        jurisdictionDirectory.put("France", 13);
        jurisdictionDirectory.put("Guernsey", 11);
        jurisdictionDirectory.put("Hong Kong", 15);
        jurisdictionDirectory.put("Japan", 17);
        jurisdictionDirectory.put("Luxembourg", 40);
        jurisdictionDirectory.put("Netherlands", 45);
        jurisdictionDirectory.put("Singapore", 24);
        jurisdictionDirectory.put("United Kingdom", 19);
    }

    private T2RBCBookingPoints(String json) {
        super(json);
    }

    public static T2RBCBookingPoints get(TORCSession session) throws IOException {
        String endPoint = "/api/rbcbookingpoints";
        TORCGenericRequest request = TORCGenericRequest.genericGet(session, endPoint);
        T2RBCBookingPoints rbcBookingPoints = new T2RBCBookingPoints(request.getJson());
        rbcBookingPoints.map();
        return rbcBookingPoints;
    }

    public String getRbcLegalEntity(String country) {
        String i = jurisdictionDirectory.get(country) +"";
        List<String> res = JsonPath.read(document,"$.[?(@.additionalProperties.branchCode == '" + i + "')].parentId");
        return res.get(0);
    }

    public String getRbcBookingPoint(String country) {
        String i = jurisdictionDirectory.get(country) +"";
        List<String> res = JsonPath.read(document, "$.[?(@.additionalProperties.branchCode == '" + i + "')].id");
        return res.get(0);
    }

    public String getIGAStatus(String country) {
        String i = jurisdictionDirectory.get(country) +"";
        List<String> res = JsonPath.read(document, "$.[?(@.additionalProperties.branchCode == '" + i + "')].additionalProperties.igaStatus");
        return res.get(0);
    }


}
