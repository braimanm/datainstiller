package com.rbc.rbccm.taf.torc.api2;

import com.rbccm.taf.ui.support.AliasedString;
import com.rbccm.taf.ui.support.DomainObjectModel;

import java.util.Map;

public class DataGeneric extends DomainObjectModel {
    private AliasedString _srno;
    private AliasedString _agreement;
    private AliasedString _crv;
    private AliasedString _conclusion;


    public DataGeneric() {}
    public DataGeneric(Map<String, String> tableRow) {
        enumerateFields((data, field) -> {
            try {
                AliasedString value = new AliasedString();
                value.initializeData(tableRow.get(field.getName()), null, null);
                field.set(this, value);
            } catch (IllegalAccessException ignore) {
            }
        });
    }

    public String getSerNum() {
        return _srno.getData();
    }

    public String getAgreementFile() {
        return _agreement.getData();
    }

    public String getCrvFile() {
        return _crv.getData();
    }

    public String getExpectedResult() {
        return _conclusion.getData();
    }
}
