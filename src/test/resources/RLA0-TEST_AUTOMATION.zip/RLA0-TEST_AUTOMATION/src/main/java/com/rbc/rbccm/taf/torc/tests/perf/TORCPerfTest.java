package com.rbc.rbccm.taf.torc.tests.perf;

import com.rbc.rbccm.taf.torc.domainobjects.PerfDOM;
import com.rbccm.taf.ui.support.EnvironmentsSetup;
import com.rbccm.taf.ui.support.TestContext;
import com.rbccm.taf.ui.testng.TestNGBase;

import org.testng.ITestContext;
import org.testng.annotations.*;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.Stories;
import ru.yandex.qatools.allure.model.SeverityLevel;

import java.io.IOException;

public class TORCPerfTest extends TestNGBase {

    private void setUser(String role) {
        EnvironmentsSetup.User user = TestContext.getTestProperties().getTestEnvironment().getUser(role);
        TestContext.getGlobalAliases().put("user-name", user.getUserName());
        TestContext.getGlobalAliases().put("user-password", user.getPassword());
    }

    @Parameters("perf-data-set")
    @Features("Performance Test")
    @Stories("Measure Load Time For Different UI Screens")
    @Severity(SeverityLevel.CRITICAL)
    @Test
    public void testLoadManagedFunds(@Optional("data/torc/perf/perf_data1.xml") String dataSet) {
        setUser("auto0");
        PerfDOM perf = new PerfDOM().fromResource(dataSet);
        perf.testManagedFunds();
    }

    @Parameters("perf-data-set")
    @Features("Performance Test")
    @Stories("Measure Load Time For Different UI Screens")
    @Severity(SeverityLevel.CRITICAL)
    @Test
    public void testLoadAgreements(@Optional("data/torc/perf/perf_data1.xml") String dataSet) {
        setUser("auto1");
        PerfDOM perf = new PerfDOM().fromResource(dataSet);
        perf.testAgreements();
    }

    @Parameters("perf-data-set")
    @Features("Performance Test")
    @Stories("Measure Load Time For Different UI Screens")
    @Severity(SeverityLevel.CRITICAL)
    @Test
    public void testLoadManagedFundsWithFilter(@Optional("data/torc/perf/perf_data1.xml") String dataSet) {
        setUser("auto2");
        PerfDOM perf = new PerfDOM().fromResource(dataSet);
        perf.testManagedFundsWithFilter();
    }

    @Parameters("perf-data-set")
    @Features("Performance Test")
    @Stories("Measure Load Time For Different UI Screens")
    @Severity(SeverityLevel.CRITICAL)
    @Test
    public void testLoadOtherIA(@Optional("data/torc/perf/perf_data1.xml") String dataSet) {
        setUser("auto3");
        PerfDOM perf = new PerfDOM().fromResource(dataSet);
        perf.testOtherIA();
    }

    @Parameters("perf-data-set")
    @Features("Performance Test")
    @Stories("Measure Load Time For Different UI Screens")
    @Severity(SeverityLevel.CRITICAL)
    @Test()
    public void testCreateAgreement(@Optional("data/torc/perf/perf_data1.xml") String dataSet) {
        setUser("auto4");
        PerfDOM perf = new PerfDOM().fromResource(dataSet);
        perf.testCreateAgreement();
    }

    @Parameters("perf-data-set")
    @Features("Performance Test")
    @Stories("Measure Load Time For Different UI Screens")
    @Severity(SeverityLevel.CRITICAL)
    @Test
    public void testCreateManagedFund(@Optional("data/torc/perf/perf_data1.xml") String dataSet) {
        setUser("auto5");
        PerfDOM perf = new PerfDOM().fromResource(dataSet);
        perf.testCreateManagedFund();
    }

    @Parameters("perf-data-set")
    @Features("Performance Test")
    @Stories("Measure Load Time For Different UI Screens")
    @Severity(SeverityLevel.CRITICAL)
    @Test
    public void testUpdateManagedFunds(@Optional("data/torc/perf/perf_data1.xml") String dataSet) {
        setUser("auto6");
        PerfDOM perf = new PerfDOM().fromResource(dataSet);
        perf.testUpdateManagedFund();
    }

    @Parameters("perf-data-set")
    @Features("Performance Test")
    @Stories("Measure Load Time For Different UI Screens")
    @Severity(SeverityLevel.CRITICAL)
    @Test(dependsOnMethods = {"testCreateAgreement"}, alwaysRun = true) //Preventing Optimistic Locking, avoid running concurrently with testCreateAgreement
    public void testUpdateAgreement(@Optional("data/torc/perf/perf_data1.xml") String dataSet) {
        setUser("auto4"); // Same user as used in testCreateAgreement, these two tests are executed sequentially
        PerfDOM perf = new PerfDOM().fromResource(dataSet);
        perf.testUpdateAgreement();
    }

    @Parameters("perf-data-set")
    @Features("Performance Test")
    @Stories("Measure Load Time For Different UI Screens")
    @Severity(SeverityLevel.CRITICAL)
    @Test
    public void testLoadCRV(@Optional("data/torc/perf/perf_data1.xml") String dataSet) {
        setUser("auto7");
        PerfDOM perf = new PerfDOM().fromResource(dataSet);
        perf.testLoadCRVs();
    }

    @Parameters("perf-data-set")
    @Features("Performance Test")
    @Stories("Measure Load Time For Different UI Screens")
    @Severity(SeverityLevel.CRITICAL)
    @Test
    public void testExecuteBusinessRules(@Optional("data/torc/perf/perf_data1.xml") String dataSet) {
        setUser("auto8");
        PerfDOM perf = new PerfDOM().fromResource(dataSet);
        perf.testExecuteBusinessRules();
    }

    @Parameters("perf-data-set")
    @Features("Performance Test")
    @Stories("Measure Load Time For Different UI Screens")
    @Severity(SeverityLevel.CRITICAL)
    @Test
    public void testUpdateTask(@Optional("data/torc/perf/perf_data1.xml") String dataSet) {
        setUser("auto9");
        PerfDOM perf = new PerfDOM().fromResource(dataSet);
        perf.testUpdateTask();
    }

//    @Parameters("perf-data-set")
//    @Features("Performance Test")
//    @Stories("Measure Load Time For Different UI Screens")
//    @Severity(SeverityLevel.CRITICAL)
//    @Test(dependsOnMethods = {"testUpdateManagedFunds","testCreateManagedFund"}, alwaysRun = true)
//    public void testCreateAccount(@Optional("data/torc/perf/perf_data1.xml") String dataSet) throws IOException {
//        setUser("auto6");
//        PerfDOM perf = new PerfDOM().fromResource(dataSet);
//        perf.testCreateAccount();
//    }

    @AfterClass
    public void afterClass(ITestContext context) {
        context.setAttribute("test-done", true);
        System.out.println("<======================= THE END =====================>");
    }

}
