package com.rbc.rbccm.taf.torc.api2;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import datainstiller.data.DataPersistence;


@XStreamAlias("w9-data")
public class DataW9 extends DataPersistence {
    private String srNo;
    private Condition condition;
    private Conclusion conclusion;

    public DataW9() {}
    public DataW9(String[] values) {
        srNo = values[0];
        condition = new Condition(values);
        conclusion = new Conclusion(values);
    }

    public String getSrNo() {
        return srNo;
    }

    public Condition getCondition() {
        return condition;
    }

    public Conclusion getConclusion() {
        return conclusion;
    }

    @SuppressWarnings("WeakerAccess")
    public static class Condition {
        private String jurisdiction;
        private String igaStatus;
        private String qiStatus;
        private String accountHolderType;
        private String docType;
        private String obligationDocumentStatus;
        private String knowledgeCH3;
        private String knowledgeCH4;

        public Condition(String[] values) {
            jurisdiction = values[1];
            igaStatus = values[2];
            qiStatus = values[3];
            accountHolderType = values[4];
            docType = values[5];
            obligationDocumentStatus = values[6];
            knowledgeCH3 = values[7];
            knowledgeCH4 = values[8];
        }

        public String getJurisdiction() {
            return jurisdiction;
        }

        public String getIgaStatus() {
            return igaStatus.replace("-","_");
        }

        public String getQiStatus() {
            if (qiStatus.equals("*")) {
                return "Non_QI";
            }
            return qiStatus.replace("-","_").replace("/","").trim();
        }

        public String getAccountHolderType() {
            return accountHolderType.trim().toUpperCase();
        }

        public String getDocType() {
            String doc = docType.trim().replace(" ", "").replace("-","");
            if (doc.contains("W9")) {
                return "W9";
            }
            return doc;
        }

        public boolean getObligationDocumentStatus() {
            return obligationDocumentStatus.trim().equals("Complete");
        }

        public boolean getKnowledgeCH3() {
            return knowledgeCH3.contains("Other");
        }

        public boolean getKnowledgeCH4() {
            return knowledgeCH4.contains("Other");
        }
    }

    @SuppressWarnings("WeakerAccess")
    public static class Conclusion {
        private String withholdingStatusCh4;
        private String withholdingRateCh4;
        private String withholdingStatusCh3;
        private String withholdingRateCh3;

        public Conclusion(String[] values) {
            withholdingStatusCh4 = values[9];
            withholdingRateCh4 = values[10];
            withholdingStatusCh3 = values[11];
            withholdingRateCh3 = values[12];
        }

        public String getWithholdingStatusCh4() {
            return withholdingStatusCh4.trim().replace(" ","_").toUpperCase();
        }

        public String getWithholdingRateCh4() {
            return (int)(Float.parseFloat(withholdingRateCh4) * 100) + "%" ;
        }

        public String getWithholdingStatusCh3() {
            return withholdingStatusCh3.trim().replace(" ","_").toUpperCase();
        }

        public String getWithholdingRateCh3() {
            return (int)(Float.parseFloat(withholdingRateCh3) * 100) + "%";
        }
    }

}
