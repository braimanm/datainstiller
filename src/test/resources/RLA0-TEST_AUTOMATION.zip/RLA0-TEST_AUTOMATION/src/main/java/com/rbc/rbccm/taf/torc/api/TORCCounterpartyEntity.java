package com.rbc.rbccm.taf.torc.api;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import com.rbccm.torc.model.client.AgreementType;
import org.jsoup.Connection;

import java.io.IOException;

@SuppressWarnings({"unused", "WeakerAccess"})
@JsonIgnoreProperties(ignoreUnknown=true)
public class TORCCounterpartyEntity {
    public String id;
    public String gid;
    public String cdrClientId;
    public String legalName;
    public String[] rbcLegalEntity;
    public String[] clientBookingPoints;
    public AgreementType[] agreementType;


    private static TORCCounterpartyEntity[] getEntity(Connection con) throws IOException {
        Connection.Response res = con.execute();
        String bodyText = res.parse().body().text();
        if (bodyText.contains("Login with Username and Password User: Password:")) {
            throw new RuntimeException("Invalid token. Please login again!");
        }
        ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        TORCDataWrapper<TORCCounterpartyEntity> clients = mapper.readValue(bodyText, new TypeReference<TORCDataWrapper<TORCCounterpartyEntity>>(){});
        return clients.data;
    }

    public static TORCCounterpartyEntity[] search(TORCSession session, String legalName) throws IOException {
        Connection con = session.getConnection("/api/clientsearch");
        con.method(Connection.Method.POST);
        con.data("take","20");
        con.data("skip","0");
        con.data("page","1");
        con.data("pageSize","20");
        if (legalName != null) {
            con.data("filter[logic]", "and");
            con.data("filter[filters][0][field]", "legalName");
            con.data("filter[filters][0][operator]", "eq");
            con.data("filter[filters][0][value]", legalName);
        }

        return getEntity(con);
    }

    public static TORCCounterpartyEntity searchOne(TORCSession session, String legalName) throws IOException {
        TORCCounterpartyEntity[] many = search(session, legalName);
        for (TORCCounterpartyEntity one : many) {
            if (one.legalName.equalsIgnoreCase(legalName)) {
                return one;
            }
        }
        return many[0];
    }


    @Override
    public String toString() {
        return "\n{ \"legalname\" = " + legalName + ", \"id\" =" + id + " \"gid\" =" + gid +"}";
    }
}
