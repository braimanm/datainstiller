package com.rbc.rbccm.taf.torc.api;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.jsoup.Connection;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.util.Map;

public class TORCGenericRequest {
    private long executionTime;
    private String json;

    TORCGenericRequest(String json, long executionTime) {
        this.executionTime = executionTime;
        if (json != null) {
            ObjectMapper mapper = new ObjectMapper();
            try {
                this.json = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(mapper.readValue(json, Object.class));
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
    }

    public String getJson() {
        return json;
    }

    public long getExecutionTime() {
        return executionTime;
    }

    public <T> T getEntity(Class<T> cls) throws IOException {
        ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        return mapper.readValue(getJson(), cls);
    }

    public Object getEntity(TypeReference ref) throws IOException {
        ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        return mapper.readValue(getJson(), ref);
    }

    private static TORCGenericRequest genericRequest(Connection.Method method, TORCSession session, String endPoint, Map<String,String> headers, Map<String,String> data, String payload) throws IOException {
        Connection con = session.getConnection(endPoint);
        con.method(method);
        if (headers != null && !headers.isEmpty()) {
            con.headers(headers);
        } else {
            con.header("Content-Type", "application/json;charset=UTF-8");
        }
        if (data != null && !data.isEmpty()) {
            con.data(data);
        } else {
            con.requestBody(payload);
        }

        return execute(con, TORCGenericRequest.class);
    }

    public static TORCGenericRequest genericPost(TORCSession session, String endPoint, Map<String,String> headers, Map<String,String> data, String payload) throws IOException {
        return genericRequest(Connection.Method.POST, session, endPoint, headers, data, payload);
    }

    public static TORCGenericRequest genericPost(TORCSession session, String endPoint, String payload) throws IOException {
       return genericPost(session, endPoint, null, null, payload);
    }

    public static TORCGenericRequest genericPut(TORCSession session, String endPoint, String payload) throws IOException {
        return genericRequest(Connection.Method.PUT, session, endPoint, null, null, payload);
    }

    public static TORCGenericRequest genericGet(TORCSession session, String endPoint) throws IOException {
        return genericGet(session, endPoint, null, null);
    }

    public static TORCGenericRequest genericGet(TORCSession session, String endPoint, Map<String,String> headers, Map<String,String> data) throws IOException {
        return genericRequest(Connection.Method.GET, session, endPoint, headers, data, null);
    }

    protected static <T extends TORCGenericRequest> T execute(Connection con, Class<T> clazz) throws IOException {
        long t = System.currentTimeMillis();
        con.ignoreHttpErrors(true);
        Connection.Response res = con.execute();
        t = System.currentTimeMillis() - t;
        String bodyText = res.parse().body().text();
        T request;
        if (res.statusCode() < 200 || res.statusCode() >= 400) {
            String msg = "HTTP error " + res.statusCode() + " at: " + con.request().url().toString();
            msg += " ERROR: \n" + bodyText;
            throw new RuntimeException(msg);
        }
        if (bodyText.contains("Login with Username and Password User: Password:")) {
            throw new RuntimeException("Invalid token. Please login again!");
        }
        try {
            Constructor<T> constructor = clazz.getDeclaredConstructor(String.class, long.class);
            constructor.setAccessible(true);
            request = constructor.newInstance(bodyText, t);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return request;
    }

}
