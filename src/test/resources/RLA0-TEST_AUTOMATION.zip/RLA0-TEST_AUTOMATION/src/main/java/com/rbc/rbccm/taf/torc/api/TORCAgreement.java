package com.rbc.rbccm.taf.torc.api;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rbccm.torc.model.client.*;
import org.jsoup.Connection;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;

@SuppressWarnings({"unused", "WeakerAccess"})
public class TORCAgreement extends TORCGenericRequest {

    private TORCAgreement(String json, long executionTime) {
        super(json, executionTime);
    }

    public static TORCAgreement get(TORCSession session, String clientId, boolean isEntity) throws IOException {
        Connection con;
        if (isEntity) {
            con = session.getConnection("/api/clients/" + clientId + "/agreementsandaccounts");
        } else {
            con = session.getConnection("/api/clients/" + clientId + "/agreements");
        }
        con.method(Connection.Method.GET);
        return execute(con, TORCAgreement.class);
    }

    public static TORCAgreement put(TORCSession session, String clientId, String payload, boolean isEntity) throws IOException {
        Connection con;
        if (isEntity) {
            con = session.getConnection("/api/clients/" + clientId + "/agreementsandaccounts");
        } else {
            con = session.getConnection("/api/clients/" + clientId + "/agreements");
        }
        con.method(Connection.Method.PUT);
        con.header("Content-Type","application/json;charset=UTF-8");
        con.requestBody(payload);
        return execute(con, TORCAgreement.class);
    }

    public Agreement[] getEntities() throws IOException {
        ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        return mapper.readValue(getJson(), Agreement[].class);
    }

    public String getLinkedAgreementEntitiesAsJson() throws IOException {
        Agreement[] agreements = getEntities();
        List<LinkedAgrement> las = new ArrayList<>();
        boolean selected = false;
        for (Agreement agreement : agreements) {
            LinkedAgrement la = new LinkedAgrement();
            la.id = agreement.getId();
            la.type = agreement.getType();
            la.agreementClass = agreement.getAgreementClass();
            la.requestType = agreement.getRequestType();
            la.status = agreement.getStatus();
            if (agreement.getExecutionDate() != null) {
                SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/YYYY");
                la.executionDate = dateFormat.format(agreement.getExecutionDate());
            }
            la.beneficiaryBookingPoints = new HashSet<>();//agreement.getBeneficiaryBookingPoints();
            la.linkedAgreementIds = new HashSet<>();//agreement.getLinkedAgreementIds();
            if (!agreement.getStatus().equals(AgreementStatus.CANCELLED) && !selected) {
                la.managedFundLinkFlag = true;
                la.managedFundStatus = ManagedFundStatus.PENDING;
                selected = true;
            } else {
                la.managedFundLinkFlag = false;
            }
            las.add(la);
        }
        ObjectMapper mapper = new ObjectMapper().setSerializationInclusion(JsonInclude.Include.NON_NULL);
        return mapper.writerWithDefaultPrettyPrinter().writeValueAsString(las);
    }

    public static class LinkedAgrement {
        public long id;
        public AgreementType type;
        public AgreementClass agreementClass;
        public RequestType requestType;
        public AgreementStatus status;
        public String executionDate;
        public Set<BeneficiaryBookingPoint> beneficiaryBookingPoints;
        public Set<Long> linkedAgreementIds;
        public boolean managedFundLinkFlag;
        public ManagedFundStatus managedFundStatus;

    }

}
