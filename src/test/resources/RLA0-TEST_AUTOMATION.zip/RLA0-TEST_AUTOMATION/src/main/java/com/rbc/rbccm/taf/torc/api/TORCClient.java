package com.rbc.rbccm.taf.torc.api;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rbccm.torc.model.client.Client;
import org.jsoup.Connection;

import java.io.IOException;

@SuppressWarnings("unused")
public class TORCClient extends TORCGenericRequest {

    private TORCClient(String json, long executionTime) {
        super(json, executionTime);
    }

    public static TORCClient get(TORCSession session, String clientId) throws IOException {
        Connection con = session.getConnection("/api/clients/" + clientId);
        con.method(Connection.Method.GET);
        return execute(con, TORCClient.class);
    }

    public Client getEntity() throws IOException {
        ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        return mapper.readValue(getJson(), Client.class);
    }

}
