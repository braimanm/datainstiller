package com.rbc.rbccm.taf.torc.api2;

import com.rbccm.taf.ui.support.AliasedString;
import com.rbccm.taf.ui.support.DomainObjectModel;
import com.thoughtworks.xstream.annotations.XStreamAlias;

import java.util.Map;

@XStreamAlias("TEX-data")
public class DataTEX extends DomainObjectModel {
    private AliasedString _srno;
    private AliasedString _taxformtype;
    private AliasedString _version;
    private AliasedString _chapter3status;
    private AliasedString _federaltaxclassification;
    private AliasedString _10a;
    private AliasedString _10b;
    private AliasedString _10c;
    private AliasedString _15a;
    private AliasedString _15b;
    private AliasedString _17a;
    private AliasedString _17b;
    private AliasedString _19a;
    private AliasedString _19b;
    private AliasedString _21a;
    private AliasedString _21b;
    private AliasedString _documentationstatusch3;
    private AliasedString _documentationstatusch4;
    private AliasedString _ch3standardsofknowledge;
    private AliasedString _ch4standardsofknowledge;
    private AliasedString _treatyselected;
    private AliasedString _treatyratesmatchstandardtablerates;
    private AliasedString _texcode;


    public DataTEX() {
    }
    public DataTEX(Map<String, String> tableRow) {
        enumerateFields((data, field) -> {
            try {
                AliasedString value = new AliasedString();
                value.initializeData(tableRow.get(field.getName()), null, null);
                field.set(this, value);
            } catch (IllegalAccessException ignore) {
            }
        });
    }

    public String get_srno() {
        return _srno.getData();
    }

    public String get_taxformtype() {
        return _taxformtype.getData().replace("W-8","");
    }

    public String get_version() {
        String version = _version.getData().trim();
        if (version.length() > 4) {
            String[] ver = version.split(" ");
            version = ver[0] + ". " + ver[1];
        }
        return version;
    }

    public String get_chapter3status() {
        return _chapter3status.getData();
    }

    public String get_federaltaxclassification() {
        return _federaltaxclassification.getData();
    }

    public String get_10a() {
        return _10a.getData();
    }

    public String get_10b() {
        return _10b.getData();
    }

    public String get_10c() {
        return _10c.getData();
    }

    public String get_15a() {
        return _15a.getData();
    }

    public String get_15b() {
        return _15b.getData();
    }

    public String get_17a() {
        return _17a.getData();
    }

    public String get_17b() {
        return _17b.getData();
    }

    public String get_19a() {
        return _19a.getData();
    }

    public String get_19b() {
        return _19b.getData();
    }

    public String get_21a() {
        return _21a.getData();
    }

    public String get_21b() {
        return _21b.getData();
    }

    public String get_documentationstatusch3() {
        return _documentationstatusch3.getData();
    }

    public String get_documentationstatusch4() {
        return _documentationstatusch4.getData();
    }

    public String get_ch3standardsofknowledge() {
        return _ch3standardsofknowledge.getData();
    }

    public String get_ch4standardsofknowledge() {
        return _ch4standardsofknowledge.getData();
    }

    public String get_treatyselected() {
        return _treatyselected.getData();
    }

    public String get_treatyratesmatchstandardtablerates() {
        return _treatyratesmatchstandardtablerates.getData();
    }

    public String get_texcode() {
        return _texcode.getData();
    }
}