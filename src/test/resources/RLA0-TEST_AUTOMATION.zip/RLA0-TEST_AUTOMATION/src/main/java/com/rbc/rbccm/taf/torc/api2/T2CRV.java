package com.rbc.rbccm.taf.torc.api2;

import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.rbc.rbccm.taf.torc.api.TORCGenericRequest;
import com.rbc.rbccm.taf.torc.api.TORCSession;
import ru.yandex.qatools.allure.annotations.Step;

import java.io.IOException;
import java.util.function.Function;

@SuppressWarnings("WeakerAccess")
public class T2CRV extends T2Entity {
    private T2Task task;
    private boolean isAgreement;

    private T2CRV(String json) {
        super(json);
    }

    public static T2CRV get(TORCSession session, T2Task task) throws IOException {
        StringBuilder endPoint = new StringBuilder("/api/clients/" + task.getClientId());
        boolean isAgreement = false;
        if (!task.getAgreementId().equals("null")) {
            endPoint.append("/agreements/").append(task.getAgreementId());
            isAgreement = true;
        } else {
            endPoint.append("/accounts/").append(task.getAccountId());
        }
        endPoint.append("/clientbookingpoints/").append(task.getClientBookingPoint()).append("/crv");
        TORCGenericRequest request = TORCGenericRequest.genericGet(session, endPoint.toString());
        T2CRV crv = new T2CRV(request.getJson());
        crv.task = task;
        crv.isAgreement = isAgreement;
        return crv;
    }

    @Step("Execute Task")
    public T2CRV execute(TORCSession session, Function<DocumentContext, DocumentContext> modifyPayload) throws IOException {
        StringBuilder endPoint = new StringBuilder("/api/clients/" + getClientId());
        if (isAgreement) {
            endPoint.append("/agreements/").append(getAgreementId());
        } else {
            endPoint.append("/accounts/").append(getAccountId());
        }
        endPoint.append("/clientbookingpoints/").append(getClientBookingPointJurisdictionCode()).append("/crv/execute");
        DocumentContext currData = modifyPayload.apply(JsonPath.parse(document));
        currData.put("$", "task", task.document);
        attach(JsonUtils.prettify(currData.jsonString()), "CRV Execute Request.");
        TORCGenericRequest request = TORCGenericRequest.genericPut(session, endPoint.toString(), currData.jsonString());
        attach(request.getJson(), "CRV Execute Response.");
        return new T2CRV(request.getJson());
    }

    public String getClientId() {
        return getProperty("$.clientId");
    }

    public String getAgreementId() {
        String value = "null";
        try {
            value = getProperty("$.crvKey.AGREEMENT_ID");
        } catch (Exception ignore) {}
        return  value;
    }

    public String getAccountId() {
        return getProperty("$.crvKey.ACCOUNT_ID");
    }


    public String getClientBookingPointJurisdictionCode() {
        return getProperty("$.crvKey.CLIENT_BOOKING_POINT_JURISDICTION_CODE");
    }

}
