package com.rbc.rbccm.taf.torc.api2;

import com.fasterxml.jackson.core.type.TypeReference;
import com.rbc.rbccm.taf.torc.api.TORCGenericRequest;
import com.rbc.rbccm.taf.torc.api.TORCSession;

import java.io.IOException;

import java.util.List;

@SuppressWarnings("WeakerAccess")
public class T2_ADP_FACT_CODE  {
    public final String fatcaStatus = null;
    public final String fatcaHolderType = null;
    public final String fatcaHolderSubType = null;
    public final String documented = null;
    public final String reportable = null;
    public final String taxable = null;
    public final String fatcaHolderTypeDescLabel = null;
    public final String individualOrEntity = null;
    public final String fatcaEntityType = null;
    public final String withholdable = null;
    public final String fatcaHolderTypeDescription = null;

    public static T2_ADP_FACT_CODE get(TORCSession session, String description) throws IOException {
        TORCGenericRequest req = TORCGenericRequest.genericGet(session, "/api/adpfactcodes");
        TypeReference ref = new TypeReference<List<T2_ADP_FACT_CODE>>() {};
        for (T2_ADP_FACT_CODE code : (List<T2_ADP_FACT_CODE>) req.getEntity(ref)) {
            if (code.fatcaHolderTypeDescLabel.replaceAll("\\W","").equals(description.replaceAll("\\W",""))) {
                return code;
            }
        }
        return null;
    }

}
