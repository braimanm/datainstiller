package com.rbc.rbccm.uqt0.taf.leaf.tests;

import com.rbc.rbccm.uqt0.taf.leaf.api.ExceptionCount;
import com.rbc.rbccm.uqt0.taf.leaf.api.ExceptionEntity;
import com.rbc.rbccm.uqt0.taf.leaf.api.QuestionnaireElements;
import com.rbc.rbccm.uqt0.taf.leaf.pageobjects.*;
import com.rbccm.taf.ui.testng.TestNGBase;
import com.rbccm.taf.ui.utils.Helper;
import org.assertj.core.api.SoftAssertions;
import org.testng.ITestContext;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.Allure;
import ru.yandex.qatools.allure.annotations.Description;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Step;
import ru.yandex.qatools.allure.annotations.Stories;
import ru.yandex.qatools.allure.events.StepFailureEvent;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.*;
import java.text.DecimalFormat;
import java.util.List;
import java.util.Map;

public class TestLeaf extends TestNGBase {
    private int qId = (System.getenv().containsKey("QID_BASELINE"))? Integer.parseInt(System.getenv("QID_BASELINE")) : 1;
    private int qId2 = (System.getenv().containsKey("QID"))? Integer.parseInt(System.getenv("QID")) : 1;

    @Features("Exceptions")
    @Stories("DB Test")
    @Description("Compare Exceptions between baseline and processed data")
    @Test
    public void compareExceptionDatabases() throws SQLException {
        List<ExceptionEntity> baselineEx = new ExceptionCount(true , qId).getExceptions();
        List<ExceptionEntity> dbEx = new ExceptionCount(false , qId2).getExceptions();
        SoftAssertions soft = new SoftAssertions();
        soft.assertThat(dbEx).hasSameSizeAs(baselineEx);
        for (int i = 0; i< baselineEx.size(); i++) {
            String exDescr = baselineEx.get(i).getException_desc();
            Integer expected = baselineEx.get(i).getCount();
            Integer actual = dbEx.get(i).getCount();
            soft.assertThat(actual).as(exDescr).isEqualTo(expected);
            reportingStep("Validate " + exDescr + " is equals to the baseline value of " + expected , !expected.equals(actual));
        }
        soft.assertAll();
    }

    @Features("Questionnaire")
    @Stories("DB Test")
    @Description("Compare Questionnaires between baseline and processed data")
    @Test
    public void compareQuestionnaireDatabases() throws SQLException {
        Map<String,String> q1 = new QuestionnaireElements(true, qId).getElements();
        Map<String,String> q2 = new QuestionnaireElements(false, qId2).getElements();
        SoftAssertions soft = new SoftAssertions();
        soft.assertThat(q2).hasSameSizeAs(q1);
        q1.keySet().forEach(fieldCode -> {
            String expected = q1.get(fieldCode);
            String actual = q2.get(fieldCode);
            soft.assertThat(actual).as(fieldCode).isEqualTo(expected);
            reportingStep("Validate field " + fieldCode + " is equals to the baseline value of " + expected , !expected.equals(actual));
        });
        soft.assertAll();
    }

    @Features("Questionnaire")
    @Stories("UI Test")
    @Description("Validate Questionnaire UI fields values against baseline data")
    @Test
    public void validateQuestionnaireUI() throws SQLException {
        LoginPO login = new LoginPO(getContext());
        QuestionnaireListPO qList = login.login();
        QuestionnaireFormPO qForm = qList.getFormByID(qId2);
        Map<String,String> q1 = new QuestionnaireElements(true, qId).getElements();
        SoftAssertions soft = new SoftAssertions();
        DecimalFormat formatter = new DecimalFormat("#,##0.00");
        q1.keySet().forEach((fieldCode) -> {
            String actual = qForm.getValue(fieldCode);
            String expected = formatter.format(Double.parseDouble(q1.get(fieldCode)));
            soft.assertThat(actual).as(fieldCode).isEqualTo(expected);
            reportingStep("Validate field " + fieldCode + " is equals to " + expected, !expected.equals(actual));
        });
        soft.assertAll();
    }

    @Features("Questionnaire")
    @Stories("UI Test")
    @Description("Validate Questionnaire Drill Down UI totals against baseline")
    @Test
    public void validateQuestionnaireDrillDownUI() throws SQLException {
        LoginPO login = new LoginPO(getContext());
        QuestionnaireListPO qList = login.login();
        QuestionnaireFormPO qForm = qList.getFormByID(qId2);
        Map<String,String> q1 = new QuestionnaireElements(true, qId).getElements();
        SoftAssertions soft = new SoftAssertions();
        DecimalFormat dFormat = new DecimalFormat("#,##0.00");
        q1.keySet().forEach((fieldCode) -> {
            if (qForm.isDrillDownExists(fieldCode)) {
                QuestionnaireDrillDownPO drillDown = qForm.getDrillDown(fieldCode);
                String aggregate = drillDown.getAggregateAmount();
                String total = fieldCode.equals("F1")? drillDown.getTotalF1Amount() : drillDown.getTotalAmount();
                // *************** FIXING PROBLEM WITH TOTAL AMOUNT ********************
                        if (!total.isEmpty()) {
                            BigDecimal vvv = new BigDecimal(total.replace(",",""));
                            total = dFormat.format(vvv.setScale(2,RoundingMode.HALF_DOWN));

                        }
                // **********************************************************************
                String expected = dFormat.format(Double.parseDouble(q1.get(fieldCode)));
                soft.assertThat(aggregate).as(fieldCode + " Drill Down Aggregate").isEqualTo(expected);
                reportingStep("Validate drill down aggregate for " + fieldCode + " is equals to " + expected, !expected.equals(aggregate));
                soft.assertThat(total).as(fieldCode + " Drill Down Total").isEqualTo(expected);
                reportingStep("Validate drill down total for " + fieldCode + " is equals to " + expected, !expected.equals(total));
                drillDown.close();
            }
        });
        soft.assertAll();
    }

    @Features("Exceptions")
    @Stories("UI Test")
    @Description("Validate Exceptions UI fields values against baseline data")
    @Test
    public void validateExceptionsUI() throws SQLException {
        LoginPO login = new LoginPO(getContext());
        QuestionnaireListPO qList = login.login();
        ExceptionsPO exPO = qList.getExceptionById(qId2);
        SoftAssertions soft = new SoftAssertions();
        for (String type : new String[]{"Impacts Questionnaire","Information","Provisional Enrichment"}) {
            exPO.selectType(type);
            List<ExceptionEntity> baseLineEx = new ExceptionCount(qId, type).getExceptions();
            DecimalFormat formatter = new DecimalFormat("#,###");
            baseLineEx.forEach((ex) -> {
                String actual = exPO.getField(ex);
                String expected = formatter.format(ex.getCount());
                soft.assertThat(actual).as(ex.getExcp_disp_name()).isEqualTo(expected);
                reportingStep("Validating " + ex.getException_desc() + " to be equal to " + expected, !expected.equals(actual));
            });
        }
        soft.assertAll();
    }

    @Features("Exceptions")
    @Stories("UI Test")
    @Description("Validate Exceptions Drill Down UI total against baseline")
    @Test
    public void validateExceptionDrillDownUI() throws SQLException {
        LoginPO loginPO = new LoginPO(getContext());
        QuestionnaireListPO qList = loginPO.login();
        ExceptionsPO exPO = qList.getExceptionById(qId2);
        SoftAssertions soft = new SoftAssertions();
        for (String type : new String[]{"Impacts Questionnaire","Information","Provisional Enrichment"}) {
            List<ExceptionEntity> baseLineEx = new ExceptionCount(qId, type).getExceptions();
            baseLineEx.forEach((ex) -> {
                if (ex.getException_desc().equals("Price Type")) {
                    System.out.println("bug");
                }
                exPO.selectType(type);
                ExceptionDrillDownPO exDD = exPO.getDrillDown(ex);
                String actual = exDD.getTotalAmount();
                String expected = "" + ex.getCount();
                soft.assertThat(actual).as(ex.getExcp_disp_name() + " Drill Down Total").isEqualTo(expected);
                reportingStep("Validating drill down total for " + ex.getException_desc() + " to be equal to " + expected, !expected.equals(actual));
                getContext().getDriver().navigate().back();
                Helper.waitForXHR();
            });
        }
        soft.assertAll();
    }

    @Step("{0}")
    private void reportingStep(String msg, boolean isFailed) {
        if(isFailed) {
            AssertionError assertionError = new AssertionError("Comparison Error " + msg);
            Allure.LIFECYCLE.fire(new StepFailureEvent().withThrowable(assertionError));
            takeScreenshot("Comparison Error");
        }
    }

    @BeforeMethod
    private void initMethod(ITestContext itestcontext) {
        initTest(itestcontext);
    }

    @AfterMethod
    private void clean() {
        this.closeDriver();
    }

}
