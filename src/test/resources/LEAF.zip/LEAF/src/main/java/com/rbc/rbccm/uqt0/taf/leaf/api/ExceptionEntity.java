package com.rbc.rbccm.uqt0.taf.leaf.api;

public class ExceptionEntity {
    private int report_entity_id;
    private String exception_desc;
    private String excp_disp_name;
    private String impacted_for_questionnaire;
    private int count;

    public int getReport_entity_id() {
        return report_entity_id;
    }

    public void setReport_entity_id(int report_entity_id) {
        this.report_entity_id = report_entity_id;
    }

    public String getException_desc() {
        return exception_desc;
    }

    public void setException_desc(String exception_desc) {
        this.exception_desc = exception_desc;
    }

    public String getExcp_disp_name() {
        return excp_disp_name;
    }

    public void setExcp_disp_name(String excp_disp_name) {
        this.excp_disp_name = excp_disp_name;
    }

    public String getImpacted_for_questionnaire() {
        return impacted_for_questionnaire;
    }

    public void setImpacted_for_questionnaire(String impacted_for_questionnaire) {
        this.impacted_for_questionnaire = impacted_for_questionnaire;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }
}
