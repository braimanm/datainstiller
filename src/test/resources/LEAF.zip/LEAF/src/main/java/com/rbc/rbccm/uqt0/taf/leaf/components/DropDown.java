package com.rbc.rbccm.uqt0.taf.leaf.components;

import com.rbccm.taf.ui.utils.Helper;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import ui.auto.core.data.DataTypes;
import ui.auto.core.pagecomponent.PageComponent;

public class DropDown extends PageComponent {

    @Override
    protected void init() {}

    private WebElement getSelected() {
        return coreElement.findElement(By.cssSelector("span div.md-text"));
    }

    @Override
    public void setValue() {
        if (coreElement.getAttribute("aria-expanded").equals("false")) {
            getSelected().click();
            Helper.getFluentWait().until(webDriver -> coreElement.getAttribute("aria-expanded").equals("true"));
            Helper.sleep(200); // Wait for select open animation to complete
        }
        WebElement optionList = Helper.getWebDriver().findElement(By.id(coreElement.getAttribute("aria-owns")));
        optionList.findElement(By.cssSelector("md-option[value='" + getData() + "']" )).click();
        Helper.sleep(200); // Wait for select close animation to complete
    }

    @Override
    public String getValue() {
        return getSelected().getText();
    }

    @Override
    public void validateData(DataTypes validationMethod) {}

}
