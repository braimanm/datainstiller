package com.rbc.rbccm.uqt0.taf.leaf.api;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ExceptionCount {
    private List<ExceptionEntity> exceptions;
    private int qId;

    private String sql2 = "SELECT \n" +
            "A.REPORT_ENTITY_ID, \n" +
            "B.EXCEPTION_DESC, \n" +
            "B.EXCP_DISP_NAME, \n" +
            "B.IMPACTED_FOR_QUESTIONNAIRE , \n" +
            "B.EXCEPTION_TYPE, \n" +
            "COUNT(*) as \"COUNT\" \n" +
            "FROM \n" +
            "RUQT0SHSOP_TEST.T_LEAF_EXCEPTION_SUMMARY_B A , \n" +
            "RUQT0SHSOP_TEST.T_LEAF_EXCEPTION_DESC_B B, \n" +
            "RUQT0SHSOP_TEST.T_LEAF_EXCEPTION_DETAILS_B C \n" +
            "WHERE \n" +
            " A.EXCEPTION_ID=B.EXCEPTION_ID \n" +
            "AND A.LEAF_TRADE_KEY=C.LEAF_TRADE_KEY \n" +
            "AND EXCEPTION_STATUS in ('Open', 'In-Progress') \n" +
            "and A.ALL_IMPACTED_FOR_QUESTIONNAIRE LIKE '%,{QID},%' \n" +
            "and B.EXCEPTION_TYPE ='{TYPE}'\n" +
            "GROUP BY \n" +
            "A.REPORT_ENTITY_ID, \n" +
            "B.EXCEPTION_DESC, \n" +
            "B.EXCP_DISP_NAME, \n" +
            "B.IMPACTED_FOR_QUESTIONNAIRE , \n" +
            "B.EXCEPTION_TYPE\n" +
            "ORDER BY EXCEPTION_DESC,IMPACTED_FOR_QUESTIONNAIRE DESC";


    private String getSql(boolean isBaseLine, int questionnaireId) {
        String baselineSql = "\n" +
                "SELECT \n" +
                "A.REPORT_ENTITY_ID, \n" +
                "B.EXCEPTION_DESC, \n" +
                "B.IMPACTED_FOR_QUESTIONNAIRE, \n" +
                "COUNT(*) as \"COUNT\" \n" +
                "FROM \n" +
                "RUQT0SHSOP_TEST.T_LEAF_EXCEPTION_SUMMARY_B A , \n" +
                "RUQT0SHSOP_TEST.T_LEAF_EXCEPTION_DESC_B B, \n" +
                "RUQT0SHSOP_TEST.T_LEAF_EXCEPTION_DETAILS_B C \n" +
                "WHERE  \n" +
                "A.EXCEPTION_ID=B.EXCEPTION_ID \n" +
                "AND A.LEAF_TRADE_KEY=C.LEAF_TRADE_KEY \n" +
                "AND EXCEPTION_STATUS in ('Open', 'In-Progress') \n" +
                "and A.ALL_IMPACTED_FOR_QUESTIONNAIRE LIKE '%,{QID},%' \n" +
                "GROUP BY \n" +
                "A.REPORT_ENTITY_ID, \n" +
                "B.EXCEPTION_DESC, \n" +
                "B.IMPACTED_FOR_QUESTIONNAIRE \n" +
                "ORDER BY EXCEPTION_DESC,IMPACTED_FOR_QUESTIONNAIRE DESC";
        String sql = baselineSql.replace("{QID}", "" + questionnaireId);
        if (!isBaseLine) {
            sql = sql.replace("_SUMMARY_B","_SUMMARY");
            sql = sql.replace("_DESC_B","_DESC");
            sql = sql.replace("_DETAILS_B","_DETAILS");
        }
        return sql;
    }

    public ExceptionCount(boolean isBaseLine, int questionnaireId) throws SQLException {
        qId = questionnaireId;
        DBAccess db = new DBAccess();
        JdbcTemplate jdbcTemp = db.getJdbcTemplate();
        exceptions = jdbcTemp.query(getSql(isBaseLine, questionnaireId), new BeanPropertyRowMapper<>(ExceptionEntity.class));
    }

    public ExceptionCount(int questionnaireId, String exceptionType) throws  SQLException {
        qId = questionnaireId;
        DBAccess db = new DBAccess();
        JdbcTemplate jdbcTemp = db.getJdbcTemplate();
        String sql = sql2.replace("{QID}", "" + qId).replace("{TYPE}", exceptionType);
        exceptions = jdbcTemp.query(sql, new BeanPropertyRowMapper<>(ExceptionEntity.class));
    }

    public List<ExceptionEntity> getExceptions() {
        return exceptions;
    }
}
