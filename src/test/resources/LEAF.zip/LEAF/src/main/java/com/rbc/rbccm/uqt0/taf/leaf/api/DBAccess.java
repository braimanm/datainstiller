package com.rbc.rbccm.uqt0.taf.leaf.api;

import com.rbccm.taf.ui.support.EnvironmentsSetup;
import com.rbccm.taf.ui.support.TestContext;
import oracle.jdbc.OracleConnection;
import oracle.jdbc.pool.OracleDataSource;
import org.apache.commons.lang3.StringUtils;
import org.springframework.jdbc.core.JdbcTemplate;

import javax.sql.DataSource;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public class DBAccess {
    private EnvironmentsSetup.User dbUser;

    DBAccess() {
        dbUser = TestContext.getTestProperties().getTestEnvironment().getUser("db");
    }

    private Properties getConnProps() {
        Properties props = new Properties();
        props.put("dburl", "jdbc:oracle:thin:@" + System.getenv(dbUser.getFullName()));
        props.put(OracleConnection.CONNECTION_PROPERTY_USER_NAME, System.getenv(dbUser.getUserName()));
        props.put(OracleConnection.CONNECTION_PROPERTY_PASSWORD, System.getenv(dbUser.getPassword()));
        return props;
    }

    @SuppressWarnings("unused")
    public Connection getDBConnection() throws SQLException {
        Properties props = getConnProps();
        return DriverManager.getConnection((String) props.get("dburl"), props);
    }

    public DataSource getDataSource() throws SQLException {
        Properties props = getConnProps();
        OracleDataSource ds = new OracleDataSource();
        ds.setURL(props.getProperty("dburl"));
        ds.setConnectionProperties(props);
        return ds;
    }

    JdbcTemplate getJdbcTemplate() throws SQLException {
        return new JdbcTemplate(getDataSource());
    }

    // ***************** FOR DEBUGGING ******************
    private int[] sizes;
    private List<String[]> table = new ArrayList<>();

    private void updateSizes(String value, int index) {
        int gap = 3;
        if (sizes[index] < value.length() + gap ) {
            sizes[index] = value.length() + gap ;
        }
    }

    private void addHeaders(ResultSetMetaData metadata) throws SQLException {
        sizes = new int[metadata.getColumnCount()];
        String[] columns = new String[metadata.getColumnCount()];
        for (int i=0; i < metadata.getColumnCount(); i++) {
            String columnName = metadata.getColumnName(i + 1);
            columns[i] = columnName;
            updateSizes(columnName, i);
        }
        table.add(columns);
        String[] columns2 = new String[metadata.getColumnCount()];
        for (int i=0; i < metadata.getColumnCount(); i++) {
            String type = metadata.getColumnTypeName(i + 1);
            String prec = " (" + metadata.getPrecision(i + 1) + "," + metadata.getScale(i + 1) +  ")";
            if (type.equals("decimal")) {
                type = type + prec;
            }
            columns2[i] = type;
            updateSizes(type, i);
        }
        table.add(columns2);
    }

    private void printTable() {

        for (int i = 0; i < table.size(); i++) {
            String[] values = table.get(i);
            StringBuilder sb = new StringBuilder();
            for (int s = 0; s < values.length; s++) {
                sb.append(String.format("%-" + sizes[s] + "s", values[s]));
            }
            System.out.println(sb.toString());
            if (i == 1) {
                int sum = 0;
                for (int s : sizes) sum += s;
                System.out.println(StringUtils.repeat("=", sum));
            }
        }
    }

    void debug(String sql) throws SQLException {
        try (
                Connection con = getDBConnection();
                Statement stmt = con.createStatement();
                ResultSet rs = stmt.executeQuery(sql)
        ) {
            ResultSetMetaData metadata = rs.getMetaData();
            addHeaders(metadata);
            while (rs.next()) {
                String[] columns = new String[metadata.getColumnCount()];
                for (int i = 0; i < metadata.getColumnCount(); i++) {
                    Object value;
                    switch (metadata.getColumnTypeName(i + 1)) {
                        case "decimal":
                            value = rs.getObject(i + 1);
                            break;
                        default:
                            value = rs.getString(i + 1);
                            break;
                    }
                    columns[i] = (String) value;
                    updateSizes((String) value, i);
                }
                table.add(columns);
            }
            printTable();
        }
    }
}
