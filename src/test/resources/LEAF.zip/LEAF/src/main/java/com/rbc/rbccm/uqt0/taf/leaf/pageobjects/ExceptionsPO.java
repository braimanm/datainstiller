package com.rbc.rbccm.uqt0.taf.leaf.pageobjects;

import com.rbc.rbccm.uqt0.taf.leaf.api.ExceptionEntity;
import com.rbc.rbccm.uqt0.taf.leaf.components.DropDown;
import com.rbccm.taf.ui.support.PageObjectModel;
import com.rbccm.taf.ui.utils.Helper;
import com.thoughtworks.xstream.annotations.XStreamOmitField;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import ui.auto.core.components.WebComponent;

import java.util.List;

public class ExceptionsPO extends PageObjectModel {
    @XStreamOmitField
    @FindBy(css = "md-select[ng-model='main.excpType']")
    private DropDown exceptionType;
    @XStreamOmitField
    @FindBy(xpath = "//button[.='Retrieve']")
    private WebComponent retrieveButton;


    public void selectType(String type) {
        if (!exceptionType.getValue().equals(type)) {
            setElementValue(exceptionType, type);
            retrieveButton.click();
            Helper.waitForXHR();
        }
    }

    public String getField(ExceptionEntity fieldName) {
        final String[] attrVal = new String[1];

        List<WebElement> fields = getDriver().findElements(By.xpath("//*[contains(@aria-label,'" + fieldName.getExcp_disp_name() + "')]"));

        if (fields.isEmpty()) {
            throw new RuntimeException("'" + fieldName.getException_desc() + "' field was not found on Exception Dashboard!");
        }

        String[] values = fields.get(0).getAttribute("aria-label") .split(" ");
        attrVal[0] = values[values.length - 1];

        return attrVal[0];
    }

    public ExceptionDrillDownPO getDrillDown(ExceptionEntity fieldName) {
        List<WebElement> fields = getDriver().findElements(By.xpath("//*[.='" + fieldName.getExcp_disp_name() + "']"));

        if (fields.isEmpty()) {
            throw new RuntimeException("'" + fieldName.getException_desc() + "' field was not found on Exception Dashboard!");
        }

        fields.get(0).click();

        Helper.waitForXHR();

        ExceptionDrillDownPO edd = new ExceptionDrillDownPO();
        edd.initPage(getContext());
        return edd;

    }


}
