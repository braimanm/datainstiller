package com.rbc.rbccm.uqt0.taf.leaf.pageobjects;

import com.rbccm.taf.ui.support.AliasedString;
import com.rbccm.taf.ui.support.EnvironmentsSetup;
import com.rbccm.taf.ui.support.PageObjectModel;
import com.rbccm.taf.ui.support.TestContext;
import com.rbccm.taf.ui.utils.Helper;
import datainstiller.data.Data;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import ui.auto.core.components.WebComponent;

@SuppressWarnings("unused")
public class LoginPO extends PageObjectModel {
    private AliasedString url;
    @FindBy(css = "#myusr_name")
    private WebComponent userName;
    @FindBy(css = "#myusr_password")
    private WebComponent userPswd;
    @Data(skip = true)
    @FindBy(css = "a[onclick^=run_login")
    private WebComponent loginButton;

    public LoginPO(TestContext context) {
        initPage(context);
    }

    public QuestionnaireListPO login() {
        EnvironmentsSetup.User envUser = TestContext.getTestProperties().getTestEnvironment().getUser("user");
        if (!System.getenv().containsKey(envUser.getUserName())) {
            throw new RuntimeException("Application Login user is not set in system environment!");
        }
        if (!System.getenv().containsKey(envUser.getPassword())) {
            throw new RuntimeException("Application Login password is not set in system environment!");
        }

        String user = System.getenv(envUser.getUserName());
        String pswd = System.getenv(envUser.getPassword());
        String url= System.getenv(TestContext.getTestProperties().getTestEnvironment().getUrl());
        getDriver().get(url);
        setElementValue(userName, user);
        setElementValue(userPswd, pswd);
        loginButton.click();
        waitForUrl("#!/sh-questionnaire");
        Helper.getWebDriiverWait().until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[.='Unique Record ID']")));
        QuestionnaireListPO q = new QuestionnaireListPO();
        q.initPage(getContext());
        return q;
    }

}

