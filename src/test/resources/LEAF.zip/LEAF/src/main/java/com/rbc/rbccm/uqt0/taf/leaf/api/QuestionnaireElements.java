package com.rbc.rbccm.uqt0.taf.leaf.api;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class QuestionnaireElements {
    private Map<String, String> elements = new HashMap<>();
    private int qId;

    private String getSql(boolean isBaseLine, int questionnaireId) {
        String baselineSql = "" +
                "SELECT v.PROCESS_ID, e.RPT_ELEMENT_ID, ELEMENT_NAME,  ELEMENT_VALUE \n" +
                "FROM  T_LEAF_RPT_ELEMENTS_B e, T_LEAF_RPT_ELEMENT_VALS_B v \n" +
                "WHERE e.RPT_ELEMENT_ID = v.RPT_ELEMENT_ID \n" +
                "AND v.PROCESS_ID = {QID} ORDER BY ELEMENT_NAME";
        String sql = baselineSql.replace("{QID}", "" + questionnaireId);
        if (!isBaseLine) {
            sql = sql.replace("T_LEAF_RPT_ELEMENTS_B","T_LEAF_RPT_ELEMENTS");
            sql = sql.replace("T_LEAF_RPT_ELEMENT_VALS_B","T_LEAF_RPT_ELEMENT_VALS");
        }
        return sql;
    }

    public QuestionnaireElements(boolean isBaseLine, int questionnaireId) throws SQLException {
        qId = questionnaireId;
        DBAccess db = new DBAccess();
        JdbcTemplate jdbcTemp = db.getJdbcTemplate();
        List<QuestionnaireEntity> qList = jdbcTemp.query(getSql(isBaseLine, questionnaireId), new BeanPropertyRowMapper<>(QuestionnaireEntity.class));
        qList.forEach((q) -> elements.put(q.getElement_name() , q.getElement_value()));
    }

    public Map<String, String> getElements() {
        if (elements.isEmpty()) throw new RuntimeException("Questionnaire with ID:" + qId + " was not found");
        return elements;
    }
}
