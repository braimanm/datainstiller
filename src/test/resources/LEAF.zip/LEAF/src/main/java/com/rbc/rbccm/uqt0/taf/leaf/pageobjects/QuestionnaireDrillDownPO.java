package com.rbc.rbccm.uqt0.taf.leaf.pageobjects;

import com.rbccm.taf.ui.support.PageObjectModel;
import com.rbccm.taf.ui.utils.Helper;
import org.openqa.selenium.By;
import org.openqa.selenium.support.FindBy;
import ui.auto.core.components.WebComponent;


public class QuestionnaireDrillDownPO extends PageObjectModel {
    @FindBy(xpath = "//md-dialog//td[.='Aggregate Amount']/following-sibling::td")
    private WebComponent aggregateAmount;
    @FindBy(css = ".ui-grid-footer-cell-wrapper div:nth-child(6)")
    private WebComponent totalAmount;
    @FindBy(css = ".ui-grid-footer-cell-wrapper div:nth-child(4)")
    private WebComponent totalF1Amount;

    public void close() {
        By closeButton = By.cssSelector("button[aria-label='Close dialog']");
        Helper.waitToShow(closeButton).click();
        Helper.waitToHide(closeButton);
    }

    public String getAggregateAmount() {
        return aggregateAmount.getText();
    }

    public String getTotalAmount() {
        return totalAmount.getText().replace("total: ","");
    }

    public String getTotalF1Amount() {
        return totalF1Amount.getText().replace("total: ","");
    }
}
