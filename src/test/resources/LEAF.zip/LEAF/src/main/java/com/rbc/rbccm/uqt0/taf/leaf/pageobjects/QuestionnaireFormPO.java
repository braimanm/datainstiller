package com.rbc.rbccm.uqt0.taf.leaf.pageobjects;

import com.rbccm.taf.ui.support.PageObjectModel;
import com.rbccm.taf.ui.utils.Helper;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.List;

public class QuestionnaireFormPO extends PageObjectModel {

    private void moveFocusToElement(WebElement element) {
        if (element.getLocation().getY() <= 64) {
            getContext().getDriver().findElement(By.xpath("//h1[.='ROYAL BANK OF CANADA']")).click();
        }
    }

    private WebElement getElement(String fieldCode) {
        return getDriver().findElement(By.cssSelector("#" + fieldCode.replace(".","\\.")));
    }

    public String getValue(String fieldCode) {
        return getElement(fieldCode).getText();
    }

    public boolean isDrillDownExists(String fieldCode) {
        WebElement valueElement = getElement(fieldCode);
        List<WebElement> valuesA = valueElement.findElements(By.cssSelector("a"));
        return !valuesA.isEmpty();
    }

    public QuestionnaireDrillDownPO getDrillDown(String fieldCode) {
        WebElement link = getElement(fieldCode).findElement(By.cssSelector("a"));
        moveFocusToElement(link);
        link.click();
        Helper.waitForXHR();
        QuestionnaireDrillDownPO drillDown = new QuestionnaireDrillDownPO();
        drillDown.initPage(getContext());
        return drillDown;
    }

}
