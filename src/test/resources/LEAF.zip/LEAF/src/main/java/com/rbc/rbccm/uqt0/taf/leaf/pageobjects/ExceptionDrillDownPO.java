package com.rbc.rbccm.uqt0.taf.leaf.pageobjects;

import com.rbccm.taf.ui.support.PageObjectModel;
import org.openqa.selenium.support.FindBy;
import ui.auto.core.components.WebComponent;

public class ExceptionDrillDownPO extends PageObjectModel {
    @FindBy(css = ".ui-grid-pager-count")
    private WebComponent totalItems;


    public String getTotalAmount() {
        return totalItems.getText().split("of")[1].replace("items","").trim();
    }

}
