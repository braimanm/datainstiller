package com.rbc.rbccm.uqt0.taf.leaf.api;

public class QuestionnaireEntity {
    private int process_id;
    private int rpt_element_id;
    private String element_name;
    private String element_value;

    public int getProcess_id() {
        return process_id;
    }

    public void setProcess_id(int process_id) {
        this.process_id = process_id;
    }

    public int getRpt_element_id() {
        return rpt_element_id;
    }

    public void setRpt_element_id(int rpt_element_id) {
        this.rpt_element_id = rpt_element_id;
    }

    public String getElement_name() {
        return element_name;
    }

    public void setElement_name(String element_name) {
        this.element_name = element_name;
    }

    public String getElement_value() {
        return element_value;
    }

    public void setElement_value(String element_value) {
        this.element_value = element_value;
    }
}
