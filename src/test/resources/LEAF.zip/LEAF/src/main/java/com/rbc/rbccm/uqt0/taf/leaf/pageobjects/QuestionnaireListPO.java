package com.rbc.rbccm.uqt0.taf.leaf.pageobjects;

import com.rbccm.taf.ui.support.PageObjectModel;
import com.rbccm.taf.ui.utils.Helper;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.List;

public class QuestionnaireListPO extends PageObjectModel {

    public QuestionnaireFormPO getFormByID(int id) {
        By viewQ = By.xpath("//div/a[.='" + id + "']/../../../div[11]//a");
        isIdPresent(viewQ, id).click();
        Helper.waitForXHR();
        QuestionnaireFormPO qForm = new QuestionnaireFormPO();
        qForm.initPage(getContext());
        return qForm;
    }

    public ExceptionsPO getExceptionById(int id) {
        By viewQ = By.xpath("//div/a[.='" + id + "']/../../../div[8]//a");
        isIdPresent(viewQ, id).click();
        Helper.waitForXHR();
        ExceptionsPO exPO = new ExceptionsPO();
        exPO.initPage(getContext());
        return exPO;
    }

    private WebElement isIdPresent(By locator, int id) {
        List<WebElement> els = getDriver().findElements(locator);
        if (els.isEmpty()) throw new RuntimeException("Questionnaire with ID:" + id + " was not found!");
        return els.get(0);
    }

}
