package com.rbccm.taf;

import com.rbccm.taf.ui.support.EnvironmentsSetup;
import com.rbccm.taf.ui.support.UserProvider;
import com.rbccm.taf.ui.testng.TestNGBase;
import org.assertj.core.api.Assertions;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.Test;

public class TestUserProvider extends TestNGBase {
    private static UserProvider userP = UserProvider.getInstance();

    @Test
    public void method() {
        StringBuilder sb = new StringBuilder(Thread.currentThread().getId() + " - ");
        for (int i =1; i<4; i++) {
            EnvironmentsSetup.User user = userP.getUser("role" + i);
            Assertions.assertThat(user).isNotNull();
            Assertions.assertThat(userP.getAllUsedRoles()).containsOnlyOnce(user.getRole());
            sb.append(user.getRole()).append(" , ");
        }
        System.out.println(sb + "\n");

    }

    @AfterSuite
    public void after() {
        System.out.println(UserProvider.getInstance().getAllUsedRoles());
    }



}
