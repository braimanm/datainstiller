package com.rbccm.taf;

import com.rbccm.taf.ui.support.EnvironmentsSetup;
import com.rbccm.taf.ui.support.UserProvider;
import com.rbccm.taf.ui.testng.TestNGBase;
import org.assertj.core.api.Assertions;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.Test;

public class TestUserProvider2 extends TestNGBase {

    @Test
    public void method2() {
        StringBuilder sb = new StringBuilder(Thread.currentThread().getId() + ".2 - ");
        for (int i =1; i<4; i++) {
            EnvironmentsSetup.User user = UserProvider.getInstance().getUser("role" + i);
            Assertions.assertThat(user).isNotNull();
            Assertions.assertThat(UserProvider.getInstance().getAllUsedRoles()).containsOnlyOnce(user.getRole());
            sb.append(user.getRole()).append(" , ");
        }
        System.out.println(sb + "\n");

    }

    @AfterSuite
    public void after() {
        System.out.println(UserProvider.getInstance().getAllUsedRoles());
    }


}
