package com.rbccm.taf.ui.support;

public class DomainObjectModel extends PageObjectModel {
}
