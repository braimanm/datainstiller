package com.rbccm.taf.ui.support;

import ui.auto.core.pagecomponent.PageComponentNoDefaultAction;

public class AliasedString extends PageComponentNoDefaultAction {
    @Override
    protected void init() {}
}
