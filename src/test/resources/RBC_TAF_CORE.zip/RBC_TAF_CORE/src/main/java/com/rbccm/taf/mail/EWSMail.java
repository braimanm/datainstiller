package com.rbccm.taf.mail;

import com.rbccm.taf.ui.support.TestContext;
import com.rbccm.taf.ui.utils.Helper;
import microsoft.exchange.webservices.data.core.ExchangeService;
import microsoft.exchange.webservices.data.core.PropertySet;
import microsoft.exchange.webservices.data.core.enumeration.notification.EventType;
import microsoft.exchange.webservices.data.core.enumeration.property.BasePropertySet;
import microsoft.exchange.webservices.data.core.enumeration.property.WellKnownFolderName;
import microsoft.exchange.webservices.data.core.enumeration.search.SortDirection;
import microsoft.exchange.webservices.data.core.service.item.EmailMessage;
import microsoft.exchange.webservices.data.core.service.item.Item;
import microsoft.exchange.webservices.data.core.service.schema.ItemSchema;
import microsoft.exchange.webservices.data.credential.ExchangeCredentials;
import microsoft.exchange.webservices.data.credential.WebCredentials;
import microsoft.exchange.webservices.data.notification.GetEventsResults;
import microsoft.exchange.webservices.data.notification.ItemEvent;
import microsoft.exchange.webservices.data.notification.PullSubscription;
import microsoft.exchange.webservices.data.property.complex.EmailAddress;
import microsoft.exchange.webservices.data.property.complex.FolderId;
import microsoft.exchange.webservices.data.property.complex.MessageBody;
import microsoft.exchange.webservices.data.property.complex.MimeContent;
import microsoft.exchange.webservices.data.search.FindItemsResults;
import microsoft.exchange.webservices.data.search.ItemView;
import microsoft.exchange.webservices.data.search.filter.SearchFilter;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;


public class EWSMail {
    private ExchangeService service;

    public EWSMail() {
        service = new ExchangeService();
        try {
            service.setUrl(new URI(TestContext.getTestProperties().getMailServer() + "/ews/exchange.asmx"));
        } catch (URISyntaxException e) {
            throw new RuntimeException("e");
        }
    }

    public void setCredentials(String userName, String password) {
        ExchangeCredentials credentials = new WebCredentials(userName, password, "devoak");
        service.setCredentials(credentials);
    }

    public FindItemsResults<Item> getEmailsWithSubject(String text) {
        ItemView itemView = new ItemView(5);
        try {
            itemView.getOrderBy().add(ItemSchema.DateTimeReceived, SortDirection.Descending);
            itemView.setPropertySet(new PropertySet(BasePropertySet.IdOnly, ItemSchema.Subject, ItemSchema.DateTimeReceived));
            SearchFilter filter = new SearchFilter.ContainsSubstring(ItemSchema.Subject, text);
            FindItemsResults<Item> results = service.findItems(WellKnownFolderName.Inbox, filter, itemView);
            if (results.getTotalCount() != 0) {
                service.loadPropertiesForItems(results, PropertySet.FirstClassProperties);
            }
            return results;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public FindItemsResults<Item> getEmailsQ(String q) {
        ItemView itemView = new ItemView(5);
        try {
            itemView.getOrderBy().add(ItemSchema.DateTimeReceived, SortDirection.Descending);
            itemView.setPropertySet(new PropertySet(BasePropertySet.IdOnly, ItemSchema.Subject, ItemSchema.DateTimeReceived));
            FindItemsResults<Item> results = service.findItems(WellKnownFolderName.Inbox, q, itemView);
            if (results.getTotalCount() != 0) {
                service.loadPropertiesForItems(results, PropertySet.FirstClassProperties);
            }
            return results;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public FindItemsResults<Item> waitForEmailWithSubject(String text) {
        long t_o = System.currentTimeMillis() + TestContext.getTestProperties().getEmailTimeout() * 1000;
        FindItemsResults<Item> results;
        do {
            results = getEmailsWithSubject(text);
            if (results.getTotalCount()< 1) {
                Helper.sleep(200);
            }
        } while (results.getTotalCount()< 1 && System.currentTimeMillis() < t_o);
        return results;
    }

    public void waitforEmailAndApprove(String requestId, String msgText) {
        Item item = waitForEmailWithSubject("Request ID# " + requestId).getItems().get(0);
        sendEmailAction(item, "-Email Approval&", msgText);
    }

    public void waitforEmailAndReject(String requestId, String msgText) {
        Item item = waitForEmailWithSubject("Request ID# " + requestId).getItems().get(0);
        sendEmailAction(item, "-Email Rejection&", msgText);
    }

    private void sendEmailAction(Item item, String hrefAction, String msgText) {
        Document doc;
        try {
            doc = Jsoup.parse(item.getBody().toString());
            Elements links = doc.select(("a[href*=" + hrefAction + "]"));
            String[] linkParts = links.get(0).attr("href").replace("mailto:","").
                    replace("subject=","").
                    replace("body=","").
                    split("[?&]");
            sendEmail(linkParts[0], linkParts[1], msgText);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    public void sendEmail(String recipient , String subject, String body) {
        try {
            EmailMessage msg = new EmailMessage(service);
            msg.setSubject(subject);
            msg.setBody(MessageBody.getMessageBodyFromText(body));
            msg.getToRecipients().add(recipient);
            msg.sendAndSaveCopy();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void forwardEmail(Item item, String forwardEmail, String bodyPrefix) {
        EmailMessage msg;
        if (item.getClass().equals(EmailMessage.class)) {
            msg = (EmailMessage) item;
        } else {
            throw new RuntimeException("Unknown email item");
        }
        try {
            msg.forward(MessageBody.getMessageBodyFromText(bodyPrefix), new EmailAddress(forwardEmail));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public byte[] getEmailAsEml (Item item) {
        EmailMessage msg;
        if (item.getClass().equals(EmailMessage.class)) {
            msg = (EmailMessage) item;
        } else {
            throw new RuntimeException("Unknown email item");
        }

        try {
            msg.load(new PropertySet((ItemSchema.MimeContent)));
            MimeContent mc = msg.getMimeContent();
            return mc.getContent();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void close() {
        service.close();
    }

    public PullSubscription subscribeForNotifications() {
        List<FolderId> folders = new ArrayList<>();
        folders.add(FolderId.getFolderIdFromWellKnownFolderName(WellKnownFolderName.Inbox));
        try {
            return service.subscribeToPullNotifications(folders, 1, null, EventType.NewMail, EventType.Deleted);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public List<EmailMessage> getEmailsWithText(PullSubscription subscription, String text) throws Exception {
        List<EmailMessage> messages = new ArrayList<>();
        GetEventsResults events = subscription.getEvents();
        for (ItemEvent event : events.getItemEvents()) {
            if (event.getEventType() == EventType.NewMail) {
                EmailMessage message = EmailMessage.bind(service, event.getItemId());
                if (message.getBody().toString().contains(text)) {
                    messages.add(message);
                } else {
                    System.out.println("MESSAGE NOT BELONGS TO ME !" + message.getSubject());
                }
            }
        }
        return messages;
    }

}