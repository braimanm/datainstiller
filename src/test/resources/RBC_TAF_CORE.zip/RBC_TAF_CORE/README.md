RBC-TAF is stands for RBC Test Automation Framework

Test Automation is a critical regression activity for validating software development products with short development cycles. In today’s agile software development approach, it’s essential that Test Automation will be executed frequently in pace with product evolution and will be part of Continuous Integration. Therefore Automation Framework should natively support software development life cycle and assist with rapid and efficient development of various business Automation Tests. Automation framework should also support Data Driven testing approach where same business logic scenario is used across different data sets to reduce maintenance and improve test coverage.

RBC-TAF is another attempt to make life of automation developers easier by providing concise test automation development approach with automatic generation of test data-sets from page-objects and generation of detailed report at the end of the test execution.  
The RBC-TAF uses new approach for business oriented testing by introducing new design pattern called “domain-objects” where multiple web pages are involved across single business scenario.  
RBC-TAF supports concurrency right out of the box by invoking multiple test cases using multiple supported browsers on the single machine, on the selenium grid or on Virtual Machines in the cloud.  
RBC-TAF can run using any Web Browser on Linux, Windows or Mac OS without any special installations, all you need is Operating System and Web Browser.  
RBC-TAF seamlessly integrates with continuous integration systems allowing easy configuration for running the tests jobs against multiple environments, it also has capability to embed test report with any job run by hosting the report on the CI server.  
