package com.rbc.rbccm.taf.atis.pageobjects;

import com.rbccm.taf.ui.support.PageObjectModel;

public class OpenTradesReportsPO extends PageObjectModel {

}
