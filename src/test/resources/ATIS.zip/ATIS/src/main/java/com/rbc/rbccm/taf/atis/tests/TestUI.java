package com.rbc.rbccm.taf.atis.tests;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.rbc.rbccm.taf.atis.api.OpenTradesReport;
import com.rbc.rbccm.taf.atis.components.UIGrid;
import com.rbc.rbccm.taf.atis.pageobjects.LoginPO;
import com.rbccm.taf.ui.support.TestContext;
import com.rbccm.taf.ui.testng.TestNGBase;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import java.io.IOException;

public class TestUI extends TestNGBase {

    @Test
    public void test() throws IOException {
        LoginPO login = new LoginPO(getContext());
        login.login();

        String url= System.getenv(TestContext.getTestProperties().getTestEnvironment().getUrl());
        WebDriver driver = getContext().getDriver();

        WebElement grid = driver.findElement(By.cssSelector("div[role=grid]"));
        UIGrid uiGrid = new UIGrid(grid);
        uiGrid.init();
        OpenTradesReport[] tradesReports = uiGrid.getTradesReports();
        System.out.println(tradesReports);


        //driver.get(url+"/api/OpenTradesReport?businessDate="+DateTimeUtils.currentTimeMillis());
        // String s = driver.findElement(By.tagName("pre")).getText();
        //System.out.println(s);

        //ObjectMapper mapper = new ObjectMapper();
        //OpenTradesReport[] reports = mapper.readValue(s, OpenTradesReport[].class);

        //System.out.println(reports);
    }


}
