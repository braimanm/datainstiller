package com.rbc.rbccm.taf.atis.api;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Date;

@JsonIgnoreProperties(ignoreUnknown=true)
public class OpenTradesReport {
    @JsonProperty("accountCDC")
    private String account;
    @JsonProperty("accountCheck")
    private String check;
    @JsonProperty("accountType")
    private String type;
    @JsonProperty("adpNumber")
    private String security_nbr;
    @JsonProperty("boController")
    private String bo_cntl_no;
    @JsonProperty("bottler")
    private String blot;
    @JsonProperty("branchCDC")
    private String branch;
    @JsonProperty("brokerClearing")
    private String clh;
    @JsonProperty("businessDate")
    private Date businessDate;
    @JsonProperty("country")
    private String place_of_settlement;
    @JsonProperty("currency")
    private String currency_cd;
    @JsonProperty("cusip")
    private String cusip;
    @JsonProperty("dof")
    private String dof;
    @JsonProperty("eligibility")
    private String euroclear_dtc_eligibility;
    @JsonProperty("flashMessage")
    private String flashMessage;
    @JsonProperty("iSin")
    private String isin;
    @JsonProperty("msgStatusCode")
    private String msgStatusCode;
    @JsonProperty("posKey")
    private String posKey;
    @JsonProperty("price")
    private String price;
    @JsonProperty("rbcStatus")
    private String rbc_trade_status;
    @JsonProperty("remainingAmount")
    private String amount;
    @JsonProperty("remainingQty")
    private String quantity;
    @JsonProperty("secDescription")
    private String description;
    @JsonProperty("section")
    private String spin_code;
    @JsonProperty("senderReference")
    private String sender_reference;
    @JsonProperty("settledAmount")
    private String settledAmount;
    @JsonProperty("settledQuantity")
    private String settledQuantity;
    @JsonProperty("settlementDate")
    private Date settlement_date;
    @JsonProperty("tagNumber")
    private String tag_nbr;
    @JsonProperty("tradeDate")
    private Date trade_date;
    @JsonProperty("updatedDateTime")
    private Date updatedDateTime;

    public String getAccount() {
        return account;
    }

    public String getCheck() {
        return check;
    }

    public String getType() {
        return type;
    }

    public String getSecurity_nbr() {
        return security_nbr;
    }

    public String getBo_cntl_no() {
        return bo_cntl_no;
    }

    public String getBlot() {
        return blot;
    }

    public String getBranch() {
        return branch;
    }

    public String getClh() {
        return clh;
    }

    public Date getBusinessDate() {
        return businessDate;
    }

    public String getPlace_of_settlement() {
        return place_of_settlement;
    }

    public String getCurrency_cd() {
        return currency_cd;
    }

    public String getCusip() {
        return cusip;
    }

    public String getDof() {
        return dof;
    }

    public String getEuroclear_dtc_eligibility() {
        return euroclear_dtc_eligibility;
    }

    public String getFlashMessage() {
        return flashMessage;
    }

    public String getIsin() {
        return isin;
    }

    public String getMsgStatusCode() {
        return msgStatusCode;
    }

    public String getPosKey() {
        return posKey;
    }

    public String getPrice() {
        return price;
    }

    public String getRbc_trade_status() {
        return rbc_trade_status;
    }

    public String getAmount() {
        return amount;
    }

    public String getQuantity() {
        return quantity;
    }

    public String getDescription() {
        return description;
    }

    public String getSpin_code() {
        return spin_code;
    }

    public String getSender_reference() {
        return sender_reference;
    }

    public String getSettledAmount() {
        return settledAmount;
    }

    public String getSettledQuantity() {
        return settledQuantity;
    }

    public Date getSettlement_date() {
        return settlement_date;
    }

    public String getTag_nbr() {
        return tag_nbr;
    }

    public Date getTrade_date() {
        return trade_date;
    }

    public Date getUpdatedDateTime() {
        return updatedDateTime;
    }
}
