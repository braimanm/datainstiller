package com.rbc.rbccm.taf.atis.api;

public interface EXCELDataMapperInterface {
    void setField(String name, String value);
}
