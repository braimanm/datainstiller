package com.rbc.rbccm.taf.atis.api;

import java.sql.CallableStatement;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Types;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

public class DBActions {


    public static void delete_all() throws SQLException {
        String[] sql = { "delete from RTU70TRADE.T_STG_ISEC_OPEN_POSITION where BUSINESS_DATE_D = ?",
                "delete from RTU70TRADE.T_ISEC_OPEN_POSITION where BUSINESS_DATE_D = ?",
                "delete from RTU70TRADE.T_ISEC_EXCEPTION where BUSINESS_DATE_D = ?",
                "delete from RTU70TRADE.T_ISEC_OPEN_TRADE where BUSINESS_DATE_D = ?",
                "delete from RTU70TRADE.T_ISEC_SEG_MOVEMENT where BUSINESS_DATE_D = ?",
                "delete from RTU70TRADE.T_ISEC_ADP_HOLDING_STMT where BUSINESS_DATE_D = ?",
                "delete from RTU70TRADE.T_ISEC_PENDING_EXCESS where BUSINESS_DATE_D = ?",
                "delete from RTU70TRADE.T_ISEC_CITI_ACCT_STMT where BUSINESS_DATE_D = ?",
                "delete from RTU70TRADE.T_ISEC_CITI_POS_LOAD_STATUS where STATEMENT_DATE_D = ?"
        };

        DBAccess db = new DBAccess();
        for (String statement : sql) {
            Date date = Date.valueOf(LocalDate.now());;
            if (statement.contains("T_ISEC_PENDING_EXCESS")) {
                date = Date.valueOf(LocalDate.now().minusDays(1));
            }
            System.out.println(statement.replace("?", "'" + date.toString()) + "';");
            System.out.println(db.getJdbcTemplate().update(statement, date) + " rows deleted.");
        }
    }

    private static void execProc(Date currentDate, CallableStatement statement) throws SQLException {
        statement.setDate(1, currentDate);
        statement.registerOutParameter(2, Types.NUMERIC);
        statement.registerOutParameter(3, Types.VARCHAR);
        statement.executeUpdate();
        System.out.println("ERR CODE " + statement.getBigDecimal(2));
        System.out.println("ERR MESSAGE " + statement.getString(3));
    }

    public static void executePositionProc() {
        Locale.setDefault(Locale.US);
        DBAccess db = new DBAccess();
        Date currentDate = Date.valueOf(LocalDate.now());
        try (CallableStatement statement = db.getDBConnection().prepareCall("{call RTU70TRADE.P_STG_TO_FINAL_POSITION(?,?,?)}")) {
            execProc(currentDate, statement);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public static void executeResolveExceptionsProc() {
        Locale.setDefault(Locale.US);
        DBAccess db = new DBAccess();
        Date currentDate = Date.valueOf(LocalDate.now());
        try (CallableStatement statement = db.getDBConnection().prepareCall("{call  RTU70TRADE.P_RESOLVE_EXCEPTION(?,?,?)}")) {
            execProc(currentDate, statement);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public static void executeExceptionProc() {
        Locale.setDefault(Locale.US);
        DBAccess db = new DBAccess();
        Date currentDate = Date.valueOf(LocalDate.now());
        try (CallableStatement statement = db.getDBConnection().prepareCall("{call  RTU70TRADE.P_STG_TO_EXCEPTION(?,?,?,?,?,?,?,?,?,?,?)}")) {
            statement.setDate(1, currentDate);
            statement.setObject(2, null);
            statement.setObject(3, null);
            statement.setObject(4, null);
            statement.setObject(5, null);
            statement.setObject(6, null);
            statement.setObject(7, null);
            statement.setObject(8, null);
            statement.setObject(9, null);
            statement.registerOutParameter(10, Types.NUMERIC);
            statement.registerOutParameter(11, Types.VARCHAR);
            statement.executeUpdate();
            System.out.println("ERR CODE " + statement.getBigDecimal(10));
            System.out.println("ERR MESSAGE " + statement.getString(11));
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    
    public static void executeTradeInsert() throws SQLException {
        Locale.setDefault(Locale.US);
        String sql = "INSERT INTO RTU70TRADE.T_ISEC_OPEN_TRADE ( " +
                " BUSINESS_DATE_D, " +
                " SENDER_REF_KEY_C, " +
                " CURRENCY_CD_C, " +
                " SECTION_C, " +
                " CUSIP_C, " +
                " ISIN_C, " +
                " COUNTRY_CD_C, " +
                " TAG_NUMBER_C, " +
                " SETTLEMENT_DATE_D, " +
                " TRADE_DATE_D, " +
                " REMAINING_QTY_F, " +
                " BLOTTER_CD_C, " +
                " ELIGIBILITY_CD_C, " +
                " SEC_DESC_C, " +
                " SEC_ADP_NUMBER_C, " +
                " BRANCH_CD_C, " +
                " ACCOUNT_CD_C, " +
                " ACCOUNT_TYPE_C, " +
                " ACCOUNT_CHECK_CD_C, " +
                " REMAINING_AMT_F, " +
                " BROKER_CLEARING_CD_C, " +
                " PRICE_F, " +
                " DOF_I, " +
                " FLASH_MSG_C, " +
                " BO_CTRL_NUMBER_C, " +
                " RBC_STATUS_C) " +
                " select to_char(BUSINESS_DATE_D,'DD-MON-YYYY') Close_Of_Business, " +
                "  P.SENDER_REF_KEY_C, " +
                "  P.CURRENCY_CD_C Currency_Cd, " +
                "  case " +
                "    when TRADE_TYPE_C = '1' then 'COR' " +
                "    when TRADE_TYPE_C = '3' then 'F/R' " +
                "    when TRADE_TYPE_C = '4' then 'COD' " +
                "    when TRADE_TYPE_C = '6' then 'F/D' " +
                "    else null " +
                "  end Section, " +
                "  CUSIP_C CUSIP, " +
                "  ISIN_C ISIN, " +
                "  COUNTRY_CD_C Place_of_Settlement, " +
                "  to_char(TAG_DATE_D,'yymmdd')||TAG_NUMBER_C Tag_Nbr, " +
                "  trunc(SETTLEMENT_DATE_D) Settlement_Date, " +
                "  trunc(TRADE_DATE_D) Trade_Date, " +
                "  REMAINING_QTY_F Quantity, " +
                "  BLOTTER_CD_C Blot, " +
                "  CASE " +
                "    WHEN MATCH_DESC_C IN ('DTC', 'MSD') THEN 'DTC CHILL' " +
                "    WHEN MATCH_DESC_C IN ('DEU', 'MEU') AND DTC_CHILL_FLAG_C = 'Y' THEN 'DTC CHILL' " +
                "    WHEN MATCH_DESC_C IN ('D+E', 'M+E') THEN 'DTC CHILL & Euroclear' " +
                "    WHEN MATCH_DESC_C IN ('D+U', 'D+U') AND DTC_CHILL_FLAG_C = 'Y' THEN 'DTC CHILL & Euroclear' " +
                "    WHEN MATCH_DESC_C = 'EUC' AND EXCEPTION_IDS_C LIKE '%,111,%' THEN 'Euroclear' " +
                "    WHEN MATCH_DESC_C IN ('DEU','MEU') THEN 'DTC' " +
                "    WHEN MATCH_DESC_C IN ('D+U','M+U') THEN 'DTC & Euroclear' " +
                "    ELSE null " +
                "  END  Elig, " +
                "  SEC_DESC_C " +
                "  Description, " +
                "  SEC_ADP_NUMBER_C Security_nbr, " +
                "  BRANCH_CD_C BR, " +
                "  ACCOUNT_CD_C Acct, " +
                "  ACCOUNT_TYPE_C T, " +
                "  ACCOUNT_CHECK_CD_C C, " +
                "  REMAINING_AMT_F Amount, " +
                "  BROKER_CLEARING_CD_C CLH, " +
                "  PRICE_F Price, " +
                "  DOF_I " +
                "  DOF, " +
                "  FLASH_MSG_C Flash_Msg, " +
                "  BO_CTRL_NUMBER_C Bo_Cntl_No, " +
                "  D.SEND_TO_CITI_FLAG_DESC_C RBC_Status " +
                "  from    RTU70TRADE.T_ISEC_OPEN_POSITION P, " +
                " ( " +
                "     SELECT SENDER_REF_KEY_C,SEND_TO_CITI_FLAG_DESC_C FROM ( " +
                "     SELECT SENDER_REF_KEY_C,VALID_FROM_TS, SEND_TO_CITI_FLAG_DESC_C, MAX(VALID_FROM_TS) OVER (PARTITION BY SENDER_REF_KEY_C) MAX_TS FROM RTU70TRADE.T_ISEC_OPEN_POSITION a , " +
                "     RTU70TRADE.T_ISEC_SEND_TO_CITI_FLAG_DESC b " +
                "     WHERE a.SEND_TO_CITI_FLAG_C = b.SEND_TO_CITI_FLAG_C " +
                "     AND b.SEND_TO_CITI_FLAG_DESC_C NOT LIKE 'MT548%' " +
                "     ) " +
                "      WHERE VALID_FROM_TS=MAX_TS " +
                " ) D " +
                "  where " +
                "  P.BUSINESS_DATE_D = '?' " +
                "  AND P.SENDER_REF_KEY_C = D.SENDER_REF_KEY_C(+) " +
                "  AND P.VALID_TO_TS>sysdate ";

        DBAccess db = new DBAccess();
        int i = db.getJdbcTemplate().update(sql.replace("?", DateTimeFormatter.ofPattern("dd-MMM-yyyy").format(LocalDate.now())));
        System.out.println("Added " + i + " records!");
    }

    public static void insertHolidays() throws SQLException {
        String sql = "insert into RTU70TRADE.T_ISEC_HOLIDAY_CALENDAR (" +
                "COUNTRY_CD_C,COUNTRY_NAME_C,YEAR_C,MONTH_C,DAY_C,HOL_DESC_CD_C) " +
                "values (?,?,?,?,?,?)";

        LocalDate nowPlus3Days = LocalDate.now().plusDays(3);
        String yyyy = nowPlus3Days.format(DateTimeFormatter.ofPattern("YYYY"));
        String mm = nowPlus3Days.format(DateTimeFormatter.ofPattern("MM"));
        String dd = nowPlus3Days.format(DateTimeFormatter.ofPattern("dd"));
        DBAccess db = new DBAccess();
        int i = db.getJdbcTemplate().update(sql, new Object[] {"FR","France",yyyy,mm,dd,null} );
        System.out.println("Added " + i + " record!");
        i = db.getJdbcTemplate().update(sql, new Object[] {"CA","Canada",yyyy,mm,dd,null} );
        System.out.println("Added " + i + " record!");

    }
}
