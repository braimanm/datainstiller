package com.rbc.rbccm.taf.atis.tests;
import com.rbc.rbccm.taf.atis.api.DBActions;
import com.rbc.rbccm.taf.atis.api.TradeInstructionInput;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;

import java.io.IOException;
import java.sql.*;

public class Test {


    @org.testng.annotations.Test
    public void populate() throws IOException, InvalidFormatException, InstantiationException, IllegalAccessException, SQLException {
        DBActions.delete_all();

        TradeInstructionInput.populateFromEXCEL("data/ATIS Testcases Automation -  V3.xlsx", "TC 1 Trade Instruction Input");
        TradeInstructionInput.populateFromEXCEL("data/ATIS Testcases Automation -  V3.xlsx", "TC 1 Exception Input");

        DBActions.insertHolidays();

        DBActions.executePositionProc();
        DBActions.executeResolveExceptionsProc();
        DBActions.executeExceptionProc();
        DBActions.executeTradeInsert();
    }



}
