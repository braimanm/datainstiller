package com.rbc.rbccm.taf.atis.api;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.*;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

public class EXCELMapper<T extends EXCELDataMapperInterface> {


    protected List<T> readEXCEL(String fileName, String tabName, Class<T> classToMap) throws IOException, InvalidFormatException, IllegalAccessException, InstantiationException {
        List<T> list = new ArrayList<>();
        Workbook workbook = WorkbookFactory.create(this.getClass().getClassLoader().getResourceAsStream(fileName));
        Sheet sheet = workbook.getSheet(tabName);
        AtomicBoolean isFirstRow = new AtomicBoolean(true);
        List<String> keys = new ArrayList<>();
        for (Row row : sheet) {
            final T objectToMap = classToMap.newInstance();
            AtomicInteger i = new AtomicInteger();
            row.forEach(cell -> {
                String value = new DataFormatter().formatCellValue(cell);
                if (isFirstRow.get()) {
                    value = value.trim().toUpperCase();
                    keys.add(i.getAndIncrement(), value);
                } else {
                    if (i.get() < keys.size()) {
                        String fieldName = keys.get(i.getAndIncrement());
                        objectToMap.setField(fieldName, value);
                    }
                }
            });
            if (isFirstRow.get()) {
                isFirstRow.set(false);
            } else {
                list.add(objectToMap);
            }
        }
        return list;
    }

}
