package com.rbc.rbccm.taf.atis.api;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;

import java.io.IOException;
import java.lang.reflect.Field;
import java.sql.Date;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;


public class TradeInstructionInput implements EXCELDataMapperInterface{
    private Date BUSINESS_DATE_D = null;
    private String POS_KEY_C = null;
    private Date TAG_DATE_D = null;
    private String TAG_NUMBER_C = null;
    private String CUSIP_C = null;
    private String SEC_ADP_NUMBER_C = null;
    private String ISIN_C = null;
    private String BRANCH_CD_C = null;
    private String ACCOUNT_CD_C = null;
    private String ACCOUNT_TYPE_C = null;
    private String BLOTTER_CD_C = null;
    private Date TRADE_DATE_D = null;
    private Date SETTLEMENT_DATE_D = null;
    private Long REMAINING_QTY_F = null;
    private Double REMAINING_AMT_F = null;
    private Double PRICE_F = null;
    private String CURRENCY_CD_C = null;
    private String TRADE_TYPE_C = null;
    private String PSET_CD_C = null;
    private String COUNTRY_CD_C = null;
    private String ORIGIN_CD_C = null;
    private String SEC_DESC_C = null;
    private String ACCOUNT_CHECK_CD_C = null;
    private String BROKER_CLEARING_CD_C = null;
    private String FLASH_MSG_C = null;
    private String BROKER_CONFIRM_NBR_C = null;
    private String ACTIVITY_CD_C = null;
    private String ACTIVITY_TYPE_C = null;
    private String RECORD_TYPE_CD_C = null;
    private String ACTION_CD_C = null;
    private Date UPDATE_LAST_TS = null;
    private String MATCH_DESC_C = null;
    private String EXCEPTION_IDS_C = null;
    private String DTC_CHILL_FLAG_C = null;
    private String MARK_VALID_FLAG_C = null;
    private Long DOF_I = null;
    private Long BO_CTRL_NUMBER_C = null;
    private Long PROCESS_ID_I = null;


    public static void populateFromEXCEL(String fileName, String tabName) throws InvalidFormatException, InstantiationException, IllegalAccessException, IOException, SQLException {
        EXCELMapper<TradeInstructionInput> mapper = new EXCELMapper<>();
        List<TradeInstructionInput> trades = mapper.readEXCEL(fileName, tabName, TradeInstructionInput.class);
        for (TradeInstructionInput input: trades) {
            input.populateDB();
        }
    }

    public void  populateDB() throws SQLException {
        String sql = "insert into RTU70TRADE.T_STG_ISEC_OPEN_POSITION " + getFieldList();
//        for (Object o : get()) {
//            System.out.print(o + "\t|\t");
//        }
//        System.out.println("\n------------------------------------------------------------------------------------------------------------------------------------------------");
        DBAccess db = new DBAccess();
        int i = db.getJdbcTemplate().update(sql, get());
        System.out.println("Added " + i + " record!");
    }

    private String getFieldList() {
        StringBuilder sql = new StringBuilder("(");
        StringBuilder vals = new StringBuilder(") values (");
        Field[] fields = TradeInstructionInput.class.getDeclaredFields();
        for (int i = 0; i < fields.length; i++) {
            sql.append(i==0 ? "":",").append(fields[i].getName());
            vals.append(i==0 ? "":",").append("?");
        }
        return sql.toString() + vals + ")";
    }

    private Object[] get() {
        Field[] fields = TradeInstructionInput.class.getDeclaredFields();
        Object[] values = new Object[fields.length];
        for (int i =0; i < fields.length; i++) {
            fields[i].setAccessible(true);
            Object value;
            try {
                value = fields[i].get(this);
            } catch (Exception e) {
                value = null;
            }
            values[i] = value;
        }
        return values;
    }

    @Override
    public void setField(String name, String value) {
        if (name.toUpperCase().trim().equals("TEST CASE")) {
            return;
        }
        LocalDate dateNow = LocalDate.now();
        Date currentDate = Date.valueOf(dateNow);
        try {
            Field field = TradeInstructionInput.class.getDeclaredField(name);
            field.setAccessible(true);
            if (value.trim().isEmpty()) {
                field.set(this, null);
                return;
            }
            switch (field.getType().getName()) {
                case "java.lang.String":
                    if (field.getName().equals("POS_KEY_C")) {
                        value = value.replace("YYYYMMDD",dateNow.format(DateTimeFormatter.ofPattern("yyyyMMdd")));
                    }
                    field.set(this,value);
                    break;
                case "java.sql.Date":
                    if (!field.getName().equals("UPDATE_LAST_TS") && (value.matches(".*[-,+].*"))) {
                        int days = Integer.parseInt(value.replaceAll(".*[-,+]","").trim());
                        LocalDate date;
                        if (value.contains("-")) {
                            date = dateNow.minusDays(days);
                        } else {
                            date = dateNow.plusDays(days);
                        }
                        field.set(this, Date.valueOf(date));
                    } else {
                        field.set(this, currentDate);
                    }
                    break;
                case "java.lang.Long":
                    if (field.getName().equals("PROCESS_ID_I")) {
                        value = value.replace("YYYYMMDD", dateNow.format(DateTimeFormatter.ofPattern("yyyyMMdd")));
                    }
                    field.set(this, Long.valueOf(value.trim()));
                    break;
                case "java.lang.Double" :
                    field.set(this, Double.valueOf(value.trim()));
                    break;
            }
        } catch (NoSuchFieldException | IllegalAccessException e) {
            throw new RuntimeException(e);
        }
    }

}
