package com.rbc.rbccm.taf.atis.pageobjects;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.rbc.rbccm.taf.atis.api.OpenTradesReport;
import com.rbccm.taf.ui.support.AliasedString;
import com.rbccm.taf.ui.support.EnvironmentsSetup;
import com.rbccm.taf.ui.support.PageObjectModel;
import com.rbccm.taf.ui.support.TestContext;
import com.rbccm.taf.ui.utils.Helper;
import datainstiller.data.Data;
import org.assertj.core.api.Assertions;
import org.joda.time.DateTimeUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import ui.auto.core.components.WebComponent;

import java.io.IOException;
import java.time.format.DateTimeFormatter;

@SuppressWarnings("unused")
public class LoginPO extends PageObjectModel {
    private AliasedString url;
    @FindBy(css = "#myusr_name")
    private WebComponent userName;
    @FindBy(css = "#myusr_password")
    private WebComponent userPswd;
    @Data(skip = true)
    @FindBy(css = "a[onclick^=run_login")
    private WebComponent loginButton;

    public LoginPO(TestContext context) {
        initPage(context);
    }

    public void login() throws IOException {
        EnvironmentsSetup.User envUser = TestContext.getTestProperties().getTestEnvironment().getUser("user");
        if (!System.getenv().containsKey(envUser.getUserName())) {
            throw new RuntimeException("Application Login user is not set in system environment!");
        }
        if (!System.getenv().containsKey(envUser.getPassword())) {
            throw new RuntimeException("Application Login password is not set in system environment!");
        }

        String user = System.getenv(envUser.getUserName());
        String pswd = System.getenv(envUser.getPassword());
        String url= System.getenv(TestContext.getTestProperties().getTestEnvironment().getUrl());
        getDriver().get(url);
        setElementValue(userName, user);
        setElementValue(userPswd, pswd);
        loginButton.click();
        Helper.waitForXHR();
        Assertions.assertThat(getDriver().getCurrentUrl()).withFailMessage("Login was not successful!").doesNotContain("/auth/Login");
    }

}
