package com.rbc.rbccm.taf.atis.components;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.rbc.rbccm.taf.atis.api.OpenTradesReport;
import com.rbccm.taf.ui.utils.Helper;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import ui.auto.core.pagecomponent.PageComponentNoDefaultAction;

import java.io.IOException;


public class UIGrid extends PageComponentNoDefaultAction {
    private OpenTradesReport[] data;

    public UIGrid(WebElement el) {
        coreElement = el;
    }

    @Override
    public void init() {
        JavascriptExecutor exe = (JavascriptExecutor) Helper.getWebDriver();
        String script = "return angular.element(arguments[0]).controller().gridOptions.data;";
        ObjectMapper mapper = new ObjectMapper();
        try {
            String json = mapper.writeValueAsString(exe.executeScript(script, coreElement));
            data = mapper.readValue(json, OpenTradesReport[].class);
        } catch (IOException e ) {
            throw new RuntimeException(e);
        }
    }

    public OpenTradesReport[] getTradesReports() {
        return data;
    }
}
